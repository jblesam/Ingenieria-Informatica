package uoc.ei.practica;

import java.util.Comparator;

public class Worker extends IdentifiedObject  {
	/**
	 * comparador dels operaris basat en l'operari que té menys incidències assignades.
	 */
	public static final Comparator WORKER_BY_TICKETS_COMPARATOR = new Comparator<Worker>(){
		@Override
		public int compare(Worker worker1, Worker worker2) {
			return (int)(worker1.getNumTickets()-worker2.getNumTickets());
		}
		
	};
	
	private int numTickets=0;	
	private String name;
	
	public Worker(String dni, String name) {
		super(dni);		
		this.name = name;
	}

	public int incidences() {
		return numTickets;
	}

	public void incIncidences() {
		this.numTickets++;
	}
	
	public void decIncidences() {
		if(this.numTickets > 0) this.numTickets--;
	}
	
	public int getNumTickets() {
		return numTickets;
	}

	public void setNumTickets(int numTickets) {
		this.numTickets = numTickets;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String toString() {
		StringBuffer sb=new StringBuffer("dni: "+this.getIdentifier()).append(Messages.LS);
		sb.append("name: ").append(this.name).append(Messages.LS);
		sb.append("numTickets: ").append(this.numTickets).append(Messages.LS);				
		return sb.toString();		
	}
}
