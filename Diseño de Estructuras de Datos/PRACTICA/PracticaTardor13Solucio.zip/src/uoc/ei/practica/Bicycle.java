package uoc.ei.practica;

import java.util.Comparator;
import java.util.Date;

import uoc.ei.tads.Contenidor;
import uoc.ei.tads.Iterador;
import uoc.ei.tads.Llista;
import uoc.ei.tads.LlistaEncadenada;

enum BicycleStatus { READY, DAMAGED}
public class Bicycle extends IdentifiedObject implements Comparable<Bicycle> {

	private String model;
	private long totalTime;
	private Llista<Service> services;
	private Llista<Ticket> tickets;
	private Service currentService;
	private Station station;
	private BicycleStatus status;
	
	
	public static Comparator<String>  COMP = new Comparator<String>() {
		public int compare(String arg0, String arg1) {
			return arg0.compareTo(arg1);
		}		
	};
	

	public Bicycle(String bicycleId, String model, Station station) {
		this(bicycleId);
		this.model=model;
		this.services = new LlistaEncadenada<Service>();
		this.tickets = new LlistaEncadenada<Ticket>();
		this.currentService=null;
		this.status = BicycleStatus.READY;
		this.station = station;
	}

	public Bicycle(String bicycleId) {
		super(bicycleId);
	}

	public long time() {
		return this.totalTime;
	}
	
	
	public Contenidor<Service> services() {
		return this.services;
	}


	public void startService(User user, Station station, Date dateTime) {
		Service service= new Service(user, station, dateTime);
		this.services.afegirAlFinal(service);
		this.currentService=service;
		this.station = null;
		user.addCurrentService(service);
	}

	
	public void finishService(Station toStationId, Date dateTime) {
		long time = this.currentService.finish(toStationId, dateTime);
		User user = this.currentService.getUser();
		user.finishCurrentService();
		this.currentService=null;
		this.station = toStationId;
		this.totalTime+=time;

	}
	
	public void addTicket(Ticket ticket)  {
		this.tickets.afegirAlPrincipi(ticket);
	}
	
	public boolean isLessUsed(Bicycle bike) {
		return this.time() < bike.time();
	}
	
	public Iterador<Ticket> tickets() throws EIException  {
		if(this.tickets.estaBuit()) throw new EIException(Messages.NO_TICKETS);
		return this.tickets.elements();
	}
	public BicycleStatus getStatus() {
		return status;
	}

	public void setStatus(BicycleStatus status) {
		this.status = status;
	}

	
	
	public String toString() {
		StringBuffer sb=new StringBuffer(super.toString());
		sb.append("model: ").append(this.model).append(Messages.LS);
		if(this.status == BicycleStatus.DAMAGED) {
			sb.append("status: ").append(this.status).append(Messages.LS);
		}
		sb.append("time of use: ").append(DateUtils.diffHours(this.totalTime)).append(" hours");
		if (this.totalTime!=0) sb.append(" (timeMilis: ").append(this.totalTime+") ").append(Messages.LS);
		else sb.append(Messages.LS);
		
		if (this.currentService!=null) sb.append(Messages.RUNNING).append(Messages.LS);
		
		
		return sb.toString();		
	}
	
	

	public Station getStation() {
		return station;
	}

	public void setStation(Station station) {
		this.station = station;
	}

	
	@Override
	public int compareTo(Bicycle arg0) {
		return this.identifier.compareTo(arg0.identifier);
	}

}
