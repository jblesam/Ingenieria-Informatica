package uoc.ei.practica;

import uoc.ei.tads.Contenidor;
import uoc.ei.tads.Iterador;
import uoc.ei.tads.LlistaEncadenada;

public class Station {

	private int stationId;
	private long latitude;
	private long longitude;
	private int nParkings;
    private int activity;	
	private int numIncidences;		
	private IdentifiedList<Bicycle> bicycles;
	private IdentifiedList<Bicycle> damagedBicycles;
		

	public Station(int stationId, long latitude, long longitude, int nParkings) {
		this.stationId=stationId;
		this.set(latitude, longitude, nParkings);		
		this.bicycles = new IdentifiedList<Bicycle>();
		this.damagedBicycles = new IdentifiedList<Bicycle>();
		this.numIncidences = 0;
	}

	public void set(long latitude, long longitude, int nParkings) {
		this.latitude = latitude;
		this.longitude= longitude;
		this.nParkings=nParkings; 
	}
	
	public void addBicycle(Bicycle bicycle) throws EIException {
		if (this.bicycles.nombreElems()>=this.nParkings) throw new EIException(Messages.MAX_NUMBER_OF_BICYCLES);		
		else this.bicycles.afegirAlFinal(bicycle);
	}
	
	public Contenidor<Bicycle> bicycles() {
		return this.bicycles;
	}
			
	public Bicycle getBicycle() {
		Bicycle bicycle=null;
		if (!this.bicycles.estaBuit()) {
			bicycle = getLessUsedBike();			
		}
		if(bicycle != null) this.bicycles.deleteIdentifiedObject(bicycle.getIdentifier());
		return bicycle;
	}
			
	private Bicycle getLessUsedBike() {
		Bicycle lessUsedBike = null;  
		Iterador<Bicycle> it = this.bicycles.elements();
		while(it.hiHaSeguent()) {
			Bicycle element = (Bicycle) it.seguent();
			if(lessUsedBike == null || element.isLessUsed(lessUsedBike)) {
				lessUsedBike = element;
			}
		}		
		return lessUsedBike;
	}
		

	public int getNBicycles()  {
		return this.bicycles.nombreElems();		
	}

	
	public int getNParkings() {
		int numFreeParkings = this.nParkings - (this.bicycles.nombreElems() + this.damagedBicycles.nombreElems());		
		return numFreeParkings;
	}
	
	public boolean isClosestThanAndHasFreeParkings(long latitude, long longitude, Station station) {
		int numFreeParkings = this.getNParkings();
		if(numFreeParkings > 0 && this.isClosestThan(latitude, longitude, station) ) return true;
		return false;		
	}
	
	public boolean isClosestThanAndHasBikes(long latitude, long longitude, Station station) {
		int numBikes = this.getNBicycles();
		if(numBikes > 0 && this.isClosestThan(latitude, longitude, station) ) return true;
		return false;
		
	}
	
	private boolean isClosestThan(long latitude, long longitude, Station station) {
		double distanceFromThisStation = this.distanceToPoint(latitude, longitude);
		double distanceFromTheOtherStation = station.distanceToPoint(latitude, longitude);		
		return distanceFromThisStation <= distanceFromTheOtherStation;
	} 
	
	public double distanceToPoint(long latitude, long longitude) {
		// calculate euclidian distance to point
		double xDiff = (double)latitude- (double)this.latitude;
        double xSqr  = Math.pow(xDiff, 2);
        double yDiff = (double)longitude- (double)this.longitude;
        double ySqr = Math.pow(yDiff, 2);
        return  Math.sqrt(xSqr + ySqr);		 		
	}
	
	public long getLatitude() {
		return latitude;
	}
	

	public long getLongitude() {
		return longitude;
	}

	public String toString() {
		StringBuffer sb=new StringBuffer("id: "+this.stationId).append(Messages.LS);
		sb.append("latitude: ").append(this.latitude).append(Messages.LS);
		sb.append("longitude: ").append(this.longitude).append(Messages.LS);
		sb.append("nParkings: ").append(this.nParkings).append(Messages.LS);
		sb.append("bicycles: ").append(this.bicycles.nombreElems()).append(Messages.LS);
		
		return sb.toString();
		
	}

	
	public int getIdentifier() {
		return this.stationId;
	}
	
	
	public void incActivity() {
		this.activity++;
	}

	
	public int activity() {
		return this.activity;
	}

	public int incidences() {
		return numIncidences;
	}

	public void addTicket(Bicycle damagedBike) {		
		this.sendBikeToDamagedContainer(damagedBike);		
		this.numIncidences++;
	}
	
	public void resolveTicket(Bicycle damagedBike) {
		this.sendBikeToReadyContainer(damagedBike);		
	}
	
	private void sendBikeToDamagedContainer(Bicycle damagedBike) {
		if(this.bicycles.deleteIdentifiedObject(damagedBike.getIdentifier()) != null) {
			this.damagedBicycles.afegirAlFinal(damagedBike);
		}
	}
	
	private void sendBikeToReadyContainer(Bicycle readyBike) {
		if(this.damagedBicycles.deleteIdentifiedObject(readyBike.getIdentifier()) != null) {
			this.bicycles.afegirAlFinal(readyBike);
		}
	}
	
}