package uoc.ei.practica;

import java.util.Date;

import uoc.ei.tads.Contenidor;
import uoc.ei.tads.CuaAmbPrioritat;
import uoc.ei.tads.Diccionari;
import uoc.ei.tads.DiccionariAVLImpl;
import uoc.ei.tads.Iterador;
import uoc.ei.tads.IteradorVectorImpl;
import uoc.ei.tads.LlistaEncadenada;
import uoc.ei.tads.TaulaDispersio;

public class BicingManagerImpl implements BicingManager {
	
	private int len;
	private Station[] stations;			
	private Diccionari<String, Bicycle> bicycles;		
	private Diccionari<String, User> users;		
	private CuaAmbPrioritat<Worker> workers;
	private Diccionari<Integer, Ticket> tickets;
	private Station mostActiveStation;
	private User mostActiveUser;
	private Station mostProblematicStation;
	

	public BicingManagerImpl() {
		this.stations= new Station[S];
		this.len=0;		
		this.bicycles = new TaulaDispersio<String, Bicycle>();
		this.users= new DiccionariAVLImpl<String, User>();
		this.workers = new CuaAmbPrioritat<Worker>(Worker.WORKER_BY_TICKETS_COMPARATOR);		
		this.tickets = new DiccionariAVLImpl<Integer, Ticket>();
		this.mostActiveStation=null;
		this.mostActiveUser=null;
		this.mostProblematicStation=null;
	}


	@Override
	public void addStation(int stationId, long latitude, long longitude,
			int nParkings) throws EIException {
		Station station = this.getStation(stationId);
		
		if (station!=null) station.set(latitude, longitude, nParkings);
		else {
			station = new Station(stationId, latitude, longitude, nParkings);
			this.stations[stationId-1]=station;
			if (len<stationId) len=stationId;
		}	
	}


	private Station getStation(int stationId) {
		Station ret=null;
		if (stationId<=this.len) 
			ret = this.stations[stationId-1];
		return ret;
	}
	
	private Station getStation(int stationId, String message) throws EIException {
		Station station = this.getStation(stationId);
		if (station==null) throw new EIException(message);
		
		return station;
	}
	
	@Override
	public Iterador<Station> stations() throws EIException {
		if (this.len==0) throw new EIException(Messages.NO_STATIONS);
		Iterador<Station> it =  new IteradorVectorImpl(this.stations,this.len,0);
		return it;
	}


	@Override
	public void addBicycle(String bicycleId, String model, int stationId)
			throws EIException {
		
		Bicycle bicycle = this.bicycles.consultar(bicycleId); 
		
		if (bicycle!=null) throw new EIException(Messages.BICYCLE_ALREADY_EXISTS);
		
			
		Station station = this.getStation(stationId, Messages.STATION_NOT_FOUND);
		
		bicycle = new Bicycle(bicycleId, model, station);
		station.addBicycle(bicycle);
		this.bicycles.afegir(bicycleId, bicycle);		
	}

	@Override
	public Iterador<Bicycle> bicyclesByStation(int stationId)
			throws EIException {
		Station station = this.getStation(stationId, Messages.STATION_NOT_FOUND);
		Contenidor<Bicycle> bicycles = station.bicycles();
		if (bicycles.estaBuit()) throw new EIException(Messages.NO_BICYCLES);
		return bicycles.elements();
	}


	@Override
	public Iterador<Bicycle> bicycles() throws EIException {
		if (this.bicycles.estaBuit()) throw new EIException(Messages.NO_BICYCLES);		
		return bicycles.elements();
	}


	@Override
	public void addUser(String userId, String name) {
		User user = this.users.consultar(userId);
		
		if (user!=null) user.set(name);
		else {
			user = new User(userId, name);
			this.users.afegir(userId, user);
		}		
	}


	@Override
	public Iterador<User> users() throws EIException {
		if (this.users.estaBuit()) throw new EIException(Messages.NO_USERS);		
		return users.elements();
	}


	@Override
	public Bicycle getBicycle(String userId, int fromStationId, Date dateTime)
			throws EIException {
		User user = this.users.consultar(userId);
		if(user == null) throw new EIException(Messages.USER_NOT_FOUND);
		Station station = this.getStation(fromStationId, Messages.STATION_NOT_FOUND);
		if (user.hasCurrentService()) throw new EIException(Messages.USER_IS_BUSY);
	
		Bicycle bicycle = station.getBicycle();
		if (bicycle == null) throw new EIException(Messages.NO_BICYCLES);
		
		bicycle.startService(user, station, dateTime);
		station.incActivity();
		user.incActicity();
		
		if (this.mostActiveStation==null || this.mostActiveStation.activity()<station.activity()) this.mostActiveStation=station;
		if (this.mostActiveUser==null || this.mostActiveUser.activity()<user.activity()) this.mostActiveUser=user;
		
		return bicycle;
	}


	@Override
	public void returnBicycle(String bicycleId, int toStationId, Date dateTime)
			throws EIException {
		Bicycle bicycle = this.bicycles.consultar(bicycleId);
		if(bicycle == null) throw new EIException(Messages.BICYCLE_NOT_FOUND);

		Station station = this.getStation(toStationId, Messages.STATION_NOT_FOUND);
		station.addBicycle(bicycle);
		
		bicycle.finishService(station, dateTime);		
	}


	@Override
	public Iterador<Service> servicesByBicycle(String bicycleId)
			throws EIException {
		Bicycle bicycle = this.bicycles.consultar(bicycleId);
		if(bicycle == null) throw new EIException(Messages.BICYCLE_NOT_FOUND);
		Contenidor<Service> services= bicycle.services();
		
		if (services.estaBuit()) throw new EIException(Messages.NO_SERVICES);
		
		return services.elements();
	}


	@Override
	public Station mostActiveStation() throws EIException {
		if (this.mostActiveStation==null) throw new EIException(Messages.NO_STATIONS);
		return this.mostActiveStation;
	}


	@Override
	public User mostActiveUser() throws EIException {
		if (this.mostActiveUser==null) throw new EIException(Messages.NO_USERS);
		return this.mostActiveUser;
	}


	@Override
	public void addWorker(String dni, String name) {		
		Worker workerToAdd = new Worker(dni, name);
		this.workers.encuar(workerToAdd);				
	}	

	@Override
	public Iterador<Worker> workers() throws EIException {
		if (this.workers.estaBuit()) throw new EIException(Messages.NO_WORKERS);
		return workers.elements();
	}

	@Override
	public int addTicket(String bicicleId, String description, Date dateTime) throws EIException {
		Bicycle bike = this.bicycles.consultar(bicicleId);
		if(bike == null)  throw new EIException(Messages.BICYCLE_NOT_FOUND);
		
		bike.setStatus(BicycleStatus.DAMAGED);		
		
		Integer ticketId = nextTicketId();
		Ticket newTicket = new Ticket(ticketId, description, dateTime, bike);
		bike.addTicket(newTicket);
		this.tickets.afegir(ticketId, newTicket);				
		
		Station bikeStation = bike.getStation();
	    if(bikeStation != null ) {
	    	bikeStation.addTicket(bike);
	    	if (this.mostProblematicStation==null || this.mostProblematicStation.incidences()<bikeStation.incidences()) this.mostProblematicStation=bikeStation;
	    }
		return ticketId;
	}
	
	private Integer nextTicketId() {
		return this.tickets.nombreElems() + 1;
	}


	@Override
	public Iterador<Ticket> tickets() throws EIException {
		if (this.tickets.estaBuit()) throw new EIException(Messages.NO_TICKETS);
		return this.tickets.elements();
	}


	@Override
	public Worker assignTicket(int ticketId, Date dateTime) throws EIException {
		Worker workerToAssign = null;
		Ticket ticket = this.tickets.consultar(ticketId);
		if(ticket == null) throw new  EIException(Messages.TICKET_NOT_FOUND);
		
		workerToAssign = this.workers.desencuar();		
		ticket.assign(workerToAssign, dateTime);
		workerToAssign.incIncidences();
		this.workers.encuar(workerToAssign);
		return workerToAssign;
	}


	@Override
	public void resolveTicket(int ticketId, String desciption, Date dateTime) throws EIException {
		Ticket ticket = this.tickets.consultar(ticketId);
		if(ticket == null) throw new  EIException(Messages.TICKET_NOT_FOUND);		
		ticket.resolve(desciption, dateTime);	
		Bicycle bike = ticket.getBicycle();
		Station bikeStation = bike.getStation();
	    if(bikeStation != null ) {
	    	bikeStation.resolveTicket(bike);
	    }
	}


	@Override
	public Iterador<Ticket> ticketsByWorker(String workerId) throws EIException {		
		LlistaEncadenada<Ticket> workerTickets = new LlistaEncadenada<Ticket>();
		Iterador<Ticket> it = this.tickets.elements();
		while(it.hiHaSeguent()) {
			Ticket element = (Ticket) it.seguent();
			if(element.isAssignedToWorker(workerId)) {
				workerTickets.afegirAlFinal(element);
			}
		}
		if(workerTickets.estaBuit()) throw new EIException(Messages.NO_TICKETS);
		
		return workerTickets.elements();
	}

	@Override
	public Iterador<Ticket> ticketsByBicycle(String bicycleId) throws EIException {
		Bicycle bike = this.bicycles.consultar(bicycleId);
		if (bike == null) throw new EIException(Messages.BICYCLE_NOT_FOUND);		
		return bike.tickets();	
	}


	@Override
	public Station mostProblematicStation() throws EIException {
		if (this.mostProblematicStation==null) throw new EIException(Messages.NO_TICKETS);
		return this.mostProblematicStation;
	}


	@Override
	public int getNBicycles(int stationId) throws EIException {
		Station station = this.getStation(stationId, Messages.STATION_NOT_FOUND);
		int numBikes =  station.getNBicycles();
		if(numBikes <=0) throw new EIException(Messages.NO_BICYCLES);
		return numBikes;
	}


	@Override
	public int getNParkings(int stationId) throws EIException {
		Station station = this.getStation(stationId, Messages.STATION_NOT_FOUND);
		int numFreeParkings =  station.getNParkings();
		if(numFreeParkings <=0) throw new EIException(Messages.NO_PARKINGS);
		return numFreeParkings;
	}


	@Override
	public Station getClosestBike(long latitude, long longitude) throws EIException {
		Station closestStationWithBikes = null;
		Iterador<Station> it = this.stations();
		while(it.hiHaSeguent()) {
			Station element = (Station) it.seguent();
			if(closestStationWithBikes == null || element.isClosestThanAndHasBikes(latitude, longitude, closestStationWithBikes)) {
				closestStationWithBikes = element;
			}
		}
		return closestStationWithBikes;
	}


	@Override
	public Station getClosestParking(long latitude, long longitude) throws EIException {
		Station closestStationWithFreeParkings = null;
		Iterador<Station> it = this.stations();
		while(it.hiHaSeguent()) {
			Station element = (Station) it.seguent();
			if(closestStationWithFreeParkings == null || element.isClosestThanAndHasFreeParkings(latitude, longitude, closestStationWithFreeParkings)) {
				closestStationWithFreeParkings = element;
			}
		}
		return closestStationWithFreeParkings;
	}
	

}
