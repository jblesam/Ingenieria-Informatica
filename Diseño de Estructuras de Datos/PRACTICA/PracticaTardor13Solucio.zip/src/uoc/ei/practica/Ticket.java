package uoc.ei.practica;

import java.util.Date;

enum Status { NOT_ASSIGNED, ASSIGNED, SOLVED};

public class Ticket implements Comparable<Ticket>{

	private Integer ticketId;
	private String description;
	private Date dateTime;
	private Bicycle bicycle;
	private Status status;
	private Worker worker;
	
	public Ticket(Integer ticketId, String description, Date dateTime,
			Bicycle bicycle) {
		super();
		this.ticketId = ticketId;
		this.description = description;
		this.dateTime = dateTime;
		this.bicycle = bicycle;
		this.status = Status.NOT_ASSIGNED;
		this.worker = null;
	}


	@Override
	public int compareTo(Ticket o) {
		return this.ticketId.compareTo(o.ticketId);
	}
	
	
	public void assign(Worker worker, Date dateTime) {
		this.worker = worker;
		this.dateTime = dateTime;
		this.status = Status.ASSIGNED;
	}

	public void resolve(String description, Date dateTime) throws EIException {
		if(this.status != Status.ASSIGNED) throw new EIException(Messages.CANT_SOLVE_TICKET_NOT_ASSIGNED);
		this.worker = null;
		this.dateTime = dateTime;
		this.status = Status.SOLVED;
		this.description = description;
		this.bicycle.setStatus(BicycleStatus.READY);
	}
	
	
	
	public Bicycle getBicycle() {
		return bicycle;
	}	

	public boolean isAssignedToWorker(String workerId) {
		return this.status == Status.ASSIGNED && this.worker.getIdentifier().equals(workerId);
	}
	
	public boolean isAssignedToBicycle(String bicycleId) {
		return this.bicycle.getStatus() == BicycleStatus.DAMAGED && this.bicycle.getIdentifier().equals(bicycleId);
	}
   
	public String toString() {
		StringBuffer sb=new StringBuffer();
		sb.append("id: ").append(this.ticketId).append(Messages.LS);
		sb.append("description: ").append(this.description).append(Messages.LS);
		sb.append("bicycle: ").append(this.bicycle.getIdentifier()).append(Messages.LS);
		sb.append("status: ").append(this.status).append(Messages.LS);
		sb.append("dateTime: ").append(DateUtils.format(this.dateTime)).append(Messages.LS);
		if(this.worker != null) sb.append("worker: ").append(this.worker.getName()).append(Messages.LS);
		return sb.toString();		
	}

}
