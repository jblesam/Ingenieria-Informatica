import uoc.ei.tads.Iterador;
import uoc.ei.tads.LlistaEncadenada;

public class Team {
	
	private String name;
	private int wins;
	private LlistaEncadenada<Player> players=new LlistaEncadenada<Player>();
	
	public Team(String name) {
		setName(name);
	}
	
	public String getName() {
		return name;
	}
	
	private void setName(String name) {
		this.name = name;
	}
	
	public int getWins() {
		return wins;
	}
	
	public void setWins(int wins) {
		this.wins = wins;
	}	
	
	public void addPlayer(Player player) {
		players.afegirAlFinal(player);
	}	
	
	public Iterador<Player> getPlayers(){
		return players.elements();
	}
		
	public String toString() {
		return getName()+", ["+getWins()+"]";
	}
}
