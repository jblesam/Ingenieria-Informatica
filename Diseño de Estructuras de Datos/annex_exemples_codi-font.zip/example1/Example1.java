import uoc.ei.tads.Iterador;
import uoc.ei.tads.LlistaEncadenada;

public class Example1 {
	
	public static void main(String args[]){
	
	/* Inici inicialització */
		
		/* Es creen els equips */
		Team chi=new Team("Chicago Bulls");
		Team ind=new Team("Indiana Pacers");
		Team mil=new Team("Milwaukee Bucks");
		Team cle=new Team("Cleveland Cavaliers");
		Team det=new Team("Detroit Pistons");

		/* S'assignen els equips a la Central Division */
		LlistaEncadenada<Team> centralDivision = new LlistaEncadenada<Team>();
		centralDivision.afegirAlFinal(chi);
		centralDivision.afegirAlFinal(mil);
		centralDivision.afegirAlFinal(cle);
		centralDivision.afegirAlFinal(ind);
		centralDivision.afegirAlFinal(det);
		
		/* Es creen els jugadors */
		Player chi05=new Player("Carlos", "Boozer");
		Player chi01=new Player("Derrick", "Rose");
		Player chi13=new Player("Joakim", "Noah");
		Player chi09=new Player("Luol", "Deng");
		Player chi03=new Player("Omek", "Asik");
		Player cle02=new Player("Kyrie", "Irving");
		Player cle17=new Player("Anderson", "Varejao");
		Player cle04=new Player("Antawn", "Jamison");
		Player cle01=new Player("Daniel", "Gibson");
		Player cle33=new Player("Alonzo", "Gee");
		Player ind33=new Player("Danny", "Granger");
		Player ind02=new Player("Darren", "Collison");
		Player ind21=new Player("David", "West");
		Player ind17=new Player("Lou", "Amundson");
		Player ind55=new Player("Roy", "Hibbert");
		Player mil06=new Player("Andrew", "Bogut");
		Player mil00=new Player("Drew", "Gooden");
		Player mil07=new Player("Ersan", "Ilyasova");
		Player mil03=new Player("Brandon", "Jennings");
		Player mil05=new Player("Stephen", "Jackson");
		Player det08=new Player("Ben", "Gordon");
		Player det22=new Player("Tayshaun", "Prince");
		Player det07=new Player("Brandon", "Knight");
		Player det10=new Player("Greg", "Monroe");
		Player det03=new Player("Rodney", "Stuckey");
		
		/* S'assignen els jugadors als respectius equips */
		chi.addPlayer(chi05);
		chi.addPlayer(chi01);
		chi.addPlayer(chi13);
		chi.addPlayer(chi09);
		chi.addPlayer(chi03);
		cle.addPlayer(cle02);
		cle.addPlayer(cle17);
		cle.addPlayer(cle04);
		cle.addPlayer(cle01);
		cle.addPlayer(cle33);
		ind.addPlayer(ind33);
		ind.addPlayer(ind02);
		ind.addPlayer(ind21);
		ind.addPlayer(ind17);
		ind.addPlayer(ind55);	
		mil.addPlayer(mil06);
		mil.addPlayer(mil00);
		mil.addPlayer(mil07);
		mil.addPlayer(mil03);
		mil.addPlayer(mil05);
		det.addPlayer(det08);
		det.addPlayer(det22);
		det.addPlayer(det07);
		det.addPlayer(det10);
		det.addPlayer(det03);
		
		/* S'inicialitzen els partits guanyats dels equips */
		chi.setWins(33);
		mil.setWins(15);
		cle.setWins(14);
		ind.setWins(23);
		det.setWins(13);
	
	/* Fi inicialització */
	/* Inici recorreguts */
		
		/* Es mostra per pantalla els equips de la Central Division */
		System.out.println("\nEquips de la Divisió Central:\n");
		Iterador<Team> teams=centralDivision.elements();
		while (teams.hiHaSeguent()) {
			Team teamAux=teams.seguent();
			System.out.println(teamAux.toString());
		}
		
		/* Es mostra per pantalla els jugadors definits de la Central Division */
		System.out.println("\nJugadors de la Divisió Central:\n");
		teams=centralDivision.elements();
		while (teams.hiHaSeguent()) {
			Team teamAux=teams.seguent();
			Iterador<Player> players=teamAux.getPlayers();
			while (players.hiHaSeguent()) {
				Player playerAux=players.seguent();
				System.out.println(playerAux.toString());
			}
		}	
		
		/* Es mostra per pantalla els jugadors definits de la Central Division,
		 * agrupats per equip */
		System.out.println("\nJugadors per equip de la Divisió Central:\n");
		teams=centralDivision.elements();
		while (teams.hiHaSeguent()) {
			Team teamAux=teams.seguent();
			System.out.println("\n"+teamAux.getName());
			System.out.println("------------------------");
			Iterador<Player> players=teamAux.getPlayers();
			while (players.hiHaSeguent()) {
				Player playerAux=players.seguent();
				System.out.println("\t"+playerAux.toString());
			}
		}
	/* Fi recorreguts */
	}
}
