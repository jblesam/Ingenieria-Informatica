
public class SpadesCard extends Card {
	
	public SpadesCard(String nameCard){
		super(nameCard);
	}
	
	public String toString(){
		return "[♠"+this.getName()+"]";
	}
}
