import uoc.ei.tads.DiccionariVectorImpl;

public class Card implements Comparable<Card> {
	
	private static final int NUM_CARDS=13;
	private int value;
	private String name;
	private static DiccionariVectorImpl<String, Integer> dicValues = new DiccionariVectorImpl<String, Integer>(NUM_CARDS);
	
	private void init() {
		dicValues.afegir(new String("2"), new Integer(1));
		dicValues.afegir(new String("3"), new Integer(2));
		dicValues.afegir(new String("4"), new Integer(3));
		dicValues.afegir(new String("5"), new Integer(4));
		dicValues.afegir(new String("6"), new Integer(5));
		dicValues.afegir(new String("7"), new Integer(6));
		dicValues.afegir(new String("8"), new Integer(7));
		dicValues.afegir(new String("9"), new Integer(8));
		dicValues.afegir(new String("10"), new Integer(9));
		dicValues.afegir(new String("J"), new Integer(10));
		dicValues.afegir(new String("Q"), new Integer(11));
		dicValues.afegir(new String("K"), new Integer(12));
		dicValues.afegir(new String("A"), new Integer(13));
	}
	
	public Card(String nameCard) {
		init();
		setName(nameCard);
		setValue(dicValues.consultar(nameCard));
	}

	public int getValue() {
		return value;
	}

	private void setValue(int value) {
		this.value = value;
	}

	public String getName() {
		return name;
	}

	private void setName(String name) {
		this.name = name;
	}
	
	public int compareTo(Card card) {
		return this.getValue()-card.getValue();
	}
}
