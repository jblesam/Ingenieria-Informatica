
public class ClubsCard extends Card {
	
	public ClubsCard(String nameCard){
		super(nameCard);
	}
	
	public String toString(){
		return "[♣"+this.getName()+"]";
	}
}