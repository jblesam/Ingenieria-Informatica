
public class DiamondsCard extends Card {
	
	public DiamondsCard(String nameCard){
		super(nameCard);
	}
	
	public String toString(){
		return "[♦"+this.getName()+"]";
	}
}