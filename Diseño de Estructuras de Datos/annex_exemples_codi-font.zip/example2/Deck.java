import uoc.ei.tads.Cua;
import uoc.ei.tads.CuaAmbPrioritat;

public class Deck {

	private Cua<Card> cards=new CuaAmbPrioritat<Card>();
	
	public void addCard(Card card) {
		cards.encuar(card);
	}
	
	public Card getCard() {
		return cards.desencuar();
	}
	
	public int numCards() {
		return cards.nombreElems();
	}
}
