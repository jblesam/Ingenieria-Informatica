import uoc.ei.tads.Pila;
import uoc.ei.tads.PilaVectorImpl;

public class Example2 {
	
	public static void main(String args[]){
	
	/* Inici inicialització */
		
		/* Es crea la baralla de cartes de pòquer */
		Deck deck = new Deck();
		
		/* Es creen les cartes */
		Card h2=new HeartsCard("2");
		Card h3=new HeartsCard("3");
		Card hJ=new HeartsCard("J");
		Card c4=new ClubsCard("4");
		Card c6=new ClubsCard("6");
		Card sJ=new SpadesCard("J");
		Card sQ=new SpadesCard("Q");
		Card sK=new SpadesCard("K");
		Card d2=new DiamondsCard("2");
		Card dK=new DiamondsCard("K");
		Card dA=new DiamondsCard("A");
		
		/* S'afegeixen les cartes a la baralla */
		deck.addCard(h2);
		deck.addCard(sJ);
		deck.addCard(d2);
		deck.addCard(dK);
		deck.addCard(sK);
		deck.addCard(sQ);
		deck.addCard(h3);
		deck.addCard(c6);
		deck.addCard(hJ);
		deck.addCard(c4);
		deck.addCard(dA);
		
		/* Es creen quatre piles de cartes, una per cadascun dels pals
		 * de la baralla */
		Pila<ClubsCard> clubsCards=new PilaVectorImpl<ClubsCard>();
		Pila<DiamondsCard> diamondsCards=new PilaVectorImpl<DiamondsCard>();
		Pila<SpadesCard> spadesCards=new PilaVectorImpl<SpadesCard>();
		Pila<HeartsCard> heartsCards=new PilaVectorImpl<HeartsCard>();
	
	/* Fi inicialització */
	/* Inici recorreguts */
		
		/* Es mostra per pantalla cadascuna de les cartes de la baralla, 
		 * de forma ordenada. A més, en funció de la naturalesa de cada 
		 * carta, s'insereix a la pila corresponent del mateix pal
		 */
		System.out.print("Total cartes :\n\t");
		while (deck.numCards()>0) {
			Card aux=deck.getCard();
			System.out.print(aux.toString()+" ");
			if (aux instanceof ClubsCard) {
				clubsCards.empilar((ClubsCard)aux);
			} else if (aux instanceof DiamondsCard) {
				diamondsCards.empilar((DiamondsCard)aux);
			} else if (aux instanceof SpadesCard) {
				spadesCards.empilar((SpadesCard)aux);
			} else if (aux instanceof HeartsCard) {
				heartsCards.empilar((HeartsCard)aux);
			}
		}
		
		/* Es desapilen les cartes diamond i es mostren per pantalla*/
		System.out.print("\n\nDiamons desempilades :\n\t");		
		while (!diamondsCards.estaBuit()) {
			System.out.print(diamondsCards.desempilar()+" ");
		}
		
		/* Es desapilen les cartes spades i es mostren per pantalla*/
		System.out.print("\n\nSpades desempilades :\n\t");
		while (!spadesCards.estaBuit()) {
			System.out.print(spadesCards.desempilar()+" ");
		}
		
		/* Es desapilen les cartes hearts i es mostren per pantalla*/
		System.out.print("\n\nHearts desempilades :\n\t");
		while (!heartsCards.estaBuit()) {
			System.out.print(heartsCards.desempilar()+" ");
		}
		
		/* Es desapilen les cartes clubs i es mostren per pantalla*/
		System.out.print("\n\nClubs desempilades :\n\t");
		while (!clubsCards.estaBuit()) {
			System.out.print(clubsCards.desempilar()+" ");
		}
	/* Fi recorreguts */
	}
}
