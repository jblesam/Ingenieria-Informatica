
public class HeartsCard extends Card {
	
	public HeartsCard(String nameCard){
		super(nameCard);
	}
	
	public String toString(){
		return "[♥"+this.getName()+"]";
	}
}