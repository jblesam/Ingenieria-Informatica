/**
 * This class represents a Person
 * 
 * @author POO teaching staff
 * @version 1.0
 * @since Spring 2018
 */

public class Person{

   /**
    * This atribute stores the Person's name
    */
   private String name;

   /**
    * This atribute stores the Person's age
    */
   private int age;
   
   /**
    * Constructor method
    * 
    * @param name
    *            the Person's name
    * @param age
    *            the Person's age
    */

   public Person(String name, int age) {
      this.name = name;
      this.age = age;
   }

   /**
    * Getter method of atribute name
    * @return atribute name
    */
   public String getName() {
      return this.name;
   }

   /**
    * Getter method of atribute age
    * @return atribute age
    */
   public int getAge() {
      return this.age;
   }

}
