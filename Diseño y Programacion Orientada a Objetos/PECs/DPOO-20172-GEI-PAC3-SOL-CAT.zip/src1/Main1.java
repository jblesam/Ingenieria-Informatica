/**
 * Test class of Exercise 1
 * 
 * @author POO teaching staff
 * @version 1.0
 * @since Spring 2018
 */

public class Main1{
   
   private static final int N = 5;  // dimension of array

   // This method finds and returns the name of the youngest
   // person in the array persons:
   private static String getNameOfYoungestPerson(Person[] persons) {
      int indexYoungest=0;
      for (int cont=1; cont<persons.length; cont++) {
         if (persons[cont].getAge() < persons[indexYoungest].getAge())
            indexYoungest = cont;
         }
      return (persons[indexYoungest].getName());
   }

   public static void main(String[] args) {

      Person[] persons;
      persons = new Person[N];

      Person p1 = new Person("Marta",38);
      Person p2 = new Person("Juan",23);
      Person p3 = new Person("Pedro",41);
      Person p4 = new Person("Claudia",6);
      Person p5 = new Person("Angel",28);
      
      persons[0]=p1;
      persons[1]=p2;
      persons[2]=p3;
      persons[3]=p4;
      persons[4]=p5;

      System.out.println("The youngest person is called " + getNameOfYoungestPerson(persons));

   }

}