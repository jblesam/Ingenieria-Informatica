/**
 * 
 * @author DPOO
 *
 */
import java.util.Vector;

public class Car extends Vehicle {
//attributes
    public Engine  myEngine;

}