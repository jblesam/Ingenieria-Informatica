/**
 * 
 * @author DPOO
 *
 */
public interface Iboat {
}