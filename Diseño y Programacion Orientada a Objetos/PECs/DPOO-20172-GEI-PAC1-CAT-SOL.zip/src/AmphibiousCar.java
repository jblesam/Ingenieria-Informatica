
/**
 * 
 * @author DPOO
 *
 */
import java.util.Vector;

public class AmphibiousCar extends Car implements Iboat {
//attributes
    public Engine myEngine;
    public Boat myBoat;
}