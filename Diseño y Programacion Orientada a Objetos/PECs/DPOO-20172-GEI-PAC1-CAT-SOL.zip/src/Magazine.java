
/**
 * 
 * @author DPOO
 *
 */
import java.util.Vector;

public class Magazine {
//attributes

    public Integer price;
    public String name;
    public Integer number;
    public Vector score;
    public Score myScore;

    /**
     * Getter method
     * @return 
     */
    public Integer getPrice() {
        return null;
    }

    /**
     * Setter method
     * @param p price
     */
    public void setPrice(Integer p) {
    }

    /**
     * Getter method
     * @return name
     */
    public String getName() {
        return null;
    }

    /**
     * Setter method
     * @param n name
     */
    public void SetName(String n) {
    }

    /**
     * Getter method
     * @return number
     */
    public Integer getNumber() {
        return null;
    }

    /**
     * Setter method
     * @param n number
     */
    public void setNumber(Integer n) {
    }
}