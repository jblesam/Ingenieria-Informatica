
/**
 * 
 * @author DPOO
 *
 */
import java.util.Date;
import java.util.Vector;

public class Score {
//attributes

    public Date when;
    public Integer score;
    public Integer newAttr;
    public Vector myVehicle;
    public Vector myMagazine;

    /**
     * Getter method
     * @return when
     */
    public Date getWhen() {
        return null;
    }

    /**
     * Getter method
     * @return score
     */
    public Integer getScore() {
        return null;
    }
}