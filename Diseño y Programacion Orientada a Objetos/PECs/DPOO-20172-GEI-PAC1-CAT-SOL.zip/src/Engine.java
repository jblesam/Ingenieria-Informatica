
/**
 * 
 * @author DPOO
 *
 */
import java.util.Vector;

public class Engine {
//attributes

    public String type;
    public Vector myBus;
    public Vector myCar;
    public Vector myAmphibiousCar;
    public Vector myBoat;

    /**
     * Getter method
     * @return type of Engine
     */
    public String getType() {
        return null;
    }

    /**
     * Setter method
     * @param t type of Engine
     */
    public void setType(String t) {
    }
}