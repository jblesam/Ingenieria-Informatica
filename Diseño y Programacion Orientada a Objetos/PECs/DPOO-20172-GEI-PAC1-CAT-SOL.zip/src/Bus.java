
/**
 * 
 * @author DPOO
 *
 */
import java.util.Vector;

public class Bus {

    //attributes
    public Integer seats;
    public Engine myEngine;

    /**
     * Getter method
     * @return number of seats
     */
    public Integer getSeats() {
        return null;
    }
    /**
     * Setter method
     * @param number of seats 
     */
    public void setSeats(Integer s) {
       
    }
}