/**
 * 
 * @author DPOO
 *
 */
import java.util.Vector;

public class Vehicle {

    //attributes
    public String name;
    public Integer price;
    public Vector score;
    public Score myScore;

    /**
     * Getter method
     * @return price
     */
    public Integer getPrice() {
        return null;
    }

    /**
     * Getter method
     * @return name
     */
    public String getname() {
        return null;
    }

    /**
     * Setter method
     * @param s name
     */
    public void setname(String s) {
    }

    /**
     * Setter method
     * @param p price
     */
    public void setprice(Integer p) {
    }
}