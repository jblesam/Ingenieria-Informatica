/**
 * 
 * @author DPOO
 *
 */
public class Boat {
    
}
