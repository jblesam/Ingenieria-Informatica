/**
 * @author OOP
 */
import java.util.Vector;

public class Mortgage {

  private String id;

  private double initialAmount;

  private double annualInterestPercentage;

  private double annualInterestRate;

  private double monthlyInterestRate;

  private int annualDuration;

  private int monthlyDuration;

  private double quota;

  private double pendingAmount;

  private int numAmortizedPeriods;
 
    /**
   * 
   * @element-type BankAccount
   */
    public BankAccount myBankAccount;
    
  public Mortgage(String id, double annualInterestPercentage, double initial, int years, BankAccount account) {
	  this.id=id;
	  this.annualInterestPercentage=annualInterestPercentage;
	  annualInterestRate=annualInterestPercentage/100.0;
	  monthlyInterestRate=annualInterestRate/12;
	  initialAmount=initial;
	  pendingAmount=initialAmount;
	  annualDuration=years;
	  monthlyDuration=years*12;
	  calculateQuota();
	  myBankAccount=account;
  }
 
  public double calculateInterest(int period) {
	  double pow=Math.pow(1+monthlyInterestRate, monthlyDuration-period+1);
	  return Math.round(100.0*quota*(1.0-1.0/pow))/100.0;
  }

  public double calculateAmortization(int period) {
	  double pow=Math.pow(1+monthlyInterestRate, monthlyDuration-period+1);
	  return Math.round(100.0*quota/pow)/100.0;
  }

  public void calculateQuota() {
	  double pow=Math.pow(1+monthlyInterestRate, monthlyDuration);
	  quota=(double)initialAmount/((pow-1)/(monthlyInterestRate*pow));
  }

  public void setAmortizationPeriod(int period) {
	  numAmortizedPeriods=period;
	  double amort=0.0;
	  for (int i=1;i<=period;i++) 
		  amort+=calculateAmortization(period);
	  pendingAmount-=amort;
  }

  public void amortize(int period) {
	  setAmortizationPeriod(period);
	  myBankAccount.setBalance(myBankAccount.getBalance()-quota);
  }
  
  public double getQuota() {
        return Math.round ( 100.0 * quota ) / 100.0;
    }

  public String generateQuotes(int number) {
	  StringBuffer sb=new StringBuffer("Mortgage simulation "+id+System.getProperty("line.separator"));
	  sb.append("amount "+initialAmount+" € "+System.getProperty("line.separator"));
	  sb.append("fixedInterest "+annualInterestPercentage+"% and duration "+annualDuration+" years "+System.getProperty("line.separator"));
	  Client head=myBankAccount.getClient();
	  if (head!=null)
		  sb.append(head+System.getProperty("line.separator"));
	  for (int i=1;i<=number;i++) {
		  sb.append("Quota period "+i+"..."+getQuota()+" = "+calculateAmortization(i)+" (amortization)+" + " + "+calculateInterest(i)+ " (interest)"+System.getProperty("line.separator"));
	  }  
	  return sb.toString();		
  }
  
  public double getPendingAmount() {
	  return Math.round(100.0*pendingAmount)/100.0;
  }

  public int getMonthlyDuration() {
	  return monthlyDuration;
  }
  
  public int getNumberAmortizedPeriods(){
	  return numAmortizedPeriods;
  }
}
