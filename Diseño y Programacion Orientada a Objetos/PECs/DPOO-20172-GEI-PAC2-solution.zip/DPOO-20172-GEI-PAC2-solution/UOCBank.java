/**
 * @author OOP
 */
import java.util.Vector;

public class UOCBank {
    /**
   * 
   * @element-type Mortgage
   */
    public Vector myMortgage;
   /**
   * 
   * @element-type Client
   */ 
    public Vector  myClient;
   /**
   * 
   * @element-type BankAccount
   */
    public Vector  myBankAccount;
  
  public UOCBank() {
    myMortgage=new Vector();
    myBankAccount=new Vector();
    myClient=new Vector();
  }
    
  public void addClient(Client c) {
	myClient.add(c);			
  }

  public void addBankAccount(BankAccount b) {
	myBankAccount.add(b);
  }

  public void addMortgage(Mortgage m) {
	myMortgage.add(m);
  }

}
