/**
 * @author OOP
 */
import java.util.Vector;

public class BankAccount {

  private String iban;

  private double balance;

  private Client myClient;  
  
  private Vector myMortgage;
  
  public BankAccount(String iban, double balance, Client bankHolder) {
	  this.iban=iban;
	  this.balance=balance;
	  myClient=bankHolder;
	  this.myMortgage=new Vector();
	  
  }
  public boolean addMortgage(Mortgage mortgage) {
	  return myMortgage.add(mortgage);
  }
  
  public double getBalance() {
	  return Math.round(100.0*balance)/100.0;
  }

  public void setBalance(double d) {
	  balance=d;
  }
  
  public Client getClient() {
	  return myClient;
  }
  
  public String getIban() {
	  return iban;
  }
}