/**
 * @author OOP
 */

import java.util.Vector;

public class Client {

  private String nif;

  private String firstName;

  private String lastName;
    /**
   * 
   * @element-type BankAccount
   */
  public Vector  myBankAccount;
  
  public Client (String nif, String firstName, String lastName) {
	  	this.nif=nif;
	  	this.firstName=firstName;
	  	this.lastName=lastName;
		this.myBankAccount=new Vector();
  }
    
  public String getNif() {
	  return nif;
  }
  
  public String getFirstName() {
	  return firstName;
  }
  
  public String getLastName() {
	  return lastName;
  }

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Client [nif="+this.getNif()+", firstName=" + this.getFirstName() + ", lastName=" + this.getLastName()+ "]";
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Client other = (Client) obj;
		if (nif == null) {
			if (other.getNif() != null)
				return false;
		} else if (!nif.equals(other.getNif()))
			return false;		
		return true;
	}

   public boolean addAccount(BankAccount account) {
	  return myBankAccount.add(account);

  }

}
