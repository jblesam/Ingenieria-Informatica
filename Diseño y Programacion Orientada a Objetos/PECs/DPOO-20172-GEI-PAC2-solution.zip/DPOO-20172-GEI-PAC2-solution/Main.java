/**
 * @author OOP
 */
public class Main {

    public static void main(String args[]) {
        UOCBank myBank = new UOCBank();
        Client oneClient = new Client("31309876-R", "Julia", "Roberts");
        Client otherClient = new Client("28376749-F", "Dorian", "Grey");

        myBank.addClient(oneClient);
        myBank.addClient(otherClient);

        BankAccount oneBankAccount = new BankAccount("1024-9843-45-8376542567", 1800.0, oneClient);
        BankAccount otherBankAccount = new BankAccount("1024-4978-57-763940586", 2400.0, otherClient);

        myBank.addBankAccount(oneBankAccount);
        myBank.addBankAccount(otherBankAccount);

        Mortgage oneMortgageFlat = new Mortgage("1024-4567-34-03984766654",3.1,130000.0,30,oneBankAccount);
        myBank.addMortgage(oneMortgageFlat);
        System.out.println(oneMortgageFlat.generateQuotes(36));
        
        System.out.println("BankAccount Balance "+ oneBankAccount.getIban() );
        System.out.println("before amortize: "+ oneBankAccount.getBalance()+" €" );
        oneMortgageFlat.amortize(1);
        System.out.println("BankAccount Balance "+ oneBankAccount.getIban() );
        System.out.println("after amortize: "+ oneBankAccount.getBalance()+" €" );
        
        System.out.println("Mortgage Status: ");
        System.out.println("   Pending amount: "+oneMortgageFlat.getPendingAmount()+" €");
        System.out.println("   Pending quota: "+ (oneMortgageFlat.getMonthlyDuration()-oneMortgageFlat.getNumberAmortizedPeriods())+" months");


    }

}
