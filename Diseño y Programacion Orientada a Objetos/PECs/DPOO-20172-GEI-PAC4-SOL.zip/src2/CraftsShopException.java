/**
 * This class defines the exception causes expected
 * 
 * @author POO teaching staff
 * @version 1.0
 * @since Spring 2018
 */

public class CraftsShopException extends Exception {

   /** Defined errors */

   public static final String INCORRECT_MATERIAL = "Incorrect material: negative value of Price/m2. It has not been added. ";

   public static final String REPEATED_PRODUCT = "Repeated Product. It has not been added.";

   public static final String ORDER_NOT_FOUND = "Order not found. Impossible to remove.";

   /**
    * Constructor method
    */
   public CraftsShopException (String errorMessage) {
      super (errorMessage);
   } 

}
