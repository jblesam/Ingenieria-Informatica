import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.text.DecimalFormat;

/**
 * Test class of PAC 4 - Exercise 2
 * 
 * @author POO teaching staff
 * @version 1.0
 * @since Spring 2018
 */

public class Main2{

   // The new line separator:
   private static final String NL = System.getProperty("line.separator");

   // Declaring a CraftsShop object:
   CraftsShop myCS;

   /**
    * main method.
    * 
    * @param args
    * @throws ParseException
    */
   public static void main(String[] args) throws ParseException {

      // Making the instance of CraftsShop:
      CraftsShop myCS = new CraftsShop();

      // ***************************************************
      //   STEP 1 (Creating and listing Materials)
      // ***************************************************

      // Creating some Material objects and adding them into
      // its corresponding list:

      // Successful cases:

      Material mSilver = new Material("Silver",4480.0);
      Material mWood = new Material("Wood",570.0);
      Material mPlastic = new Material("Plastic",350.0);

      //Error case (negative value of Price/m2):

	 Material mGold = new Material("Gold",-1218.5);

      try {      
	    myCS.add(mSilver);
	    myCS.add(mWood);
	    myCS.add(mPlastic);
	    myCS.add(mGold); // <-- error case
	 }
	 catch (CraftsShopException e) {
         System.out.println("Exception: " + e);
      }


	 // Printing material's information:
      System.out.println("********************************");
      System.out.println("       OUTPUT OF STEP 1");
      System.out.println("********************************");
      System.out.println("List of materials (in the order they were introduced)");
      System.out.println("-----------------------------------------------------");
      System.out.println(myCS.listOfMaterials());

      // ***************************************************
      //   STEP 2 (Creating and listing Products)
      // ***************************************************

      // Creating some Product objects and adding them into
      // its corresponding list:

      // Successful cases:

      CircleP pCircle1 = new CircleP("C01",mSilver,4.5);
      CircleP pCircle2 = new CircleP("C02",mSilver,3.5);
	 RectangleP pRectangle1 = new RectangleP("R01",mSilver,3.5,7.5);

      // Error case (repeated product):

RectangleP pRepeated = new RectangleP("R01",mSilver,3.5,7.5);

      try {
         myCS.add(pCircle1);
         myCS.add(pCircle2);
         myCS.add(pRectangle1);
         myCS.add(pRepeated);
      }
      catch (CraftsShopException e) {
         System.out.println("Exception: " + e);
      }

	 // Printing product's information:
      System.out.println("********************************");
      System.out.println("       OUTPUT OF STEP 2");
      System.out.println("********************************");
      System.out.println("List of products (in the order they were introduced)");
      System.out.println("----------------------------------------------------");
      System.out.println(myCS.listOfProducts());

      // ***************************************************
      //   STEP 3 (Creating and listing Orders)
      // ***************************************************

      SimpleDateFormat d = new SimpleDateFormat("dd-MM-yy");

      // Creating some Order objects and adding them into
      // its corresponding list:
      Order o1 = new Order("O001",d.parse("22-03-2018"),100,pCircle1);
      Order o2 = new Order("O002",d.parse("23-03-2018"),150,pCircle2);
      Order o3 = new Order("O003",d.parse("25-03-2018"),50,pRectangle1);
      myCS.add (o1);
      myCS.add (o2);
      myCS.add (o3);

	 // Printing order's information:
      System.out.println("********************************");
      System.out.println("       OUTPUT OF STEP 3");
      System.out.println("********************************");
      System.out.println("List of orders (in the order they were introduced)");
      System.out.println("--------------------------------------------------");
      System.out.println(myCS.listOfOrders());

      // ***************************************************
      //   STEP 4 (Removing Orders)
      // ***************************************************

      System.out.println("********************************");
      System.out.println("       OUTPUT OF STEP 4");
      System.out.println("********************************");
      
      // -- SUCCESSFUL case --

      // Removing an Order object included in the list orders
      // (corresponding to Ref = "O002")

      Order targetOrder = o2;
      System.out.println("Trying to remove Order object with Ref = " + targetOrder.getRef());
      try {
         myCS.removeOrder(targetOrder);
         System.out.println("Order object has been removed");
      }
      catch (CraftsShopException e) {
         System.out.println("Exception: " + e);
      }

      // Listing the remaining Order objects at list orders
      System.out.println("List of remaining orders (in order of introduction)");
      System.out.println("---------------------------------------------------");
      System.out.println(myCS.listOfOrders());

      // -- ERROR case --

      // Trying to remove an Order object that does not
      // exist in the list orders
      // (the same object which was previously removed)

      System.out.println("Trying to remove Order object with Ref = " + targetOrder.getRef());
      try {
         myCS.removeOrder(targetOrder);
         System.out.println("Order object has been removed");
      }
      catch (CraftsShopException e) {
         System.out.println("Exception: " + e);
      }

   }

}
