import java.util.Comparator;

/**
 * Comparator class of Order objects.
 *
 * @author POO teaching staff
 * @version 1.0
 * @since Spring 2018
 */

public class SortOrdersByDate implements Comparator<Order> {
	
	public int compare(Order o1, Order o2) {

		return o1.getDate().compareTo(o2.getDate());
	}
		
}