package edu.uoc.dpoo.tracker;

import java.util.Date;

public class Message {

    private int contractId;
    private Date createdAt;
    private Date readAt;
    private MessageType type;

    public Message(int contractId, MessageType type) {
        this.contractId = contractId;
        this.type = type;
        this.createdAt = new Date();
        this.readAt = null;
    }

    public int getContractId() {
        return contractId;
    }

    public void setContractId(int contractId) {
        this.contractId = contractId;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Date getReadAt() {
        return readAt;
    }

    public void setReadAt(Date readAt) {
        this.readAt = readAt;
    }

    public MessageType getType() {
        return type;
    }

    public void setType(MessageType type) {
        this.type = type;
    }
    
    public void read() {
        /* PR1 EX 3 */
        this.readAt = new Date();
    }
    
    public boolean isUnreaded() {
        /* PR1 EX 3 */
        return this.readAt == null;
    }
}
