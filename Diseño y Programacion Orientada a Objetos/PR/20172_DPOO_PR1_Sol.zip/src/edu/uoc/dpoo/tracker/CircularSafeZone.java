package edu.uoc.dpoo.tracker;

public class CircularSafeZone extends SafeZone {

    private float radius;

    public CircularSafeZone(float radius, String description, SafeZoneType type, Coordinate center) {
        super(description, type, center);
        this.radius = radius;
    }

    @Override
    public boolean contains(Coordinate c) {
        return false;
    }

    public float getRadius() {
        return radius;
    }

    public void setRadius(float radius) {
        this.radius = radius;
    }    
}
