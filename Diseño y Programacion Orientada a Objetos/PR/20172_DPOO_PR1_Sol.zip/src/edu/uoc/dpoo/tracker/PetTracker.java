package edu.uoc.dpoo.tracker;

import java.util.ArrayList;
import java.util.List;
import java.util.Date;

public class PetTracker {

    private List<Pet> devices;
    private List<SafeZone> safeZones;
    private List<Message> messages;

    public PetTracker() {
        this.devices = new ArrayList<Pet>();
        this.safeZones = new ArrayList<SafeZone>();
        this.messages = new ArrayList<Message>();
    }

    public List<Pet> getDevices() {
        return devices;
    }

    public void setDevices(List<Pet> devices) {
        this.devices = devices;
    }

    public List<SafeZone> getSafeZones() {
        return safeZones;
    }

    public void setSafeZones(List<SafeZone> safeZones) {
        this.safeZones = safeZones;
    }

    public List<Message> getMessages() {
        return messages;
    }

    public void setMessages(List<Message> messages) {
        this.messages = messages;
    }   
    
    public void newPosition(int serial, float lat, float lon, Date timestamp) {
    }

    public void addContract(int contractId, Date start, Date end, String petName, boolean allowFriends) {
        /* PR1 EX 2 */
        if(this.getContract(contractId)==null) {
            Pet new_device = new Pet(petName, this, contractId, start, end, allowFriends);
            this.devices.add(new_device);
        }
    }
    
    public Contract getContract(int contractId) {
        /* PR1 EX 2 */
        Pet device = this.getClientDevice(contractId);
        if(device!=null) {
            return device.getContract();
        }
        return null;
    }

    public void delContract(int contractId) {
        /* PR1 EX 2 */
        Pet device = this.getClientDevice(contractId);
        if(device!=null) {
            this.devices.remove(device);
            this.removeMessages(contractId);
        }
    }

    public void extendContract(int contractId, Date end) {
    }

    public List<Pet> findFriends(int contractId, float maxDistance) {
        return null;
    }

    public void sendMessage(int contractId, MessageType type) {
        /* PR1 EX 3 */
        Pet device = this.getClientDevice(contractId);
        if(device!=null) {
            Message m = new Message(contractId, type);
            this.messages.add(m);
        }
    }

    public void linkDevice(int contractId, int serial) {
        /* PR1 EX 2 */
        Pet device = this.getClientDevice(contractId);
        if(device!=null) {
            device.setSerial(serial);
        }
    }

    public void newSquareSafeZone(SafeZoneType type, String description, float centerLat, float centerLon, float size) {
    }

    public void newCircularSafeZone(SafeZoneType type, String description, float centerLat, float centerLon, float radius) {
    }

    public Pet getClientDevice(int contractId) {
        /* PR1 EX 2 */        
        for(Pet p:this.devices) {
            if (p.getContract().getContractId()==contractId) {
                return p;
            }            
        }        
        return null;
    }
    
    public List<Pet> getActiveDevices() {
        return null;
    }
    
    private void removeMessages(int contractId) {
        /* Utility method for PR1 EX 2*/
        List<Message> contractMessages = new ArrayList<Message>();
        
        // Get all messages for this contract
        for(Message m:this.messages) {
            if(m.getContractId()==contractId){
                contractMessages.add(m);
            }
        }
        
        // Delete the messages from the list
        for(Message m:contractMessages) {
            this.messages.remove(m);
        }
    }

}
