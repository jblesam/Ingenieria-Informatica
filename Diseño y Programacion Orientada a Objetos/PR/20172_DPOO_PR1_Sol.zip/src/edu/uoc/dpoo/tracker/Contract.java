package edu.uoc.dpoo.tracker;

import java.util.Date;

public class Contract {
    private int contractId;
    private Date start;
    private Date end;
    private boolean allowFriends;

    public Contract(int contractId, Date start, Date end, boolean allowFriends) {
        this.contractId = contractId;
        this.start = start;
        this.end = end;
        this.allowFriends = allowFriends;
    }

    public int getContractId() {
        return contractId;
    }

    public void setContractId(int contractId) {
        this.contractId = contractId;
    }

    public Date getStart() {
        return start;
    }

    public void setStart(Date start) {
        this.start = start;
    }

    public Date getEnd() {
        return end;
    }

    public void setEnd(Date end) {
        this.end = end;
    }

    public boolean getAllowFriends() {
        return allowFriends;
    }

    public void setAllowFriends(boolean allowFriends) {
        this.allowFriends = allowFriends;
    }            
}
