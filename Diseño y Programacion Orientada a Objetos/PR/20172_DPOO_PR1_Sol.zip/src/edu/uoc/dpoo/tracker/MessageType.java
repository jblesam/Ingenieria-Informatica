package edu.uoc.dpoo.tracker;

public enum MessageType {
    ENTER_SAFE_ZONE,
    LEFT_SAFE_ZONE,
    FRIEND_NEAR,
    SIGNAL_LOST;
}
