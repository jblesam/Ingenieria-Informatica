package edu.uoc.dpoo.tracker;

public class SquareSafeZone extends SafeZone {

    private float size;

    public SquareSafeZone(float size, String description, SafeZoneType type, Coordinate center) {
        super(description, type, center);
        this.size = size;
    }

    public float getSize() {
        return size;
    }

    public void setSize(float size) {
        this.size = size;
    }
    
    @Override
    public boolean contains(Coordinate c) {
        return false;
    }

}
