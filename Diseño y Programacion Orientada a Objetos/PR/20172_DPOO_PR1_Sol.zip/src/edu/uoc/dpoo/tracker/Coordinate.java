package edu.uoc.dpoo.tracker;

import java.util.Date;

public class Coordinate {

    private float latitude;
    private float longitude;
    private Date timestamp;

    public float distanceTo(Coordinate c) {
        return 0.0f;
    }
}
