package edu.uoc.dpoo.tracker;

import java.util.ArrayList;
import java.util.List;
import java.util.Date;

public class Pet {

    private String name;
    private int serial;
    private Coordinate lastPosition;
    private List<Coordinate> historic;
    private PetTracker tracker;
    private Contract contract;

    public Pet(String name, PetTracker tracker, int contractId, Date start, Date end, boolean allowFriends) {
        this.name = name;
        this.tracker = tracker;
        this.serial = -1;
        this.lastPosition = null;
        this.historic = new ArrayList<Coordinate>();
        this.contract = new Contract(contractId, start, end, allowFriends);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getSerial() {
        return serial;
    }

    public void setSerial(int serial) {
        this.serial = serial;
    }

    public Coordinate getLastPosition() {
        return lastPosition;
    }

    public void setLastPosition(Coordinate lastPosition) {
        this.lastPosition = lastPosition;
    }

    public List<Coordinate> getHistoric() {
        return historic;
    }

    public void setHistoric(List<Coordinate> historic) {
        this.historic = historic;
    }

    public PetTracker getTracker() {
        return tracker;
    }

    public void setTracker(PetTracker tracker) {
        this.tracker = tracker;
    }

    public Contract getContract() {
        return contract;
    }

    public void setContract(Contract contract) {
        this.contract = contract;
    }   

    public void newPosition(Coordinate c) {
    }

    public boolean inSafeZone() {
        return false;
    }

    public List<Coordinate> getTrack(Date start, Date end) {
        return null;
    }

    public float getDistance(Date start, Date end) {
        return 0.0f;
    }

    public int elapsedTime() {
        return 0;
    }

    public List<Message> getUnreadMessages() {
        /* PR1 EX 3 */
        List<Message> messages = new ArrayList<Message>();
        for(Message msg:this.tracker.getMessages()) {
            if (msg.getContractId() == this.contract.getContractId() && msg.isUnreaded()) {
                messages.add(msg);
            }
        }
        return messages;
    }
}
