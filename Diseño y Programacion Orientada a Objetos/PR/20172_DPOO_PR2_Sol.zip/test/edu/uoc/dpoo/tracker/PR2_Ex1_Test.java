package edu.uoc.dpoo.tracker;

import java.util.Date;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class PR2_Ex1_Test {
    
    private final String pet1_name = "pet1";
    private final int pet1_serial = 1;
    private final int pet1_contractId = 25;
    private final boolean pet1_allowFriends = true;
    private final Date pet1_start = new Date();
    private final Date pet1_end = new Date();   
    private final String pet2_name = "pet2";
    private final int pet2_serial = 45;
    private final int pet2_contractId = 70;
    private final boolean pet2_allowFriends = false;
    private final Date pet2_start = new Date();
    private final Date pet2_end = new Date();   
        
    public PR2_Ex1_Test() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }  
    
    @Test
    public void addContractNegID() {
        PetTracker tracker = new PetTracker();
        
        // Check that initially the list of pets is empty
        assertNotNull(tracker.getDevices());
        assertEquals(0, (int)tracker.getDevices().size());
                
        try {
            // Add again the same contract (repeated contractId)        
            tracker.addContract(-3, pet1_start, pet1_end, pet1_name, pet1_allowFriends);
            fail();
        } catch (Throwable t){
            if(!(t instanceof TrackerException)) {
                fail();
            }
        }
        
        // Check that initially the list of pets is empty
        assertNotNull(tracker.getDevices());
        assertEquals(0, (int)tracker.getDevices().size());
        
    }      
    
    @Test
    public void addContractRepeated() {
        PetTracker tracker = new PetTracker();
        
        // Check that initially the list of pets is empty
        assertNotNull(tracker.getDevices());
        assertEquals(0, (int)tracker.getDevices().size());
        
        try {
            // Add a new contract
            tracker.addContract(pet1_contractId, pet1_start, pet1_end, pet1_name, pet1_allowFriends);            
        } catch (Throwable t) {            
            fail();            
        }        
        
        // Check that the list of pets have one element
        assertNotNull(tracker.getDevices());
        assertEquals(1, (int)tracker.getDevices().size());
        
        try {
            // Add again the same contract (repeated contractId)        
            tracker.addContract(pet1_contractId, pet1_start, pet1_end, pet1_name, pet1_allowFriends);
            fail();
        } catch (Throwable t){
            if(!(t instanceof TrackerException)) {
                fail();
            }
        }
        
        // Check that the list of pets have one element
        assertNotNull(tracker.getDevices());
        assertEquals(1, (int)tracker.getDevices().size());
    }      
    
    @Test
    public void delNotExistingContract() {
        PetTracker tracker = new PetTracker();
        
        // Check that initially the list of pets is empty
        assertNotNull(tracker.getDevices());
        assertEquals(0, (int)tracker.getDevices().size());       
        
        try {
            // Delete the contract
            tracker.delContract(pet1_contractId);
            fail();
        } catch (Throwable t){
            if(!(t instanceof TrackerException)) {
                fail();
            }
        }        
        assertEquals(0, (int)tracker.getDevices().size());
        assertNull(tracker.getClientDevice(pet1_contractId));
        assertNull(tracker.getContract(pet1_contractId));        
    }    
    
    @Test
    public void linkDeviceInvalidContract() {
        PetTracker tracker = new PetTracker();
        
        // Check that initially the list of pets is empty
        assertNotNull(tracker.getDevices());
        assertEquals(0, (int)tracker.getDevices().size());
                
        try {
            // Link the device        
            tracker.linkDevice(pet1_contractId, pet1_serial);
            fail();
        } catch (Throwable t){
            if(!(t instanceof TrackerException)) {
                fail();
            }
        }
    }  
    
    @Test
    public void linkDeviceNegSerial() {
        PetTracker tracker = new PetTracker();
        
        // Check that initially the list of pets is empty
        assertNotNull(tracker.getDevices());
        assertEquals(0, (int)tracker.getDevices().size());
        
        try {
            // Add a new contract
            tracker.addContract(pet1_contractId, pet1_start, pet1_end, pet1_name, pet1_allowFriends);
        } catch (Throwable t) {            
            fail();            
        }  
        
        // Request the device
        Pet d1 = tracker.getClientDevice(pet1_contractId);        
        assertNotNull(d1);
        
        // Check device initialization
        assertEquals(-1, d1.getSerial());
        
        try {
            // Link the device        
            tracker.linkDevice(pet1_contractId, -54);
            fail();
        } catch (Throwable t){            
            if(!(t instanceof TrackerException)) {
                fail();
            }          
        }
    }  
    
    @Test
    public void linkDeviceDupSerial() {
        PetTracker tracker = new PetTracker();
        
        // Check that initially the list of pets is empty
        assertNotNull(tracker.getDevices());
        assertEquals(0, (int)tracker.getDevices().size());
        
        try {
            // Add a new contract
            tracker.addContract(pet1_contractId, pet1_start, pet1_end, pet1_name, pet1_allowFriends);
        } catch (Throwable t) {            
            fail();            
        } 
        
        try {
            // Add a new contract
            tracker.addContract(pet2_contractId, pet2_start, pet2_end, pet2_name, pet2_allowFriends);
        } catch (Throwable t) {            
            fail();            
        } 
        
        // Request the device
        Pet d1 = tracker.getClientDevice(pet1_contractId);        
        assertNotNull(d1);
        
        // Check device initialization
        assertEquals(-1, d1.getSerial());
        
        try {
            // Link the device        
            tracker.linkDevice(pet1_contractId, pet1_serial);
            assertEquals(pet1_serial, d1.getSerial());
        } catch (Throwable t){            
            fail();            
        }
        
        // Request the device
        Pet d2 = tracker.getClientDevice(pet2_contractId);        
        assertNotNull(d2);
        
        // Check device initialization
        assertEquals(-1, d2.getSerial());
        
        try {
            // Link the device again
            tracker.linkDevice(pet2_contractId, pet1_serial);
            fail();
        } catch (Throwable t){
            if(!(t instanceof TrackerException)) {
                fail();
            }
        }
    }    
    
    
    @Test
    public void sendMessageInvalidContract() {
        PetTracker tracker = new PetTracker();
        
        // Check that initially the list of messages is empty
        assertNotNull(tracker.getMessages());
        assertEquals(0, (int)tracker.getMessages().size());
        
        try {
            // Send a message        
            tracker.sendMessage(pet1_contractId, MessageType.FRIEND_NEAR);
            fail();
        } catch (Throwable t) {            
            if(!(t instanceof TrackerException)) {
                fail();
            }            
        }
                
        assertNotNull(tracker.getMessages());
        assertEquals(0, (int)tracker.getMessages().size());        
    }
}
