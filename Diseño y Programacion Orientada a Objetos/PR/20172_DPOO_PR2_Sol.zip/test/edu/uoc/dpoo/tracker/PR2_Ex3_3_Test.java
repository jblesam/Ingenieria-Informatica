package edu.uoc.dpoo.tracker;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class PR2_Ex3_3_Test {
    
    private PetTracker tracker = null;
            
    private final int pet1_serial = 1;
    private final int pet1_contractId = 25;        
    
    private final float c1_lat = 41.4065249f;
    private final float c1_lon = 2.1945029f;
        
    public PR2_Ex3_3_Test() {
        tracker = new PetTracker();
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        tracker = new PetTracker();
        
        Calendar cal = Calendar.getInstance();        
        cal.add(Calendar.DATE, -2 );
        Date date_min2 = cal.getTime();   
        
        cal = Calendar.getInstance();        
        cal.add(Calendar.DATE, 2 );
        Date date_plus2 = cal.getTime();
        
        // Check that initially the list of pets is empty
        assertNotNull(tracker.getDevices());
        assertEquals((int)tracker.getDevices().size(), 0);
                
        try {
            // Add active contract
            tracker.addContract(pet1_contractId, date_min2, date_plus2, "pet 1", true);
                                    
            // Link devices
            tracker.linkDevice(pet1_contractId, pet1_serial);            
        } catch (Throwable t) {            
            fail();            
        }     
        
        // Check the list of pets
        assertNotNull(tracker.getDevices());
        assertEquals(1, (int)tracker.getDevices().size());       
    }
    
    @After
    public void tearDown() {
        tracker = null;
    }  
            
    @Test
    public void checkPetInSafeZone() {
        
        assertNotNull(tracker.getSafeZones());
        assertEquals(0, tracker.getSafeZones().size());
        
        tracker.newCircularSafeZone(SafeZoneType.PARK, "Awesome Park", c1_lat, c1_lon, 100);
        
        assertNotNull(tracker.getSafeZones());
        assertEquals(1, tracker.getSafeZones().size());        
        
        assertTrue(tracker.getSafeZones().get(0) instanceof CircularSafeZone);
        
        SafeZone safeZone = tracker.getSafeZones().get(0);
        Coordinate c = safeZone.getCenter().project(50, 0);
                
        Pet p1 = tracker.getClientDevice(pet1_contractId);
        assertNotNull(p1);
        try {
            tracker.newPosition(pet1_serial, c.getLatitude(), c.getLongitude(), new Date());
        } catch (Throwable t) {
            fail();
        }
        
        assertTrue(p1.inSafeZone());        
                
    }
    
    @Test
    public void checkPetNotPositionSafeZone() {
        
        assertNotNull(tracker.getSafeZones());
        assertEquals(0, tracker.getSafeZones().size());
        
        tracker.newCircularSafeZone(SafeZoneType.PARK, "Awesome Park", c1_lat, c1_lon, 100);
        
        assertNotNull(tracker.getSafeZones());
        assertEquals(1, tracker.getSafeZones().size());        
        
        assertTrue(tracker.getSafeZones().get(0) instanceof CircularSafeZone);
        
        SafeZone safeZone = tracker.getSafeZones().get(0);
        Coordinate c = safeZone.getCenter().project(50, 0);
                
        Pet p1 = tracker.getClientDevice(pet1_contractId);
        assertNotNull(p1);
                
        assertFalse(p1.inSafeZone());        
                
    }
    
    @Test
    public void checkPetOutSafeZone() {
        
        assertNotNull(tracker.getSafeZones());
        assertEquals(0, tracker.getSafeZones().size());
        
        tracker.newCircularSafeZone(SafeZoneType.PARK, "Awesome Park", c1_lat, c1_lon, 100);
        
        assertNotNull(tracker.getSafeZones());
        assertEquals(1, tracker.getSafeZones().size());        
        
        assertTrue(tracker.getSafeZones().get(0) instanceof CircularSafeZone);
        
        SafeZone safeZone = tracker.getSafeZones().get(0);
        Coordinate c = safeZone.getCenter().project(150, 0);
                
        Pet p1 = tracker.getClientDevice(pet1_contractId);
        assertNotNull(p1);
        try {
            tracker.newPosition(pet1_serial, c.getLatitude(), c.getLongitude(), new Date());
        } catch (Throwable t) {
            fail();
        }
        
        assertFalse(p1.inSafeZone());                        
    }
        
}