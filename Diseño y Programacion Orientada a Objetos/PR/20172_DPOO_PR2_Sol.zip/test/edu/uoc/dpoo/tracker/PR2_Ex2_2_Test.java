package edu.uoc.dpoo.tracker;

import java.util.Calendar;
import java.util.Date;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class PR2_Ex2_2_Test {
    
    private PetTracker tracker = null;
    
    private final int pet1_serial = 1;
    private final int pet1_contractId = 25;    
    private final int pet3_serial = 3;
    private final int pet3_contractId = 27;    
    
    private final float c1_lat = 41.4065249f;
    private final float c1_lon = 2.1945029f;
    private final Date c1_ts = new Date();          
        
    public PR2_Ex2_2_Test() {
        tracker = new PetTracker();
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        tracker = new PetTracker();
        
        Calendar cal = Calendar.getInstance();        
        cal.add(Calendar.DATE, -2 );
        Date date_min2 = cal.getTime();
        
        cal = Calendar.getInstance();        
        cal.add(Calendar.DATE, 1 );
        Date date_plus1 = cal.getTime();
        
        cal = Calendar.getInstance();        
        cal.add(Calendar.DATE, 2 );
        Date date_plus2 = cal.getTime();
        
        // Check that initially the list of pets is empty
        assertNotNull(tracker.getDevices());
        assertEquals((int)tracker.getDevices().size(), 0);
                
        try {
            // Add active contract that accepts friends
            tracker.addContract(pet1_contractId, date_min2, date_plus2, "pet 1", true);            
            // Add not active contract that accepts friends
            tracker.addContract(pet3_contractId, date_plus1, date_plus2, "pet 3", true);            
            
            // Link devices
            tracker.linkDevice(pet1_contractId, pet1_serial);            
            tracker.linkDevice(pet3_contractId, pet3_serial);            
        } catch (Throwable t) {            
            fail();            
        }     
        
        // Check the list of pets
        assertNotNull(tracker.getDevices());
        assertEquals(2, (int)tracker.getDevices().size());
    }
    
    @After
    public void tearDown() {
        tracker = null;
    }  
            
    @Test
    public void computeElapsedTimeWithPosition() {
        Pet p1 = tracker.getClientDevice(pet1_contractId);
        assertNotNull(p1);
        try {            
            assertNull(p1.getLastPosition());
            assertNotNull(p1.getHistoric());
            assertEquals(0, p1.getHistoric().size());
            tracker.newPosition(pet1_serial, c1_lat, c1_lon, c1_ts);
            assertNotNull(p1.getLastPosition());            
            assertEquals(1, p1.getHistoric().size());
            
            Thread.sleep(2000);
            
            int elapsed = p1.elapsedTime();
            int max_val = (int) (((new Date()).getTime()-c1_ts.getTime())/1000.0);
            
            assertTrue(elapsed >=2);
            assertTrue(elapsed <=max_val);
            
        } catch (Throwable t) {            
            fail();            
        }
    }
    
    @Test
    public void computeElapsedTimeWithoutPosition() {
        Pet p3 = tracker.getClientDevice(pet3_contractId);
        assertNotNull(p3);
        try {            
            assertNull(p3.getLastPosition());
            assertNotNull(p3.getHistoric());
            assertEquals(0, p3.getHistoric().size());
            tracker.newPosition(pet3_serial, c1_lat, c1_lon, c1_ts);
            fail(); 
        } catch (Throwable t) {            
            if(!(t instanceof TrackerException)) {
                fail();
            }            
        }
        assertNull(p3.getLastPosition());
        assertEquals(0, p3.getHistoric().size());
        
        try {
            Thread.sleep(2000);
        } catch (InterruptedException ex) {
            fail();
        }
        assertEquals(-1, p3.elapsedTime());        
    }    
}
