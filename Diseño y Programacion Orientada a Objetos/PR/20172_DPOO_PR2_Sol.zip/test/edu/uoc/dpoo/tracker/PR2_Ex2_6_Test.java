package edu.uoc.dpoo.tracker;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class PR2_Ex2_6_Test {
    
    private PetTracker tracker = null;
    
    private final int pet1_serial = 1;
    private final int pet1_contractId = 25;
    private final int pet2_serial = 2;
    private final int pet2_contractId = 26;
    private final int pet3_serial = 3;
    private final int pet3_contractId = 27;
    private final int pet4_serial = 4;
    private final int pet4_contractId = 28;
    private final int pet5_serial = 5;
    private final int pet5_contractId = 29;
    
    
    private final float c1_lat = 41.4065249f;
    private final float c1_lon = 2.1945029f;
    private final Date c1_ts = new Date();    
    
    private final float c2_lat = 41.3972103f;
    private final float c2_lon = 2.206349f;
    private final Date c2_ts = new Date(); 
        
    public PR2_Ex2_6_Test() {
        tracker = new PetTracker();
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        tracker = new PetTracker();
        
        Calendar cal = Calendar.getInstance();        
        cal.add(Calendar.DATE, -2 );
        Date date_min2 = cal.getTime();
        
        cal = Calendar.getInstance();        
        cal.add(Calendar.DATE, -1 );
        Date date_min1 = cal.getTime();
        
        cal = Calendar.getInstance();        
        cal.add(Calendar.DATE, 1 );
        Date date_plus1 = cal.getTime();
        
        cal = Calendar.getInstance();        
        cal.add(Calendar.DATE, 2 );
        Date date_plus2 = cal.getTime();
        
        // Check that initially the list of pets is empty
        assertNotNull(tracker.getDevices());
        assertEquals((int)tracker.getDevices().size(), 0);
                
        try {
            // Add active contract that accepts friends
            tracker.addContract(pet1_contractId, date_min2, date_plus2, "pet 1", true);
            // Add active contract that accepts friends
            tracker.addContract(pet2_contractId, date_min2, date_plus2, "pet 2", true);
            // Add not active contract that accepts friends
            tracker.addContract(pet3_contractId, date_plus1, date_plus2, "pet 3", true);
            // Add active contract that does not accepts friends
            tracker.addContract(pet4_contractId, date_min2, date_plus2, "pet 4", false);
            // Add not active contract that does not accepts friends
            tracker.addContract(pet5_contractId, date_min2, date_min1, "pet 5", false);
            
            // Link devices
            tracker.linkDevice(pet1_contractId, pet1_serial);
            tracker.linkDevice(pet2_contractId, pet2_serial);
            tracker.linkDevice(pet3_contractId, pet3_serial);
            tracker.linkDevice(pet4_contractId, pet4_serial);
            tracker.linkDevice(pet5_contractId, pet5_serial);
        } catch (Throwable t) {            
            fail();            
        }     
        
        // Check the list of pets
        assertNotNull(tracker.getDevices());
        assertEquals(5, (int)tracker.getDevices().size());
    }
    
    @After
    public void tearDown() {
        tracker = null;
    }  
            
    @Test
    public void findFriendsNoCoordinates() {
        List<Pet> friends = tracker.findFriends(pet1_contractId, 500);
        
        assertNotNull(friends);
        assertEquals(0, friends.size());        
    }
    
    @Test
    public void findFriendsNoCoordinates2() {        
        try {
            tracker.newPosition(pet1_serial, c1_lat, c1_lon, c1_ts);        
        } catch (Throwable t) {            
            fail();            
        }
        
        List<Pet> friends = tracker.findFriends(pet1_contractId, 500);
        
        assertNotNull(friends);
        assertEquals(0, friends.size());        
    }
    
    @Test
    public void findFriendsActiveContracts() {        
        Pet p1 = tracker.getClientDevice(pet1_contractId);
        assertNotNull(p1);
        
        try {
            tracker.newPosition(pet1_serial, c1_lat, c1_lon, c1_ts);
        } catch (Throwable t) {            
            fail();            
        }
            
        List<Pet> friends = tracker.findFriends(pet1_contractId, 500);        
        assertNotNull(friends);
        assertEquals(0, friends.size());        
            
        Coordinate cIn = p1.getLastPosition().project(100, 0);
        try {
            tracker.newPosition(pet2_serial, cIn.getLatitude(), cIn.getLongitude(), cIn.getTimestamp());
        } catch (Throwable t) {            
            fail();            
        }
            
        friends = tracker.findFriends(pet1_contractId, 500);        
        assertNotNull(friends);
        assertEquals(1, friends.size());
            
        Coordinate cOut = p1.getLastPosition().project(1000, 0);
        try{
            tracker.newPosition(pet2_serial, cOut.getLatitude(), cOut.getLongitude(), cOut.getTimestamp());
        } catch (Throwable t) {            
            fail();            
        }
            
        friends = tracker.findFriends(pet1_contractId, 500);        
        assertNotNull(friends);
        assertEquals(0, friends.size());            
    }
    
    @Test
    public void findFriendsNotActiveContracts() {        
        Pet p1 = tracker.getClientDevice(pet1_contractId);
        assertNotNull(p1);
        
        try {
            tracker.newPosition(pet1_serial, c1_lat, c1_lon, c1_ts);
        } catch (Throwable t) {            
            fail();            
        }
        
        List<Pet> friends = tracker.findFriends(pet1_contractId, 500);        
        assertNotNull(friends);
        assertEquals(0, friends.size());        
            
        Coordinate cIn = p1.getLastPosition().project(100, 0);
        try {
            tracker.newPosition(pet4_contractId, cIn.getLatitude(), cIn.getLongitude(), cIn.getTimestamp());
        } catch (Throwable t) {            
            fail();            
        }
            
        friends = tracker.findFriends(pet1_contractId, 500);        
        assertNotNull(friends);
        assertEquals(0, friends.size());

        Coordinate cOut = p1.getLastPosition().project(1000, 0);
        try {
            tracker.newPosition(pet4_contractId, cOut.getLatitude(), cOut.getLongitude(), cOut.getTimestamp());
        } catch (Throwable t) {            
            fail();            
        }
            
        friends = tracker.findFriends(pet1_contractId, 500);        
        assertNotNull(friends);
        assertEquals(0, friends.size());
    }    
}
