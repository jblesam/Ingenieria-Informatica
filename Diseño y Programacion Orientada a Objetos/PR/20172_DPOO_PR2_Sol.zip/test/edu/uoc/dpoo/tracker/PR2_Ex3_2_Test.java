package edu.uoc.dpoo.tracker;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class PR2_Ex3_2_Test {
    
    private PetTracker tracker = null;
            
    private final int pet1_serial = 1;
    private final int pet1_contractId = 25;        
    
    private final float c1_lat = 41.4065249f;
    private final float c1_lon = 2.1945029f;
        
    public PR2_Ex3_2_Test() {
        tracker = new PetTracker();
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        tracker = new PetTracker();
        
        Calendar cal = Calendar.getInstance();        
        cal.add(Calendar.DATE, -2 );
        Date date_min2 = cal.getTime();   
        
        cal = Calendar.getInstance();        
        cal.add(Calendar.DATE, 2 );
        Date date_plus2 = cal.getTime();
        
        // Check that initially the list of pets is empty
        assertNotNull(tracker.getDevices());
        assertEquals((int)tracker.getDevices().size(), 0);
                
        try {
            // Add active contract
            tracker.addContract(pet1_contractId, date_min2, date_plus2, "pet 1", true);
                                    
            // Link devices
            tracker.linkDevice(pet1_contractId, pet1_serial);            
        } catch (Throwable t) {            
            fail();            
        }     
        
        // Check the list of pets
        assertNotNull(tracker.getDevices());
        assertEquals(1, (int)tracker.getDevices().size());       
    }
    
    @After
    public void tearDown() {
        tracker = null;
    }  
            
    @Test
    public void containsCircularSafeZone() {
        
        assertNotNull(tracker.getSafeZones());
        assertEquals(0, tracker.getSafeZones().size());
        
        tracker.newCircularSafeZone(SafeZoneType.PARK, "Awesome Park", c1_lat, c1_lon, 100);
        
        assertNotNull(tracker.getSafeZones());
        assertEquals(1, tracker.getSafeZones().size());        
        
        assertTrue(tracker.getSafeZones().get(0) instanceof CircularSafeZone);
        
        SafeZone safeZone = tracker.getSafeZones().get(0);
        
        assertTrue(safeZone.contains(safeZone.getCenter()));
        assertTrue(safeZone.contains(safeZone.getCenter().project(50, 0)));
        assertFalse(safeZone.contains(safeZone.getCenter().project(150, 0)));
                
    }
    
    @Test
    public void containsSquareSafeZone() {
        
        assertNotNull(tracker.getSafeZones());
        assertEquals(0, tracker.getSafeZones().size());
        
        tracker.newSquareSafeZone(SafeZoneType.VET, "Awesome Vet", c1_lat, c1_lon, 50);
        
        assertNotNull(tracker.getSafeZones());
        assertEquals(1, tracker.getSafeZones().size());
        
        assertTrue(tracker.getSafeZones().get(0) instanceof SquareSafeZone);
        
        SafeZone safeZone = tracker.getSafeZones().get(0);
        
        assertTrue(safeZone.contains(safeZone.getCenter()));
        assertTrue(safeZone.contains(safeZone.getCenter().project(20, 0)));
        assertTrue(safeZone.contains(safeZone.getCenter().project(20, 90)));
        assertTrue(safeZone.contains(safeZone.getCenter().project(20, 180)));
        assertTrue(safeZone.contains(safeZone.getCenter().project(20, 270)));
        
        assertFalse(safeZone.contains(safeZone.getCenter().project(40, 0)));
        assertFalse(safeZone.contains(safeZone.getCenter().project(40, 90)));
        assertFalse(safeZone.contains(safeZone.getCenter().project(40, 180)));
        assertFalse(safeZone.contains(safeZone.getCenter().project(40, 270)));
    }
    
}