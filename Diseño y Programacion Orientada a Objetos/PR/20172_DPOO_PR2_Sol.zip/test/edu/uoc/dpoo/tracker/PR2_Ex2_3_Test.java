package edu.uoc.dpoo.tracker;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class PR2_Ex2_3_Test {
    
    private PetTracker tracker = null;
    private List<Date> coordTimes = null;
        
    private final int pet1_serial = 1;
    private final int pet1_contractId = 25;    
    private final int pet2_serial = 2;
    private final int pet2_contractId = 26;    
    
    private final float c1_lat = 41.4065249f;
    private final float c1_lon = 2.1945029f;
        
    public PR2_Ex2_3_Test() {
        tracker = new PetTracker();
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        tracker = new PetTracker();
        
        Calendar cal = Calendar.getInstance();        
        cal.add(Calendar.DATE, -2 );
        Date date_min2 = cal.getTime();   
        
        cal = Calendar.getInstance();        
        cal.add(Calendar.DATE, 2 );
        Date date_plus2 = cal.getTime();
        
        // Check that initially the list of pets is empty
        assertNotNull(tracker.getDevices());
        assertEquals((int)tracker.getDevices().size(), 0);
                
        try {
            // Add active contract that accepts friends
            tracker.addContract(pet1_contractId, date_min2, date_plus2, "pet 1", true);
            // Add active contract that accepts friends
            tracker.addContract(pet2_contractId, date_min2, date_plus2, "pet 2", true);
                                    
            // Link devices
            tracker.linkDevice(pet1_contractId, pet1_serial);            
            tracker.linkDevice(pet2_contractId, pet2_serial);            
        } catch (Throwable t) {            
            fail();            
        }     
        
        // Check the list of pets
        assertNotNull(tracker.getDevices());
        assertEquals(2, (int)tracker.getDevices().size());
        
        coordTimes = new ArrayList<Date>();
        
        Pet p1 = tracker.getClientDevice(pet1_contractId);
        assertNotNull(p1);
        assertNull(p1.getLastPosition());
        assertNotNull(p1.getHistoric());
        assertEquals(0, p1.getHistoric().size());        
        
        cal = Calendar.getInstance();        
        for (int i=1;i<=15; i++){
            cal.add(Calendar.SECOND, 15);
            Date c_ts = cal.getTime();
            coordTimes.add(c_ts);
            try {                        
                tracker.newPosition(pet1_serial, c1_lat + (i*0.01f), c1_lon + (-i*0.01f), c_ts);
                assertNotNull(p1.getLastPosition());            
                assertEquals(i, p1.getHistoric().size());            
            } catch (Throwable t) {            
                fail();            
            }
        }        
        assertNotNull(p1.getHistoric());
        assertEquals(15, p1.getHistoric().size());
    }
    
    @After
    public void tearDown() {
        tracker = null;
    }  
            
    @Test
    public void getValidTrack() {
        Pet p1 = tracker.getClientDevice(pet1_contractId);
        assertNotNull(p1);
        assertTrue(p1.getHistoric().size()>2);
        List<Coordinate> track = p1.getTrack(p1.getHistoric().get(0).getTimestamp(), p1.getLastPosition().getTimestamp());
        assertNotNull(track);
        assertEquals(p1.getHistoric().size(), track.size());
        assertSame(p1.getHistoric().get(0), track.get(0));
        assertSame(p1.getLastPosition(), track.get(track.size()-1));
    }
    
    @Test
    public void getValidTrackShortened() {
        Pet p1 = tracker.getClientDevice(pet1_contractId);
        assertNotNull(p1);
        assertTrue(p1.getHistoric().size()>2);
        List<Coordinate> track = p1.getTrack(p1.getHistoric().get(1).getTimestamp(), p1.getLastPosition().getTimestamp());
        assertNotNull(track);
        assertEquals(p1.getHistoric().size()-1, track.size());
        assertSame(p1.getHistoric().get(1), track.get(0));
        assertSame(p1.getLastPosition(), track.get(track.size()-1));
    }
    
    @Test
    public void getEmptyTrack() {
        Pet p2 = tracker.getClientDevice(pet2_contractId);
        assertNotNull(p2);
        assertEquals(0, p2.getHistoric().size());
        
        Calendar cal = Calendar.getInstance();        
        cal.add(Calendar.SECOND, -10 );
        Date start = cal.getTime();
        cal.add(Calendar.SECOND, 30 );
        Date end = cal.getTime();
        
        List<Coordinate> track = p2.getTrack(start, end);
        assertNotNull(track);
        assertEquals(0, track.size());        
    }
    
    @Test
    public void getEmptyTrackFilter() {
        Pet p1 = tracker.getClientDevice(pet1_contractId);
        assertNotNull(p1);
        assertTrue(p1.getHistoric().size()>2);
        
        Calendar cal = Calendar.getInstance();
        cal.setTime(p1.getHistoric().get(0).getTimestamp());
        cal.add(Calendar.SECOND, -50 );                
        Date start = cal.getTime();
        cal.add(Calendar.SECOND, 30 );
        Date end = cal.getTime();
        
        List<Coordinate> track = p1.getTrack(start, end);
        assertNotNull(track);
        assertEquals(0, track.size());        
        
        cal = Calendar.getInstance();
        cal.setTime(p1.getLastPosition().getTimestamp());
        cal.add(Calendar.SECOND, 20 );                
        start = cal.getTime();
        cal.add(Calendar.SECOND, 30 );
        end = cal.getTime();
        
        track = p1.getTrack(start, end);
        assertNotNull(track);
        assertEquals(0, track.size());
    }
}
