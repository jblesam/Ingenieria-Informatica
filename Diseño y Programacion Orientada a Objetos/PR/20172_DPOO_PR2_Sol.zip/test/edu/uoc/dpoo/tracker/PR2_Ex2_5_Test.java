package edu.uoc.dpoo.tracker;

import java.util.Calendar;
import java.util.Date;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class PR2_Ex2_5_Test {
    
    private PetTracker tracker = null;
    
    private final int pet1_serial = 1;
    private final int pet1_contractId = 25;
    private final int pet2_serial = 2;
    private final int pet2_contractId = 26;
    private final int pet3_serial = 3;
    private final int pet3_contractId = 27;
    private final int pet4_serial = 4;
    private final int pet4_contractId = 28;
    private final int pet5_serial = 5;
    private final int pet5_contractId = 29;
        
    public PR2_Ex2_5_Test() {
        tracker = new PetTracker();
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        tracker = new PetTracker();
        
        Calendar cal = Calendar.getInstance();        
        cal.add(Calendar.DATE, -2 );
        Date date_min2 = cal.getTime();
        
        cal = Calendar.getInstance();        
        cal.add(Calendar.DATE, -1 );
        Date date_min1 = cal.getTime();
        
        cal = Calendar.getInstance();        
        cal.add(Calendar.DATE, 1 );
        Date date_plus1 = cal.getTime();
        
        cal = Calendar.getInstance();        
        cal.add(Calendar.DATE, 2 );
        Date date_plus2 = cal.getTime();
        
        // Check that initially the list of pets is empty
        assertNotNull(tracker.getDevices());
        assertEquals((int)tracker.getDevices().size(), 0);
                
        try {
            // Add active contract that accepts friends
            tracker.addContract(pet1_contractId, date_min2, date_plus2, "pet 1", true);
            // Add active contract that accepts friends
            tracker.addContract(pet2_contractId, date_min2, date_plus2, "pet 2", true);
            // Add not active contract that accepts friends
            tracker.addContract(pet3_contractId, date_plus1, date_plus2, "pet 3", true);
            // Add active contract that does not accepts friends
            tracker.addContract(pet4_contractId, date_min2, date_plus2, "pet 4", false);
            // Add not active contract that does not accepts friends
            tracker.addContract(pet5_contractId, date_min2, date_min1, "pet 5", false);
            
            // Link devices
            tracker.linkDevice(pet1_contractId, pet1_serial);
            tracker.linkDevice(pet2_contractId, pet2_serial);
            tracker.linkDevice(pet3_contractId, pet3_serial);
            tracker.linkDevice(pet4_contractId, pet4_serial);
            tracker.linkDevice(pet5_contractId, pet5_serial);
        } catch (Throwable t) {            
            fail();            
        }     
        
        // Check the list of pets
        assertNotNull(tracker.getDevices());
        assertEquals(5, (int)tracker.getDevices().size());
    }
    
    @After
    public void tearDown() {
        tracker = null;
    }  
            
    @Test
    public void computeDistance() {
        assertNotNull(tracker.getActiveDevices());
        assertEquals(3, tracker.getActiveDevices().size());
    }
}
