package edu.uoc.dpoo.tracker;

public class SquareSafeZone extends SafeZone {

    private float size;

    public SquareSafeZone(float size, String description, SafeZoneType type, Coordinate center) {
        super(description, type, center);
        this.size = size;
    }

    public float getSize() {
        return size;
    }

    public void setSize(float size) {
        this.size = size;
    }
    
    @Override
    public boolean contains(Coordinate c) {
        /* PR2 EX 3.2 */
        double diagonal = Math.sqrt(2.0 * Math.pow(this.size, 2));
        Coordinate nw = getCenter().project((int) Math.round(diagonal/2.0), 45);
        Coordinate se = getCenter().project((int) Math.round(diagonal/2.0), 225);
        
        boolean contained = true;
        if(nw.getLatitude() > se.getLatitude()) {
            contained = contained && (c.getLatitude()<=nw.getLatitude() && c.getLatitude()>=se.getLatitude());
        } else {
            contained = contained && (c.getLatitude()>=nw.getLatitude() && c.getLatitude()<=se.getLatitude());
        }
        
        if(nw.getLongitude() > se.getLongitude()) {
            contained = contained && (c.getLongitude()<=nw.getLongitude() && c.getLongitude()>=se.getLongitude());
        } else {
            contained = contained && (c.getLongitude()>=nw.getLongitude() && c.getLongitude()<=se.getLongitude());
        }
                
        return contained;
    }
}
