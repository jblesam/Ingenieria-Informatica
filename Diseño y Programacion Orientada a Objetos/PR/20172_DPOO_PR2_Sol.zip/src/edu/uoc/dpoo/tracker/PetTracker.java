package edu.uoc.dpoo.tracker;

import java.util.ArrayList;
import java.util.List;
import java.util.Date;

public class PetTracker 
    /* PR2 EX 4.1 */
    implements EventListener
{

    private List<Pet> devices;
    private List<SafeZone> safeZones;
    private List<Message> messages;

    public PetTracker() {
        this.devices = new ArrayList<Pet>();
        this.safeZones = new ArrayList<SafeZone>();
        this.messages = new ArrayList<Message>();
    }

    public List<Pet> getDevices() {
        return devices;
    }

    public void setDevices(List<Pet> devices) {
        this.devices = devices;
    }

    public List<SafeZone> getSafeZones() {
        return safeZones;
    }

    public void setSafeZones(List<SafeZone> safeZones) {
        this.safeZones = safeZones;
    }

    public List<Message> getMessages() {
        return messages;
    }

    public void setMessages(List<Message> messages) {
        this.messages = messages;
    }   
    
    public void newPosition(int serial, float lat, float lon, Date timestamp) 
        /* PR2 Ex 2.1 */    
        throws TrackerException 
    {
        Pet pet = getPetBySerial(serial);
        if(pet == null) {
            return;
        }
        Coordinate newPosition = new Coordinate(lat, lon, timestamp);
        /* Check on the contract is delegated on the class Pet */
        pet.newPosition(newPosition);
    }
    
    public void addContract(int contractId, Date start, Date end, String petName, boolean allowFriends) 
        /* PR2 Ex 1 */    
        throws TrackerException 
    {
        /* PR2 Ex 1*/
        if (contractId <= 0){
            throw new TrackerException(TrackerException.NEGATIVE_ID);
        }
        
        /* PR1 EX 2 */
        if(this.getContract(contractId)==null) {
            Pet new_device = new Pet(petName, this, contractId, start, end, allowFriends);
            this.devices.add(new_device);
        }
        /* PR2 EX 1*/
        else {
            throw new TrackerException(String.format(TrackerException.DUPLICATED_ID, contractId));
        }
    }
    
    public Contract getContract(int contractId) {
        /* PR1 EX 2 */
        Pet device = this.getClientDevice(contractId);
        if(device!=null) {
            return device.getContract();
        }
        return null;
    }

    public void delContract(int contractId) 
        /* PR2 Ex 1 */    
        throws TrackerException
    {
        /* PR1 EX 2 */
        Pet device = this.getClientDevice(contractId);
        if(device!=null) {
            this.devices.remove(device);
            this.removeMessages(contractId);
        }
        /* PR2 EX 1*/
        else {
            throw new TrackerException(String.format(TrackerException.INVALID_ID, contractId));
        }
    }

    public void extendContract(int contractId, Date end) {
    }

    public List<Pet> findFriends(int contractId, float maxDistance) {
        /* PR2 Ex 2.6 */
        List<Pet> retList = new ArrayList<Pet>();
        Pet reference = getClientDevice(contractId);
        
        if (!reference.getContract().isActive()) {
            return retList;
        }
        
        if (reference.getLastPosition() == null) {
            return retList;
        }
        
        for(Pet p:getActiveDevices()) {
            if (p.getSerial() == reference.getSerial()) {
                continue;
            }
            if(p.getContract().getAllowFriends() &&                 
                p.getLastPosition() != null && 
                p.getLastPosition().distanceTo(reference.getLastPosition()) <= 500) {
                
                retList.add(p);
            }
        }        
        
        return retList;
    }

    public void sendMessage(int contractId, MessageType type) 
        /* PR2 Ex 1 */    
        throws TrackerException
    {
        /* PR1 EX 3 */
        Pet device = this.getClientDevice(contractId);
        if(device!=null) {
            Message m = new Message(contractId, type);
            this.messages.add(m);
        }
        /* PR2 EX 1*/
        else {
            throw new TrackerException(String.format(TrackerException.INVALID_ID, contractId));
        }
    }

    public void linkDevice(int contractId, int serial) 
        /* PR2 Ex 1 */    
        throws TrackerException 
    {
        /* PR2 Ex 1*/
        if (serial <= 0){
            throw new TrackerException(TrackerException.NEGATIVE_SERIAL);
        }
        if (getPetBySerial(serial) != null){
            throw new TrackerException(String.format(TrackerException.DEVICE_LINKED, serial));            
        }        
        
        /* PR1 EX 2 */
        Pet device = this.getClientDevice(contractId);
        if(device!=null) {
            device.setSerial(serial);
        }
        /* PR2 EX 1*/
        else {
            throw new TrackerException(String.format(TrackerException.INVALID_ID, contractId));
        }
        
        /* PR2 EX 4.1 */
        device.addListener(this);
    }

    public void newSquareSafeZone(SafeZoneType type, String description, float centerLat, float centerLon, float size) {
        /* PR2 EX 3.1 */ 
        Coordinate center = new Coordinate(centerLat, centerLon, new Date());
        SafeZone zone = new SquareSafeZone(size, description, type, center);
        this.safeZones.add(zone);
    }

    public void newCircularSafeZone(SafeZoneType type, String description, float centerLat, float centerLon, float radius) {
        /* PR2 EX 3.2 */ 
        Coordinate center = new Coordinate(centerLat, centerLon, new Date());
        SafeZone zone = new CircularSafeZone(radius, description, type, center);
        this.safeZones.add(zone);
    }

    public Pet getClientDevice(int contractId) {
        /* PR1 EX 2 */        
        for(Pet p:this.devices) {
            if (p.getContract().getContractId()==contractId) {
                return p;
            }            
        }        
        return null;
    }
    
    public List<Pet> getActiveDevices() {
        /* PR2 EX 3.5 */
        List<Pet> retList = new ArrayList<Pet>();
        
        for(Pet p:this.devices) {
            if (p.getContract().isActive()) {
                retList.add(p);
            }
        }
        
        return retList;
    }
    
    private void removeMessages(int contractId) {
        /* Utility method for PR1 EX 2*/
        List<Message> contractMessages = new ArrayList<Message>();
        
        // Get all messages for this contract
        for(Message m:this.messages) {
            if(m.getContractId()==contractId){
                contractMessages.add(m);
            }
        }
        
        // Delete the messages from the list
        for(Message m:contractMessages) {
            this.messages.remove(m);
        }
    }
    
    /* PR2 Ex 1,2 Support method */
    private Pet getPetBySerial(int serial){
        Pet pet = null;
        for(Pet p: getDevices()) {
            if (p.getSerial() == serial) {
                pet = p;
                break;
            }
        }
        return pet;
    }

    /* PR2 EX 4.1 */
    @Override
    public void onEnterSafeZone(Pet pet, SafeZone zone) {
        /* PR2 EX 4.2 */
        try {
            this.sendMessage(pet.getContract().getContractId(), MessageType.ENTER_SAFE_ZONE);
        } catch (TrackerException ex) {
            
        }
    }

    /* PR2 EX 4.1 */
    @Override
    public void onExitSafeZone(Pet pet, SafeZone zone) {
        /* PR2 EX 4.2 */
        try {
            this.sendMessage(pet.getContract().getContractId(), MessageType.LEFT_SAFE_ZONE);
        } catch (TrackerException ex) {
            
        }
    }

    /* PR2 EX 4.1 */
    @Override
    public void onFriendNear(Contract contract, List<Pet> friends) {
        /* PR2 EX 4.2 */
        try {
            this.sendMessage(contract.getContractId(), MessageType.FRIEND_NEAR);
            for(Pet p:friends) {
                this.sendMessage(p.getContract().getContractId(), MessageType.FRIEND_NEAR);
            }
        } catch (TrackerException ex) {
            
        }
    }

    /* PR2 EX 4.1 */
    @Override
    public void onContactRecovered(Pet pet) {
        /* PR2 EX 4.2 */
        try {
            this.sendMessage(pet.getContract().getContractId(), MessageType.SIGNAL_LOST);
        } catch (TrackerException ex) {
            
        }
    }
}
