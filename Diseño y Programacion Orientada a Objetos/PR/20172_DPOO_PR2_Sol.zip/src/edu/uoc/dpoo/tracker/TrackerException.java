package edu.uoc.dpoo.tracker;

public class TrackerException extends Exception {
    // Predefined errors
    // Without parameters    
    public static final String NEGATIVE_ID = "Contract ID must be positive";
    public static final String NEGATIVE_SERIAL = "Serial number must be positive";
            
    // With parameters
    public static final String INVALID_ID = "No contract with id %s exist in the tracker";
    public static final String DUPLICATED_ID = "Contract with id %s already exists in the tracker";
    public static final String DEVICE_LINKED = "The device with serial %s is already linked to a contract";
    public static final String INACTIVE_CONTRACT = "Contract with id %s is not active";
            
    /* 
    
    - How to throw with a custom message:    
    throw new TrackerException("this is a custom message");
    
    - How to throw with a pre-defined message:    
    -- Without parameters
    throw new TrackerException(TrackerException.NEGATIVE_ID);
    
    -- With parameters 
    throw new TrackerException(String.format(TrackerException.INVALID_ID, contractId));
    
    */
    public TrackerException (String message){
        super(message);
    }
}
