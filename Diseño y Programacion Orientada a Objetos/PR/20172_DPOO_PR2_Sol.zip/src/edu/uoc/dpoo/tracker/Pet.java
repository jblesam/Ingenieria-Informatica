package edu.uoc.dpoo.tracker;

import java.util.ArrayList;
import java.util.List;
import java.util.Date;

public class Pet {

    private String name;
    private int serial;
    private Coordinate lastPosition;
    private List<Coordinate> historic;
    private PetTracker tracker;
    private Contract contract;
    
    /* PR2 Ex 4.1 */
    private List<EventListener> listeners = new ArrayList<EventListener>();

    public Pet(String name, PetTracker tracker, int contractId, Date start, Date end, boolean allowFriends) {
        this.name = name;
        this.tracker = tracker;
        this.serial = -1;
        this.lastPosition = null;
        this.historic = new ArrayList<Coordinate>();
        this.contract = new Contract(contractId, start, end, allowFriends);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getSerial() {
        return serial;
    }

    public void setSerial(int serial) {
        this.serial = serial;
    }

    public Coordinate getLastPosition() {
        return lastPosition;
    }

    public void setLastPosition(Coordinate lastPosition) {
        this.lastPosition = lastPosition;
    }

    public List<Coordinate> getHistoric() {
        return historic;
    }

    public void setHistoric(List<Coordinate> historic) {
        this.historic = historic;
    }

    public PetTracker getTracker() {
        return tracker;
    }

    public void setTracker(PetTracker tracker) {
        this.tracker = tracker;
    }

    public Contract getContract() {
        return contract;
    }

    public void setContract(Contract contract) {
        this.contract = contract;
    }   

    public void newPosition(Coordinate c) 
        /* PR2 EX 2.1 */
        throws TrackerException
    {
        /* PR2 EX 2.1 */
        if(getContract().isActive() == false) {
            throw new TrackerException(String.format(TrackerException.INACTIVE_CONTRACT, getContract().getContractId()));
        }
        
        /* PR2 EX 4.2 */
        Coordinate initialPosition = this.lastPosition;
        /* Signal recovered */
        if (this.elapsedTime() > 60) {
            this.notifyContactRecovered();
        }
        
        
        this.lastPosition = c;
        this.historic.add(c);   
        
        
        /* PR2 EX 4.2 */
        checkEvents(initialPosition, this.lastPosition);
    }

    public boolean inSafeZone() {
        /* PR2 EX 3.3 */
        if (this.lastPosition == null) {
            return false;
        }
        for(SafeZone safeZone:this.tracker.getSafeZones()) {
            if(safeZone.contains(this.lastPosition)){
                return true;
            }
        }
        return false;
    }

    public List<Coordinate> getTrack(Date start, Date end) {
        /* PR2 EX 2.3 */
        List<Coordinate> retList = new ArrayList<Coordinate>();
        
        for(Coordinate c:this.historic) {
            if (start.after(c.getTimestamp())) {
                continue;
            }
            if (end.before(c.getTimestamp())) {
                break;
            }
            retList.add(c);
        }
        
        return retList;
    }

    public float getDistance(Date start, Date end) {
        /* PR2 EX 2.4 */
        float distance = 0.0f;
        
        List<Coordinate> track = getTrack(start, end);
        if(track.size()<2) {
            return 0.0f;
        }
        
        for(int i=1;i<track.size();i++) {
            distance += track.get(i-1).distanceTo(track.get(i));
        }
        
        return distance;
    }

    public int elapsedTime() {
        /* PR2 EX 2.2 */  
        if(getLastPosition() == null) {
            return -1;
        }
        
        Date currentTime = new Date();
        long elapsed = currentTime.getTime() - getLastPosition().getTimestamp().getTime();
        return (int) elapsed/1000;
    }

    public List<Message> getUnreadMessages() {
        /* PR1 EX 3 */
        List<Message> messages = new ArrayList<Message>();
        for(Message msg:this.tracker.getMessages()) {
            if (msg.getContractId() == this.contract.getContractId() && msg.isUnreaded()) {
                messages.add(msg);
            }
        }
        return messages;
    }
    
    /* PR2 Ex 4.1 */
    public void addListener(EventListener listener) {
        this.listeners.add(listener);
    }
    
    /* PR2 Ex 4.2 Auxiliar methods*/
    private void checkEvents(Coordinate currentPosition, Coordinate newPosition) {
           
        /* Enter or leave safe zones */
        SafeZone initial_safeZone = getPositionSafeZone(currentPosition);
        SafeZone final_safeZone = getPositionSafeZone(newPosition);
        if (initial_safeZone != final_safeZone) {
            if(initial_safeZone!=null) {
                this.notifyExitSafeZone(initial_safeZone);
            }
            if(final_safeZone!=null) {
                this.notifyEnterSafeZone(final_safeZone);
            }
        }
        
        /* Find friends */
        List<Pet> friends = tracker.findFriends(getContract().getContractId(), 500);
        if (friends.size() > 0) {
            this.notifyFriendNear(friends);
        }
    }
    
    private SafeZone getPositionSafeZone(Coordinate pos) {
        if(pos == null) {
            return null;
        }
        for(SafeZone safeZone:tracker.getSafeZones()) {
            if(safeZone.contains(pos)){
                return safeZone;
            }
        }
        return null;
    }
    
    private void notifyEnterSafeZone(SafeZone zone) {
        for(EventListener l:this.listeners) {
            l.onEnterSafeZone(this, zone);
        }
    }
    private void notifyExitSafeZone(SafeZone zone) {
        for(EventListener l:this.listeners) {
            l.onExitSafeZone(this, zone);
        }
    }
    private void notifyContactRecovered() {
        for(EventListener l:this.listeners) {
            l.onContactRecovered(this);
        }
    }
    private void notifyFriendNear(List<Pet> friends) {
        for(EventListener l:this.listeners) {
            l.onFriendNear(this.getContract(), friends);
        }
    }
}
