package edu.uoc.dpoo.tracker;

import java.util.List;

public interface EventListener {
    public void onEnterSafeZone(Pet pet, SafeZone zone);
    public void onExitSafeZone(Pet pet, SafeZone zone);
    public void onFriendNear(Contract contract, List<Pet> friends);
    public void onContactRecovered(Pet pet);
}