package edu.uoc.dpoo.tracker;

public class CircularSafeZone extends SafeZone {

    private float radius;

    public CircularSafeZone(float radius, String description, SafeZoneType type, Coordinate center) {
        super(description, type, center);
        this.radius = radius;
    }

    @Override
    public boolean contains(Coordinate c) {  
        /* PR2 EX 3.2 */
        return getCenter().distanceTo(c) <= this.radius;
    }

    public float getRadius() {
        return radius;
    }

    public void setRadius(float radius) {
        this.radius = radius;
    }    
}
