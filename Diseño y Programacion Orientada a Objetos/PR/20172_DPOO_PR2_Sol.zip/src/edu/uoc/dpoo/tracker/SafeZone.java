package edu.uoc.dpoo.tracker;

public abstract class SafeZone {

    private String description;
    private SafeZoneType type;
    private Coordinate center;

    public SafeZone(String description, SafeZoneType type, Coordinate center) {
        this.description = description;
        this.type = type;
        this.center = center;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public SafeZoneType getType() {
        return type;
    }

    public void setType(SafeZoneType type) {
        this.type = type;
    }

    public Coordinate getCenter() {
        return center;
    }

    public void setCenter(Coordinate center) {
        this.center = center;
    }    

    public abstract boolean contains(Coordinate c);

}
