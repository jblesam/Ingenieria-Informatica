package edu.uoc.dpoo.tracker;

public enum SafeZoneType {
    VET,
    PET_AREA,
    PARK;
}
