package edu.uoc.dpoo.tracker;

import java.util.Date;

public class Coordinate {

    private float latitude;
    private float longitude;
    private Date timestamp;

    public Coordinate(float latitude, float longitude, Date timestamp) {
        this.latitude = latitude;
        this.longitude = longitude;
        this.timestamp = timestamp;
    }
    
    public float distanceTo(Coordinate c) {
        final int R = 6371;

        double latDistance = Math.toRadians(c.getLatitude() - this.latitude);
        double lonDistance = Math.toRadians(c.getLongitude() - this.longitude);
        double a = Math.sin(latDistance / 2.0) * Math.sin(latDistance / 2.0)
                + Math.cos(Math.toRadians(this.latitude)) * Math.cos(Math.toRadians(c.getLatitude()))
                * Math.sin(lonDistance / 2.0) * Math.sin(lonDistance / 2.0);
        double b = 2.0 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        double distance = R * b * 1000;

        distance = Math.pow(distance, 2);

        return (float) Math.sqrt(distance);        
    }

    public float getLatitude() {
        return latitude;
    }

    public void setLatitude(float latitude) {
        this.latitude = latitude;
    }

    public float getLongitude() {
        return longitude;
    }

    public void setLongitude(float longitude) {
        this.longitude = longitude;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }
    
    public Coordinate project(int dist, float theta) {        
        double dx = dist * Math.sin(Math.toRadians(theta));
        double dy = dist * Math.cos(Math.toRadians(theta));
        
        double dlon = dx/(111320*Math.cos(this.latitude));
        double dlat = dy/110540;
                
        return new Coordinate((float) (dlat + this.latitude), (float) (dlon + this.longitude), this.timestamp);
    }
}
