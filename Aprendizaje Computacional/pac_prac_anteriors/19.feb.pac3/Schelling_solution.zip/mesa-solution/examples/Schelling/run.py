from server import server

server.launch()
