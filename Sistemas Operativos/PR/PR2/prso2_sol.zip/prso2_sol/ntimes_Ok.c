#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <signal.h>
#include <stdbool.h>

#include "rutines.h"

#define DMaxProcess 100

/* Functions definitions */
void sigquit_management(int sig);
void sigint_management(int sig);

/* Global variables */
int pid_cmd1[DMaxProcess], pid_cmderror=0, ntimes;
bool cmd1_enabled=true, cmd2_enabled=false;


int main(int argc, char *argv[])
{
	char cmd[256]; 
	int a, h, cmd2, status, ntimes;

	if (argc<3)
		Error("[ntimes_Ok::main] Insufficient arguments: after n <cmd1> [args,...] --error <cmd2> [args,...]");

	ntimes = atoi(argv[1]);
	if (ntimes>=100)
		Error("[ntimes_Ok::main] Too many processes.");

	for (a=2;a<argc;a++)
	{
		if (strcasecmp(argv[a],"--error")==0)
		{
			cmd2 = a+1;
			argv[a]=NULL;
			break;
		}
	}

	for (h=0;h<ntimes;h++)
		pid_cmd1[h]=0;

	if (cmd2==0)
		Error("[after2_Ok::main] Error in arguments:  missing --error.");

	// Install SIGQUIT signal management rutine.
	if (signal(SIGQUIT,sigquit_management)==SIG_ERR)
		Error("[after_Ok::main] Error in installing SIGQUIT manager.");

	if (cmd1_enabled)	
	{
		for (h=0;h<ntimes && cmd1_enabled;h++)
		{
			if ((pid_cmd1[h]=fork())==0)
			{
				if (signal(SIGINT,SIG_IGN)==SIG_ERR)
					Error("[after_Ok::main] Error in ignoring SIGINT signal.");		
				
				// Child1 -> First command.
				execvp(argv[2],&argv[2]);
				Error("[after_Ok::main] Error lauching first command.");
			}
		}
		for (h=0;h<ntimes;h++)
		{
			if (wait(&status)<0)
				Error("[after_Ok::main] Error executing first command.");
			
			if (!WIFEXITED(status) || (WIFEXITED(status) && WEXITSTATUS(status)!=0))
				cmd2_enabled=true;
				
			pid_cmd1[h]=0;
		}
	}

	if (cmd2_enabled)	
	{	
		if ((pid_cmderror=fork())==0)
		{
			if (signal(SIGQUIT,SIG_IGN)==SIG_ERR)
				Error("[after_Ok::main] Error in ignoring SIGQUIT signal.");		
				
			// Child2 -> Second command.
			execvp(argv[cmd2],&argv[cmd2]);
			Error("[after_Ok::main] Error lauching second command.");
		}
	
		if (wait(&status)<0)
			Error("[after_Ok::main] Error executing second command.");
			
		pid_cmderror=0;
	}

	exit(0);
}



/******************************************************************************/
/* Function name:	sigquit_management			   					      	  */
/* Description:   Management of SIGQUIT 							 	      */
/* Parameters:    The signal number											  */
/* Returns:				Nothing. 											  */
/******************************************************************************/

void sigquit_management(int sig)
{
	int h;

	write_string_c("Received SIGQUIT --> Cmd1 cancelled.\n", color_purple);
	
	cmd1_enabled = false;
	cmd2_enabled = true;
	
	for (h=0;h<ntimes;h++)
	{
		if (pid_cmd1[h]!=0)
			kill(SIGTERM,pid_cmd1[h]);
	}
}



