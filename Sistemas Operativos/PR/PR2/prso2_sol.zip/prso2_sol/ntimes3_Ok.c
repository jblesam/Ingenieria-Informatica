#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdbool.h>

#include "rutines.h"

#define DMaxProcess 100

/* Functions definitions */
void sigquit_management(int sig);
void leer_cmd_output();
int leer_cmd_error();

/* Global variables */
int pid_cmd1[DMaxProcess], pid_cmderror=0, ntimes;
int pipe_out[DMaxProcess][2], pipe_err[2];
bool cmd1_enabled=true, cmd2_enabled=false;


int main(int argc, char *argv[])
{
	char cmd[256]; 
	int a, h, cmd2, status, flags;

	if (argc<3)
		Error("[ntimes3_Ok::main] Insufficient arguments: ntimes3 n <cmd1> [args,...] --error <cmd2> [args,...]");

	ntimes = atoi(argv[1]);
	if (ntimes>=100)
		Error("[ntimes_Ok::main] Too many processes.");

	for (a=2;a<argc;a++)
	{
		if (strcasecmp(argv[a],"--error")==0)
		{
			cmd2 = a+1;
			argv[a]=NULL;
			break;
		}
	}

	if (cmd2==0)
		Error("[ntimes3_Ok::main] Error in arguments:  missing --error.");

	for (h=0;h<ntimes;h++)
	{
		pid_cmd1[h]=0;
		if (pipe(pipe_out[h])<0)
			Error("[ntimes3_Ok::main] Error creating pipe_out.");		
	}
	if (pipe(pipe_err)<0)
		Error("[ntimes3_Ok::main] Error creating pipe_err.");		

	if (cmd1_enabled)	
	{
		for (h=0;h<ntimes && cmd1_enabled;h++)
		{
			if ((pid_cmd1[h]=fork())==0)
			{
				close(1);
				dup(pipe_out[h][1]);
				for (h=0;h<ntimes;h++) {
					close(pipe_out[h][0]); close(pipe_out[h][1]);
				}

				close(2);
				dup(pipe_err[1]);
				close(pipe_err[0]); close(pipe_err[1]);
				
				// Child1 -> First command.
				execvp(argv[2],&argv[2]);
				Error("[ntimes3_Ok::main] Error lauching first command.");
			}
		}

		/* Close not used pipe descriptors (writer descriptor) */
		for (h=0;h<ntimes;h++) 
			close(pipe_out[h][1]);
		close(pipe_err[1]);

		/* Read cmd1 stdin & stderr */
		leer_cmd_output();

		/* Waiting for all cmd1 processes finishes */
		for (h=0;h<ntimes;h++)
		{
			if (wait(&status)<0)
				Error("[ntimes3_Ok::main] Error executing first command.");
			
			if (!WIFEXITED(status) || (WIFEXITED(status) && WEXITSTATUS(status)!=0))
				cmd2_enabled=true;
				
			pid_cmd1[h]=0;
		}
	}

	if (cmd2_enabled)	
	{	
		if ((pid_cmderror=fork())==0)
		{
			close(2);
			dup(pipe_err[1]);
			close(pipe_err[0]); close(pipe_err[1]);

			// Child2 -> Second command.
			execvp(argv[cmd2],&argv[cmd2]);
			Error("[ntimes3_Ok::main] Error lauching second command.");
		}
	

		/* Desactivate the non-blocking read for pipe_out[*][0] */
		if ((flags=fcntl(pipe_err[0], F_GETFL, 0))<0)
			Error("[ntimes3_Ok::leer_cmd_output] Error reading pipe_err FD flags.");
		if (fcntl(pipe_err[0],F_SETFL, flags|O_NONBLOCK)<0)
			Error("[ntimes3_Ok::leer_cmd_output] Error setting pipe_err FD flags.");

		/* Read cmd2 stderr */
		while(leer_cmd_error()==1);

		if (wait(&status)<0)
			Error("[ntimes3_Ok::main] Error executing second command.");
			
		pid_cmderror=0;
	}

	exit(0);
}



/******************************************************************************/
/* Function name:	leer_cmd_output  			   					          */
/* Description:   Read comand output from pipe and writting on stdout		  */
/* Parameters:    File/Pipe descriptor 									      */
/* Returns:				Nothing. 										      */
/******************************************************************************/

void leer_cmd_output()
{
	int open_pipes=ntimes+1, bread, err=1, h, flags;
	char cad[201], color[20]; 

printf("leer_cmd_output %d.\n",ntimes);

	/* Activate the non-blocking read for pipe_out[*][0] */
	for (h=0;h<ntimes;h++)
	{
		int flags;

		// Get file descriptor flags.
		if ((flags=fcntl(pipe_out[h][0], F_GETFL, 0))<0)
			Error("[ntimes3_Ok::leer_cmd_output] Error reading pipe_out FD flags.");
		if (fcntl(pipe_out[h][0],F_SETFL, flags|O_NONBLOCK)<0)
			Error("[ntimes3_Ok::leer_cmd_output] Error setting pipe_out FD flags.");
	}

	/* Activate the non-blocking read for pipe_out[*][0] */
	if ((flags=fcntl(pipe_err[0], F_GETFL, 0))<0)
		Error("[ntimes3_Ok::leer_cmd_output] Error reading pipe_err FD flags.");
	if (fcntl(pipe_err[0],F_SETFL, flags|O_NONBLOCK)<0)
		Error("[ntimes3_Ok::leer_cmd_output] Error setting pipe_err FD flags.");

	do {
		/* Receive cmd1 stdout */
		for (h=0;h<ntimes;h++)
		{
			if (pipe_out[h][0]!=0)
			{
				if ( ((bread = read(pipe_out[h][0], &cad, 200))<0) && errno!=EAGAIN)
				{
					Error("[ntimes3_Ok::leer_cmd_output] Error reading pipe.");
				}
				if (bread==0)
				{
					close(pipe_out[h][0]);
					pipe_out[h][0] = 0;
					open_pipes--;
					continue;
				}
				if (bread>0)
				{
					cad[bread]='\0';
					sprintf(color,"\033[01;%dm",h+32);
					if (write_string_c(cad, color)<0)
						Error("[ntimes3_Ok::leer_cmd_output] Error writing stdout.");		
				}
			}
		}

		/* Receive cmd1 stderr */
		if (err!=0)
		{
			err = leer_cmd_error();
			if (err==0)
				open_pipes--;
		}

	} while(open_pipes>0);
}


/******************************************************************************/
/* Function name: leer_cmd_error     			   					          */
/* Description:   Read comand output from pipe and writting on stdout		  */
/* Parameters:    File/Pipe descriptor 									      */
/* Returns:		  0 if the err descriptor is closed.  					      */
/******************************************************************************/

int leer_cmd_error()
{
	int bread;
	char cad[201]; 
	
	if ( ((bread = read(pipe_err[0], &cad, 200))<0) && errno!=EAGAIN)
		Error("[ntimes3_Ok::leer_cmd_error] Error reading pipe.");
	else if (bread==0)
		return(0);
			
	if (bread>0)
	{
		cad[bread]='\0';				
		if (write_string_c(cad, color_red)<0)
			Error("[ntimes3_Ok::leer_cmd_error] Error writing stdout.");		
	}

	return(1);
}
