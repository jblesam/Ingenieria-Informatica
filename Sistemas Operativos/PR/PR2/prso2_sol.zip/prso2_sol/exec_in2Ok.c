#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <signal.h>

#include "rutines.h"

/* Functions definitions */
void alarm_management(int sig);

int main(int argc, char *argv[])
{
	char cmd[256];
	int pid;
	
	if (argc<2)
		Error("[exec_in2Ok::main] Insufficient arguments: exec_in <sec> <cmd> [args...]");

	// Wait until time.
	if ((pid=fork())<0) /* Create process */
		Error("[exec_in2Ok::main] Error in fork.");
	if (pid==0)
	{	/* Child process --> execute sleep command. */
		execlp("sleep", "sleep", argv[1], NULL);
		Error("[exec_in2Ok::main] Error in exec`lp.");
	}
	if (pid>0) /* Main process wait until child finish */ 
		wait(NULL);
	
	if (execvp(argv[2],&argv[2])<0)
		Error("exec_in2Ok::main] Error in command execution.");
	
	exit(0);
}

