#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdbool.h>

#include "rutines.h"

#define DMaxProcess 100

/* Functions definitions */
void sigquit_management(int sig);
void sigint_management(int sig);

/* Global variables */
int pid_cmd1[DMaxProcess], pid_cmderror=0, ntimes;
bool cmd1_enabled=true, cmd2_enabled=false;


int main(int argc, char *argv[])
{
	char cmd[256], *outfilesuffix=NULL, *errfilename=NULL;
	int a, h, cmd2, status, ntimes;

	if (argc<3)
		Error("[ntimes2_Ok::main] Insufficient arguments: after n <cmd1> [args,...] --error <cmd2> [args,...]");

	ntimes = atoi(argv[1]);
	if (ntimes>=100)
		Error("[ntimes2_Ok::main] Too many processes.");


	for (a=2;a<argc;a++)
	{
		if (strcasecmp(argv[a],"--error")==0)
		{
			cmd2 = a+1;
			argv[a]=NULL;
		}
		else
		if (strcasecmp(argv[a],"--out")==0){
			outfilesuffix = argv[a+1];
			argv[a]=NULL;
		}
		else
		if (strcasecmp(argv[a],"--err")==0) {
			errfilename = argv[a+1];
			argv[a]=NULL;
		}
	}

	for (h=0;h<ntimes;h++)
		pid_cmd1[h]=0;

	if (cmd2==0 || outfilesuffix==NULL || errfilename==NULL)
		Error("[ntimes2_Ok::main] Error in arguments:  missing --error, --out or --err");


	if (cmd1_enabled)	
	{
		for (h=0;h<ntimes && cmd1_enabled;h++)
		{
			if ((pid_cmd1[h]=fork())==0)
			{
				char outfilename[200];

				close(1);
				sprintf(outfilename, "%s%d", outfilesuffix,h+1);
				if (open(outfilename, O_WRONLY | O_CREAT | O_TRUNC, 00666)<0)
					Error("[ntimes2_Ok::main] Error opening standard output file.");

				close(2);
				if (open(errfilename, O_WRONLY | O_CREAT | O_APPEND, 00666)<0)
					Error("[ntimes2_Ok::main] Error opening standard error file.");
				
				// Child1 -> First command.
				execvp(argv[2],&argv[2]);
				Error("[ntimes2_Ok::main] Error lauching first command.");
			}
		}
		for (h=0;h<ntimes;h++)
		{
			if (wait(&status)<0)
				Error("[ntimes2_Ok::main] Error executing first command.");
			
			if (!WIFEXITED(status) || (WIFEXITED(status) && WEXITSTATUS(status)!=0))
				cmd2_enabled=true;
				
			pid_cmd1[h]=0;
		}
	}

	if (cmd2_enabled)	
	{	
		if ((pid_cmderror=fork())==0)
		{
			close(2);
			if (open(errfilename, O_WRONLY | O_CREAT | O_APPEND, 00666)<0)
				Error("[ntimes2_Ok::main] Error opening standard error file.");
				
			// Child2 -> Second command.
			execvp(argv[cmd2],&argv[cmd2]);
			Error("[ntimes2_Ok::main] Error lauching second command.");
		}
	
		if (wait(&status)<0)
			Error("[ntimes2_Ok::main] Error executing second command.");
			
		pid_cmderror=0;
	}

	exit(0);
}

