/*
 * rutines.h
 */

#ifndef RUTINES_H_
#define RUTINES_H_

#include <errno.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>


/* Global variables */
char *color_purple = "\033[00;35m";
char *color_blue = "\033[01;34m";
char *color_red = "\033[01;31m";
char *color_end = "\033[00m";

/* Constant Definitions */
#define MAXSTR 256
#define DEBUG false
#define D_MESSAGE_COLOR color_blue

/* Functions prototypes*/
void Error(char *str);
int write_string(char *str, int len);
int write_string_c(char *message, char *color);


/******************************************************************************/
/* Function name: error                                                     	*/
/* Description:   Writes a error message and finish the execution		     		*/
/* Parameters:    Error message (message)                                   	*/
/******************************************************************************/

void Error(char *str)
{
	char buff[MAXSTR];
	
	write(2, color_red, strlen(color_red));
  	snprintf (buff, MAXSTR, "[%d] (%d:%s) %s\n", getpid(), errno, strerror (errno), str);
  	write (2, buff, strlen (buff));
  	write(2, color_end, strlen(color_end));
  	exit (1);
}



/******************************************************************************/
/* Function name:	write_string																*/
/* Description: 	Write an information message and a string in the std output	*/
/* Parameters:		The information message (message) and the color string		*/
/******************************************************************************/

int write_string(char *str, int len)
{
	char buff[MAXSTR];
  	
  	str[len]='\0';
	return(write_string_c(str, D_MESSAGE_COLOR));
}



/******************************************************************************/
/* Function name:	write_string_c																*/
/* Description: 	Write an information message and a string in the std output	*/
/* Parameters:		The information message (message) and the color string		*/
/******************************************************************************/

int write_string_c(char *message, char *color)
{
    write(1, color, strlen(color));	
    write(1, message, strlen(message));
    write(1, color_end, strlen(color_end));
  	
  	return(1);
}


#endif /* RUTINES_H_ */
