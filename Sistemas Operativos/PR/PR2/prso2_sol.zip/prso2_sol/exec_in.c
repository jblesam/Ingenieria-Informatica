#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>

#include "rutines.h"

int main(int argc, char *argv[])
{
	char cmd[256];
	int a;
	
	if (argc<2)
		Error("Insufficient arguments: exec_in <sec> <cmd> [args...]");
		
	sleep(atoi(argv[1]));
	
	cmd[0]='\0';
	for(a=2;a<argc;a++)
	{
		strcat(cmd,argv[a]);
		strcat(cmd," ");
	}
	
	system(cmd);
		
	exit(0);
}


