#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#define rfib(x) rfib2(x,1,0)

long int rfib2(long int n, int val, int prev);

#define DMaxLevel 261800

int main (int argc, char *argv[])
{
	long int n;
	char str[50];

	// Verify that the user entered the correct arguments.
	// If not show an error.
	if (argc>1)					
		n = atol(argv[1]);
  	else {
		write(2,"Error in parameters.\n Usage: fib <number>.\n",strlen("Error in parameters.\n Usage: fib <number>.\n"));
		exit(1);
	}
		
	// We control the maximum level of recursivity
	if (n>=0 && n<DMaxLevel) {
		sprintf(str,"Fibonacci %ld-th number -> %ld.\n",n, rfib(n));
		write(1,str,strlen(str));
	}
	
	exit(0);
}


long int rfib2(long int n, int val, int prev)
{
	if (n==0)
		return prev;

	if (n==1)
		return val;

	return rfib2(n-1, val+prev, val);
}
