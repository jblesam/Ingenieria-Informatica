#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

long int rfib(long int n);

int main (int argc, char *argv[])
{
	long int n;
	char str[50];

   	// Verify that the user entered the correct arguments.
	// If not show an error.
	if (argc>1)					
		n = atol(argv[1]);
  	else {
		write(2,"Error in parameters.\n Usage: fib <number>.\n",strlen("Error in parameters.\n Usage: fib <number>.\n"));
		exit(1);
	}
		
	sprintf(str,"Fibonacci %ld-th number -> %ld.\n",n, rfib(n));
	write(1,str,strlen(str));
	
	exit(0);
}



// Calculate the fibonacci series iteratively.
long int rfib(long int n)
{
	long int val,val_1,val_2,x;
	
	if (n==0)
		return 0;

	if (n==1)
		return 1;

	val_2=0;
	val_1=1;
	for (x=1;x<n;x++) 
	{
		val = val_1 + val_2;
		val_2 = val_1;
		val_1 = val;
	}
	
	return(val);
}
