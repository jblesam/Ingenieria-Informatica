#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#define rfib(x) rfib2(x,1,0)

long int rfib2(long int n, int val, int prev);

int main (int argc, char *argv[])
{
	long int n;
	char str[30];

	n = atol(argv[1]);

	sprintf(str,"Fibonacci %ld-th number -> %ld.\n",n, rfib(n));
	write(1,str,strlen(str));
	
	exit(0);
}


long int rfib2(long int n, int val, int prev)
{
	if (n==0)
		return prev;

	if (n==1)
		return val;
	
	return rfib2(n-1, val+prev, val);
}
