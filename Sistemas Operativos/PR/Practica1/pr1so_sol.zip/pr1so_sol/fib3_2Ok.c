#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#define rfib(x) rfib2(x,1,0)

long int rfib2(long int n, long int val, long int prev);
void fibonacci(int fdin, int fdout);
int read_number(int fd, long int *n, int max);

int main (int argc, char *argv[])
{
	long int n;
	char *filein=NULL, *fileout=NULL;
	int fdin=-1,fdout=-1;

	if (argc > 1)
		filein = argv[1];

	if (argc > 2)
		fileout = argv[2];

	if (filein!=NULL)
		fdin = open(filein, O_RDONLY);
	else
		fdin = 0 ; // read from stdin

	if (fdin<0) {
		perror("Error opening filein. ");
		exit(1);
	}

	if (fileout!=NULL)
		fdout = open(fileout, O_WRONLY | O_CREAT | O_TRUNC, 0660);
	else
		fdout = 1 ; // write result on stdout

	if (fdout<0) {
		perror("Error opening fileout.");
		exit(2);
	}

	if (fdin<0 || fdout<0) {  // Write error messagen on stderr
		write(2,"Error in arguments: fib3 FileIn FileOut.\n",strlen("Error in arguments: fib3 FileIn FileOut.\n"));
		exit(3);
   }
		
	fibonacci(fdin, fdout);

	if (fdin>0)
		close(fdin);

	if (fdout>2)
		close(fdout);
	
	exit(0);
}


void fibonacci(int fdin, int fdout)
{
	long int n, fab;
	char str[30];
	int ret;

	while((ret=read_number(fdin, &n, 30))>=0)
	{
		if (ret>0) 
		{ 
			fab = rfib(n);
			sprintf(str,"%ld\n",fab);
			if (write(fdout, str, strlen(str))<0)  { 
				// Write error messagen on stderr
				perror("Error writting in output file. ");
				exit(4);
			}
		}
	}
}


long int rfib2(long int n, long int val, long int prev)
{
	if (n==0)
		return prev;

	if (n==1)
		return val;
	
	return rfib2(n-1, val+prev, val);
}


int read_number(int fd, long int *n, int max)
{
	char number_str[30];
	int ret,ret2, x=0;
	
	strcpy(number_str,"");
	while( (ret=read(fd,&number_str[x++],1))>0 && number_str[x-1]!=' ' && number_str[x-1]!='\n' && x<max);
	number_str[x]='\0';
	
	if (ret<0)
		return(ret);
	else 
	{
		ret2=sscanf(number_str,"%ld", n);
		if (ret2<=0 && ret<=0)
			return(-1);
		else
			return(ret2);
	}
}

