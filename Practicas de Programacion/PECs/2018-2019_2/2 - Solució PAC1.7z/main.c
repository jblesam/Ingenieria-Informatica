#include "cellar.h"


/**************************************************************************/
  int main (void)
/**************************************************************************/
{
  tCellar c;
  int ret;

  /* section a */
  init_cellar(&c);

  /* section b */
  printf("\n Section b\n");
  ret=add_wine_set (&c, 100, "Blue Cherry", red, "Bretagne", 14.5, 20, 35.0);
  if (ret>0) {
  	add_grape(&c, 100, "Cabernet Sauvignon");
  	add_grape(&c, 100, "Merlot");
  	add_grape(&c, 100, "Cabernet Franc");
  }

  ret=add_wine_set (&c, 200, "White cloud", white, "Provence", 13.0, 6, 22.0);
  if (ret>0) add_grape(&c, 200, "Chardonnay");
 
  ret=add_wine_set (&c, 300, "Green Asparragus", red, "Bordeaux", 13.5, 8, 18.0);
  if (ret>0) {
	add_grape(&c, 300, "Tempranillo");
  	add_grape(&c, 300, "Cabernet Sauvignon");
  }
 
  ret=add_wine_set (&c, 200, "Old Castle", white, "Languedoc", 12.5, 5, 20.0);
  if (ret>0) {
	add_grape(&c, 200, "White Sauvignon");
  	add_grape(&c, 200, "Verdejo");
  } 


  /* section c */
  printf("\n Section c\n");
  add_wine_stock(&c, 300, standard, 28);
  add_wine_stock(&c, 100, half, 60);
  add_wine_stock(&c, 300, standard, 7);
  add_wine_stock(&c, 100, standard, 85);
  add_wine_stock(&c, 400, standard, 100);

  /* section d */
  printf("\n Section d\n");
  print_wine_list(c);

  return 0;
}
