#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

/* Constants *********************************************************/

#define MAXGRAPES 5
#define MAXWINES 80
#define MAXCHAR 100

/* Types *************************************************************/

typedef enum {false, true} bool;
typedef enum {standard, half, split} tFormat;
typedef enum {red, white, dessert} tWineType;

typedef char string[MAXCHAR+1];

typedef struct {
	string grapes[MAXGRAPES];
	int    numGrapes;
} tGrapeSet;

typedef struct {
	int       id;
	string    brand;
	tGrapeSet grapeSet;
	tWineType type;
	string	  areaDO;
        float     alcoholDegree;
        int	  holdingTime;
	float     price;
} tWine;

typedef struct {
	int 	idWine;
	tFormat format;
	int	numBoxes;
} tStock;

typedef struct {
	int     idClient;
	int     idWine;
	tFormat format;
	int     numBoxes;
} tOrder;

typedef struct {
	tOrder *orderSet;
	int numOrders;
	tWine wineSet[MAXWINES];
	int numWines;
	tStock *stockSet;
	int numStock;
} tCellar;

/* Functions *********************************************************/

void    init_cellar (tCellar *c);
tWine   create_wine (int id, string b, tWineType t, string DO, float p, int h, float pr);
void    add_grape (tCellar *c, int idWine, string g);
int    add_wine_set (tCellar *c, int id, string b, tWineType t, string DO, float p, int h, float pr);
void    add_wine_stock (tCellar *c, int id, tFormat f, int n);
void    print_wine_list (tCellar c);
