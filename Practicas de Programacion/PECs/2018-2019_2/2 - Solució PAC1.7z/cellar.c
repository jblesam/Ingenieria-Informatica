#include "cellar.h"

/* Auxiliary functions ****************************************************/

/**************************************************************************/
  bool find_grape (tGrapeSet g, string name)
/**************************************************************************/
{
  bool found;
  int  i;

  i     = 0;
  found = false;
  while ((i < g.numGrapes) && !found) {
        found = (strcmp (g.grapes[i], name)==0);
        i++;
  }

  return found;
}

/**************************************************************************/
  tWine *find_wine_set (tCellar c, int id)
/**************************************************************************/
{
  tWine *res;
  int  i;

  i   = 0;
  res = NULL;
  while ((i < c.numWines) && (res == NULL)) {
        if (c.wineSet[i].id == id) 
           res = &(c.wineSet[i]);
        else
           i++;
  }

  return res;
}

/**************************************************************************/
 tStock *find_wine_stock (tCellar c, int id, tFormat f)
/**************************************************************************/
{
  int  i;
  tStock *res;

  i   = 0;
  res = NULL;
  while ((i < c.numStock) && (res==NULL)) {
        if ((c.stockSet[i].idWine == id) && (c.stockSet[i].format == f)) 
            res = &(c.stockSet[i]);
	i++;
  }

  return res;
}


/* Demanded functions ****************************************************/

/**************************************************************************/
  void init_cellar (tCellar *c)
/**************************************************************************/
{
  /* Check PRE conditions */
  assert(c != NULL);

  /* Empty structures */
  c->numOrders   = 0;
  c->numWines    = 0;
  c->numStock    = 0;
}

/**************************************************************************/
  void    add_grape (tCellar *c, int idWine, string g)
/**************************************************************************/
{
  /* Check PRE conditions */
  assert(c != NULL);
  assert(idWine >= 0);

  tWine *w;

  /* Search the wine */
  w=find_wine_set(*c, idWine);
  if (w==NULL)
        printf("ERROR: Wine %d already doesn't belong to the cellar \n", idWine);
  else {
  	/* Search the grape */
  	if (find_grape (w->grapeSet, g))
        	printf("ERROR: Grape %s already belong to this wine\n", g);
    	else {
        	/* It does not exist, add it to the set */
		strcpy(w->grapeSet.grapes[w->grapeSet.numGrapes], g);
		w->grapeSet.numGrapes ++;
	}
  }
}

/****************************************************************************************************/
  int    add_wine_set (tCellar *c, int id, string b, tWineType t, string DO, float p, int h, float pr)
/****************************************************************************************************/
{
    /* Check PRE conditions */
    assert(c != NULL);
    assert(c->numWines < MAXWINES);
    assert(id >= 0);
    assert(t==red || t==white || t==dessert);
    assert(p > 0);        
    assert(h > 0);
    assert(pr >= 0.0);    

    int res;
    int index;
    tWine *w;

    /* Search the wine */
    if (find_wine_set (*c, id) != NULL) {
        printf("ERROR: Wine %d already belong to the cellar \n", id);
        res = -1;
    }
    else {
        /* Add the wine to the set of wines and with an empty set of grapes */        
	index = c->numWines;
	c->wineSet[index].id = id;
	strcpy (c->wineSet[index].brand, b);
  	c->wineSet[index].grapeSet.numGrapes = 0;
  	c->wineSet[index].type = t;
  	strcpy(c->wineSet[index].areaDO, DO);
  	c->wineSet[index].alcoholDegree = p;
  	c->wineSet[index].holdingTime = h;
        c->wineSet[index].price = pr;
	c->numWines++;	
        res = c->numWines;
    }
    return res;
}

/**************************************************************************/
  void    add_wine_stock (tCellar *c, int id, tFormat f, int n)
/**************************************************************************/
{
    /* Check PRE conditions */
    assert(c != NULL);
    assert(id >= 0);
    assert(f == standard || f == half || f == split);
    assert(n > 0);

    tStock *s;

    /* Search the wine */
    if (find_wine_set (*c, id) == NULL)
        printf("ERROR: Wine %d does not belong to the cellar \n", id);
    else { 
        s = find_wine_stock (*c, id, f);
        if (s!=NULL) {
       	   /* If it exists, update the number of units */
	   s->numBoxes += n;
        }
        else {
           /* If it does not exist, allocate space */
           if (c->numStock == 0)
               c->stockSet = (tStock *) malloc(sizeof(tStock));
           else 
               c->stockSet = (tStock *) realloc(c->stockSet, (c->numStock+1)*sizeof(tStock));

      	   /* If it is ok, then add the wine to the stock */        
           if (c->stockSet == NULL)
      	    	printf("ERROR: Memory error\n");
           else {
               c->stockSet[c->numStock].idWine = id;
               c->stockSet[c->numStock].format = f;
               c->stockSet[c->numStock].numBoxes = n;
               c->numStock++;
	   }
        }
    }
}

/**************************************************************************/
  void print_wine_list (tCellar c)
/**************************************************************************/
{
  int  i, j;
  tWine w;
  int n;
 
  printf("\n");

  for (i=0; i<c.numWines; i++) {
      /* for each wine in the set */
      w = c.wineSet[i];

      printf("id:%d  ", w.id);
      printf("brand: %s", w.brand);
      if (w.type==red) printf("\t type: Red");
      else if (w.type==white) printf("\t type: White");
      else printf("\t type: Dessert");

      /* stock information */
      n=0;
      for (j=0; j<c.numStock; j++) {
	if (c.stockSet[j].idWine == w.id) {
        	printf("\n");
		if (c.stockSet[j].format==standard) printf("\t format: standard");
		else if (c.stockSet[j].format==half) printf("\t format: half");
		else printf("\t format: split");

		printf("\t num boxes: %d", c.stockSet[j].numBoxes);

		n++;
	}
      }
      if (n==0) printf("\n\t No stock for this wine\n");
      else printf("\n");

      printf("\n");
  }

}

