#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include "ranking.h"
#include "competition.h"

// Get stadistics for a team
tError ranking_getTeamStadisitics(tCompetition* object, const char* team_name, tTeamStadistics *stadistics){
    // PR3 EX1
    // return ERR_NOT_IMPLEMENTED;
    
    // Check preconditions
    assert(object != NULL);
    assert(team_name != NULL);
    assert(stadistics != NULL);
    
    // Find team
    if (competition_findTeam(object, team_name) == NULL) {
        return ERR_INVALID_TEAM;
    }
    
    // Get team score
    stadistics->score = competition_getTeamScore(object, team_name);

    // Get team wins
    stadistics->num_Wins = competition_getTeamWins(object, team_name);
    
    // Get team draws
    stadistics->num_Draws = competition_getTeamDraws(object, team_name);
        
    // Get team points. Calculated with wins and draws instead of competition_getTeamPoints for optimize calculations
    stadistics->points = stadistics->num_Wins*3 + stadistics->num_Draws;
    
    return OK;
}

// Compare stadistics of two teams to get the order in the ranking.
// 0 equal ranking, 1 stadistics1 wins, -1 stadistics2 wins
int ranking_compareStadistics(tTeamStadistics* stadistics1, tTeamStadistics* stadistics2)
{
    // PR3 EX1
    // return ERR_NOT_IMPLEMENTED;
    
    // Check preconditions
    assert(stadistics1 != NULL);
    assert(stadistics2 != NULL);
    
    // Team with more points goes first
    if (stadistics1->points > stadistics2->points){
        return 1;
    }
    else if (stadistics2->points > stadistics1->points){
        return -1;
    }
    else{
        // Same points. The team with more Wins goes first
        if (stadistics1->num_Wins > stadistics2->num_Wins){
            return 1;
        }
        else if (stadistics2->num_Wins > stadistics1->num_Wins){
            return -1;
        }
        else{
            // Same points and wins. The team with bigger score goes first
            if (stadistics1->score > stadistics2->score){
                return 1;
            }
            else if (stadistics2->score > stadistics1->score){
                return -1;
            }
            else{
                // Teams has equal ranking
                return 0;
            }
        }
    }
}

// Gets the stadistics of a team and create the ranking
tError ranking_createTeamRanking(tCompetition* competition, const char* team_name, tRanking *dst){
    // PR3 EX2
    // return ERR_NOT_IMPLEMENTED;
    
    // Check preconditions
    assert(competition != NULL);
    assert(team_name != NULL);
    assert(dst != NULL);
    
    tTeam* team;
    tError err;
    
    // Find team
    team = competition_findTeam(competition, team_name);
    if (team == NULL) {
        return ERR_INVALID_TEAM;
    }
    
    // Reserve memory
    dst->stadistics = (tTeamStadistics*) malloc(sizeof(tTeamStadistics));
    if (dst->stadistics == NULL){
        return ERR_MEMORY_ERROR;
    }
    
    // Get team stadistics
    err = ranking_getTeamStadisitics(competition, team_name, dst->stadistics);
    if (err == OK){
        // Set team. No need to reserve memory because we have only one copy of every team stored on memory
        dst->team = team;
    }
    
    return err;
}

// Create the ranking list
void rankingList_createList(tRankingList* list){
    // PR3 EX2
    // return ERR_NOT_IMPLEMENTED;
    
    // Check preconditions
    assert(list != NULL);

    // Assign pointers to NULL
    list->first = NULL;
}

// Gets ranking node from given position
tRankingListNode* rankingList_getNode(tRankingList* list, int index){
    // PR3 EX2
    // return ERR_NOT_IMPLEMENTED;
    
    // Check preconditions
    assert(list != NULL);
    assert(index > 0);
    
    int i;
    tRankingListNode *prev;

    i = 1;
    prev = list->first;
    while (i<index && (prev!=NULL)) {
        prev = prev->next;
        i++;
    }

    return prev;
}

// Insert/adds a new ranking to the ranking list
tError rankingList_insert(tRankingList* list, tRanking ranking, int index){
    // PR3 EX2
    // return ERR_NOT_IMPLEMENTED;
    
    // Check preconditions
    assert(list != NULL);
    assert(index > 0);
    
    tRankingListNode *tmp;
    tRankingListNode *prev;
    
    tmp = (tRankingListNode*) malloc(sizeof(tRankingListNode));
    if (tmp==NULL) {
        return ERR_MEMORY_ERROR;
    }
    else {  
        tmp->e = ranking;
        if (index==1) {
            // no previous element
            tmp->next = list->first;
            list->first = tmp;
        }
        else {  
            prev = rankingList_getNode(list, index-1);
            if (!(prev==NULL))  {
                // standard case
                tmp->next=prev->next;
                prev->next=tmp;
            }     
            else {
                return ERR_INVALID_INDEX;
            }
        }
    }

    return OK;
}

// Insert/adds a new ranking to the ranking list
tError rankingList_delete(tRankingList* list, int index){
    // PR3 EX2
    // return ERR_NOT_IMPLEMENTED;
    
    // Check preconditions
    assert(list != NULL);
    assert(index > 0);

    tRankingListNode *tmp;
    tRankingListNode *prev;

    if (index==1) {
        // no previous element
        tmp = list->first;
        if (tmp == NULL) {
            return ERR_EMPTY_LIST;
        }
        else {
            list->first=tmp->next;
            free(tmp);
        }
    }
    else {
        prev = rankingList_getNode(list, index-1);
        if (!(prev==NULL)) {
            // standard case
            tmp = prev->next;
            if (tmp==NULL) {
                return ERR_INVALID_INDEX;
            }
            else {
                prev->next = tmp->next;
                free(tmp);
            }
        }
        else {
            return ERR_INVALID_INDEX;
        }
    }
        
    return OK;
}

// Gets ranking from given position
tRanking* rankingList_get(tRankingList* list, int index){
    // PR3 EX2
    // return ERR_NOT_IMPLEMENTED;
    
    // Check preconditions
    assert(list != NULL);
    assert(index > 0);
    
    tRankingListNode* curr;
    curr = rankingList_getNode(list, index);
    if (curr == NULL) {
        return NULL;
    }
    else {
        return &curr->e;
    }
}

// Gets true if list is empty
bool rankingList_empty(tRankingList* list){
    // PR3 EX2
    // return ERR_NOT_IMPLEMENTED;
    
    // Check preconditions
    assert(list != NULL);
    return (list->first == NULL);
}

// Remove all data for a ranking list
void rankingList_free(tRankingList* list){
    // PR3 EX2
    // return ERR_NOT_IMPLEMENTED;
    
    // Check preconditions
    assert(list != NULL);
    
    // Delete all elements from the list
    while (!rankingList_empty(list)){
        rankingList_delete(list, 1);
    }
}

// Get team with better stadistics
tTeam* rankingList_getBestTeam(tRankingList* list){
    // PR3 EX3
    //return NULL;
    
    // Check preconditions
    assert(list != NULL);
    
    tRankingListNode* current;
    tRanking max_Ranking;
    
    if (rankingList_empty(list)){
        // Empty list
        return NULL;
    }
	
    else{
        // Initialize first element as max value
        current = list->first;
        max_Ranking = current->e;
        
        // Loop all elements
        while (current!=NULL) {
            // Check if next element from list is better than current max value
			// 0 equal ranking, 1 stadistics1 wins, -1 stadistics2 wins
            if (ranking_compareStadistics(current->e.stadistics, max_Ranking.stadistics) == 1){
                max_Ranking = current->e;
            }
            current = current->next;
        }
            
        // Returns team with max stadistics
        return max_Ranking.team;
    }
}

// Get team with worst stadistics
tTeam* rankingList_getWorstTeam(tRankingList* list){
    // PR3 EX3
    assert(list != NULL);
    
    tRankingListNode* current;
    tRanking min_Ranking;
    
    if (rankingList_empty(list)){
        // Empty list
        return NULL;
    }
    else{
        // Initialize first element as min value
        current = list->first;
        min_Ranking = current->e;
        
        // Loop all elements
        while (current!=NULL) {
            // Check if next element from list is worse than current max value
            // 0 equal ranking, 1 stadistics1 wins, -1 stadistics2 wins
            if (ranking_compareStadistics(current->e.stadistics, min_Ranking.stadistics) == -1){
                min_Ranking = current->e;
            }
            current = current->next;
        }
            
        // Returns team with max stadistics
        return min_Ranking.team;
    }
}

tError rankingList_insert_sorted(tRankingList* list, tRanking ranking)
{
    // Check preconditions
    //return ERR_NOT_IMPLEMENTED;

    assert(list != NULL);

    tRankingListNode *current;
    tRankingListNode *new_node;
    
    new_node = (tRankingListNode*) malloc(sizeof(tRankingListNode));

    if (new_node==NULL) {
        return ERR_MEMORY_ERROR;
    }
	
	if(list->first==NULL) //Executes when linked list is empty
	{		
		new_node->e = ranking;
		new_node->next = NULL;
				
		list->first = new_node;
		return OK;
	} 
	
	if(ranking_compareStadistics(ranking.stadistics,list->first->e.stadistics)==1)
	{
		//Executes if given data is less than data in first node of linked list
		new_node->e = ranking;
		new_node->next = list->first;
		list->first = new_node;
		
		return OK;
	} 
	
	else
	{
		//Other cases even to put in the last position
		current = list->first;
		new_node->e = ranking;
		
		// 0 equal ranking, 1 stadistics1 wins, -1 stadistics2 wins
		while(current->next!= NULL)// && (ranking_compareStadistics(current->e.stadistics,new_node->e.stadistics)> 0))
		{
			if (ranking_compareStadistics(current->next->e.stadistics,new_node->e.stadistics)== -1)
			{
				new_node->next = current->next;
				current->next = new_node;
				
				return OK;
			}
			
			else
			{
				current = current->next;
			}
		}
		
		//last position
		new_node->e = ranking;
		new_node->next = NULL;
		current->next = new_node;
		
		return OK;
	}

}

//Sort list according to team stadistics
tRankingList* rankingList_sortInsertion(tRankingList *list){
    // PR3 EX3
    tRankingList *sortedlist;
    tRankingListNode *current;

    sortedlist = (tRankingList *)malloc(sizeof(tRankingList));

    rankingList_createList(sortedlist);
    current = list->first;

    while(current != NULL)
    {
        rankingList_insert_sorted(sortedlist, current->e);
        current = current->next;
    }

    return sortedlist;
}

