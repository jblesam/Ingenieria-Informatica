#ifndef __TEST_SUIT_H__
#define __TEST_SUIT_H__

#include "test_pr1.h"
#include "test_pr2.h"
#include "test_pr3.h"

// Run all available tests
bool run_all(tTestSuite* test_suite);

#endif // __TEST_SUIT_H__