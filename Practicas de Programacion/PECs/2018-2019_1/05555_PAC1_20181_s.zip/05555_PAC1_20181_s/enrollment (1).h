#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

/* Constants *********************************************************/

#define MAX_LEVELS   3
#define MAX_OPTIONS  4
#define MAX_CAPACITY 30
#define MAX_CHAR     100

/* Types *************************************************************/

typedef enum {false, true} bool;
typedef enum {open, closed, unknown} tFacility;
typedef enum {accepted, denied, pending} tStatus;

typedef char string[MAX_CHAR+1];

typedef struct {
    int     idChild;
    int     idNursery;
    int     points;
    tStatus status;
} tApplication;

typedef struct {
    int          id;
    string       name;
    int          age;
    int          idCity;
    int          idDistrict;
    tApplication applications[MAX_OPTIONS];
    int          numApp;
} tChild;

typedef struct {
    int           id;
    int           places;
    tApplication  assigned[MAX_CAPACITY];
    int           numAssign;
    tApplication *waiting;
    int           numWait;
} tLevel;

typedef struct {
    int       id;
    string    name;
    int       idCity;
    int       idDistrict;
    tFacility status;
    tLevel    levels[MAX_LEVELS];
    int       numLev;
} tNursery;

typedef struct {
    tChild   *children;
    int       numChild;
    tNursery *nurseries;
    int       numNurs;
} tEnrollment;

/* Functions *********************************************************/

void init_enrollment (tEnrollment *e);
void new_nursery     (tEnrollment *e, int id, string name, tFacility stat, int idCity, int idDist);
void new_child       (tEnrollment *e, int id, string name, int age, int idCity, int idDist);
void add_application (tEnrollment *e, int idChild, int idNurs);
void print_children  (tEnrollment e);

