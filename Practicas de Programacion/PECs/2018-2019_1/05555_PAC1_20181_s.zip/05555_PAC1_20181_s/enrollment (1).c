#include "enrollment.h"

/* Auxiliary functions ****************************************************/

/**************************************************************************/
  tNursery *find_nursery (tEnrollment e, int code)
/**************************************************************************/
{
  tNursery *n;
  int  ii;

  ii = 0;
  n  = NULL;
  while ((ii < e.numNurs) && (n == NULL)) {
        if (e.nurseries[ii].id == code)
           n = &(e.nurseries[ii]);
        else
           ii++;
  }

  return n;
}

/**************************************************************************/
  tChild *find_child (tEnrollment e, int code)
/**************************************************************************/
{
  tChild *c;
  int  ii;

  ii = 0;
  c  = NULL;
  while ((ii < e.numChild) && (c == NULL)) {
        if (e.children[ii].id == code)
           c = &(e.children[ii]);
        else
           ii++;
  }

  return c;
}

/**************************************************************************/
  tApplication *find_application (tChild c, int idNurs)
/**************************************************************************/
{
  tApplication *a;
  int  ii;

  ii = 0;
  a  = NULL;
  while ((ii < c.numApp) && (a == NULL)) {
        if (c.applications[ii].idNursery == idNurs)
           a = &(c.applications[ii]);
        else
           ii++;
  }

  return a;
}

/* Demanded functions ****************************************************/

/**************************************************************************/
  void init_enrollment (tEnrollment *e)
/**************************************************************************/
{
  /* Check PRE conditions */
  assert(e != NULL);

  /* Empty structures */
  e->numChild = 0;
  e->numNurs  = 0;

}

/**************************************************************************/
  void new_nursery (tEnrollment *e, int id, string name, tFacility stat, int idCity, int idDist)
/**************************************************************************/
{
  /* Check PRE conditions */
  assert(e != NULL);
  assert(id > 0);
  assert(idCity > 0);
  assert(idDist >= 0);

  /* Search the nursery */
  if (find_nursery (*e, id) != NULL)
      printf("ERROR: Nursery %i is already stored\n", id);
  else {
      /* It does not exist, allocate space */
      if (e->numNurs == 0)
          e->nurseries = (tNursery *) malloc(sizeof(tNursery));
      else 
          e->nurseries = (tNursery *) realloc(e->nurseries, (e->numNurs+1)*sizeof(tNursery));

      /* If it is ok, then add the nursery to the enrollment process*/        
      if (e->nurseries == NULL)
	      printf("ERROR: Memory error\n");
      else {
	      e->nurseries[e->numNurs].id         = id;
	      e->nurseries[e->numNurs].idCity     = idCity;
	      e->nurseries[e->numNurs].idDistrict = idDist;
	      e->nurseries[e->numNurs].status     = stat;
	      e->nurseries[e->numNurs].numLev     = 0;
	      strcpy(e->nurseries[e->numNurs].name, name);
	      e->numNurs++;
      }
  }
}

/**************************************************************************/
  void new_child (tEnrollment *e, int id, string name, int age, int idCity, int idDist)
/**************************************************************************/
{
  /* Check PRE conditions */
  assert(e != NULL);
  assert(id > 0);
  assert((age >= 0) && (age < MAX_LEVELS));
  assert(idCity > 0);
  assert(idDist >= 0);

  /* Search the child */
  if (find_child (*e, id) != NULL)
      printf("ERROR: Child %i is already stored\n", id);
  else {
      /* It does not exist, allocate space */
      if (e->numChild == 0)
          e->children = (tChild *) malloc(sizeof(tChild));
      else 
          e->children = (tChild *) realloc(e->children, (e->numChild+1)*sizeof(tChild));

      /* If it is ok, then add the child to the enrollment process*/        
      if (e->children == NULL)
	      printf("ERROR: Memory error\n");
      else {
	      e->children[e->numChild].id         = id;
	      e->children[e->numChild].age        = age;
	      e->children[e->numChild].idCity     = idCity;
	      e->children[e->numChild].idDistrict = idDist;
	      e->children[e->numChild].numApp     = 0;
	      strcpy(e->children[e->numChild].name, name);
	      e->numChild++;
      }
  }
}

/**************************************************************************/
  void add_application (tEnrollment *e, int idChild, int idNurs)
/**************************************************************************/
{
  tChild   *c;
  tNursery *n;
  int      ii, points;
  int      repeated;  

  /* Check PRE conditions */
  assert(e != NULL);
  assert(idChild > 0);
  assert(idNurs > 0);

  /* Search the child */
  c = find_child (*e, idChild);
  if (c == NULL)
      printf("ERROR: Child %i is not stored in the enrollment\n", idChild);
  else { 
      /* Check there is enough space */
      if (c->numApp == MAX_OPTIONS)
          printf("ERROR: Child %i has the maximum number of applications\n", idChild);
      else {
          /* Check it is not repeated */
          if (find_application (*c, idNurs) != NULL)
              printf("ERROR: Application (Child %i, Nursery %i) is already stored\n", idChild, idNurs);
          else  {
              /* Search the nursery */
              n = find_nursery (*e, idNurs);
              if (n == NULL)
                  printf("ERROR: Nursery %i is not stored in the enrollment\n", idNurs);
              else  {
                  /* Calculate the score */
                  if (c->idCity == n->idCity) 
                     if (c->idDistrict == n->idDistrict) points = 20;
                      else points = 10;
                  else points = 0;
  
                  c->applications[c->numApp].idChild   = idChild;
                  c->applications[c->numApp].idNursery = idNurs;
                  c->applications[c->numApp].status    = pending;
                  c->applications[c->numApp].points    = points;
                  c->numApp++;
              }
          }
      }
  }
}


/**************************************************************************/
  void print_children  (tEnrollment e)
/**************************************************************************/
{
  tChild       c;
  tApplication a;
  int          ii, jj;

  printf("\n");

  for (ii=0; ii<e.numChild; ii++) 
  {
      /* for each child in the enrollment */
      c = e.children[ii];

      printf("%d.\t%s\n", c.id, c.name);
      for (jj=0; jj<c.numApp; jj++) 
      {
	       a = c.applications[jj];
 	       printf("\t%d.\tNursery: %d\tPoints:%d\n", jj+1, a.idNursery, a.points);
      }
      printf("\n");
  }

  printf("\n");
}

