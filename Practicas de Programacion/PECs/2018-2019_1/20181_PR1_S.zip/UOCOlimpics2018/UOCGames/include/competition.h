#ifndef __COMPETITION_H__
#define __COMPETITION_H__

#include "team.h"
#include "player.h"

// Definition of a competition
typedef struct {
    tTeamTable teams;
    tPlayerTable players;    
} tCompetition;

// Initialize the competition
void competition_init(tCompetition* object);

// Remove all data for a competition
void competition_free(tCompetition* object);

// Register a new player
tError competition_registerPlayer(tCompetition* object, const char* username, const char* name, const char* mail);

// Remove a player
tError competition_removePlayer(tCompetition* object, const char* username);

// Find a player
tPlayer* competition_findPlayer(tCompetition* object, const char* username);

// Register a new team
tError competition_registerTeam(tCompetition* object, const char* team_name, const char* username);

// Remove a player
tError competition_removeTeam(tCompetition* object, const char* team_name);

// Find a team
tTeam* competition_findTeam(tCompetition* object, const char* team_name);

#endif // __COMPETITION_H__