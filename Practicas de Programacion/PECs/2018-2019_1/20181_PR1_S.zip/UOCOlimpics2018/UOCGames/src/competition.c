#include <stdlib.h>
#include "competition.h"

// Initialize the competition
void competition_init(tCompetition* object) {
    // PR1 EX3
    
    // Initialize players and team tables
    playerTable_init(&object->players);
    teamTable_init(&object->teams);
}

// Remove all data for a competition
void competition_free(tCompetition* object) {
    // PR1 EX3
    
    // Remove data from  players and team tables
    playerTable_free(&object->players);
    teamTable_free(&object->teams);
}

// Register a new player
tError competition_registerPlayer(tCompetition* object, const char* username, const char* name, const char* mail) {
    // PR1 EX3
    //return ERR_NOT_IMPLEMENTED;
    
    tPlayer player;
    tError err;
    
    // Check if the player already exists
    if(playerTable_find(&object->players, username) != NULL) {
        return ERR_DUPLICATED_USERNAME;
    }
    
    // Initialize a player with the data
    err = player_init(&player, username, name, mail);
    if(err != OK) {
        return err;
    }
    
    // Add the player to the table
    err = playerTable_add(&object->players, &player);
    
    // Remove the data from the player
    player_free(&player);
    
    return err;    
}

// Remove a player
tError competition_removePlayer(tCompetition* object, const char* username) {
    // PR1 EX3
    //return ERR_NOT_IMPLEMENTED;
    
    tPlayer* player;
    
    // Get the player with the username
    player = playerTable_find(&object->players, username);
    
    if(player == NULL) {
        return ERR_NOT_FOUND;
    }
    
    return playerTable_remove(&object->players, player);
}

// Find a player
tPlayer* competition_findPlayer(tCompetition* object, const char* username) {
    // PR1 EX3
    //return NULL;
    
    return playerTable_find(&object->players, username);
}

// Register a new team
tError competition_registerTeam(tCompetition* object, const char* team_name, const char* username) {
    // PR1 EX3
    // return ERR_NOT_IMPLEMENTED;
    tTeam team;
    tPlayer *player;
    tError err;
    
    // Check if the team already exists
    if(teamTable_find(&object->teams, team_name) != NULL) {
        return ERR_DUPLICATED_TEAMNAME;
    }
    
    // Check if the player exists
    player = playerTable_find(&object->players, username);
    if(player == NULL) {
        return ERR_INVALID_PLAYER;
    }
        
    // Initialize a team with the data
    err = team_init(&team, team_name, player);
    if(err != OK) {
        return err;
    }
    
    // Add the team to the table
    err = teamTable_add(&object->teams, &team);
    
    // Remove the data from the team
    team_free(&team);
    
    return err;    
}

// Remove a player
tError competition_removeTeam(tCompetition* object, const char* team_name) {
    // PR1 EX3
    // return ERR_NOT_IMPLEMENTED;
    
    tTeam* team;
    
    // Get the player with the username
    team = teamTable_find(&object->teams, team_name);
    
    if(team == NULL) {
        return ERR_NOT_FOUND;
    }
    
    return teamTable_remove(&object->teams, team);
}

// Find a team
tTeam* competition_findTeam(tCompetition* object, const char* team_name) {
    // PR1 EX3
    // return NULL;
    
    return teamTable_find(&object->teams, team_name);
}