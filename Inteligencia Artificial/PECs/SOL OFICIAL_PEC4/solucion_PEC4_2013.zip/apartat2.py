# -*- coding: utf-8 -*-
from random import random, randint, sample


# Crea un nou individu creuant altres dos (les posicions dels quals
# s'indiquen al segon par�metre)
def creua(poblacio, posicions):
    L = len(poblacio[0])

	# Pren els gens del primer progenitor i despr�s pren a l'atzar
	# un segment d'entre 1 i L gens del segon progenitor
    fill   = poblacio[posicions[0]][:]
    inici  = randint(0,L-1)
    final  = randint(inici+1,L)
    fill[inici:final] = poblacio[posicions[1]][inici:final]

    return fill

# Aplica mutacions a un individu segons una taxa donada.
# Simplement canvia alguns municipis de grup
def muta(individu, taxaMutacio):
    mutat = []
    for i in range(len(individu)):
        if random() > taxaMutacio:
            mutat.append(individu[i])
        else:
            mutat.append(randint(0,NOMBRE_GRUPS-1))

    return mutat

# Fa evolucionar el sistema durant un nombre de generacions
def evoluciona(poblacio, generacions, municipis, estimacioHabitants, estimacioDistancies):

    # Ordena la poblaci� inicial per la funci� objectiu (descendentment)
    poblacio.sort(key=lambda 
				  x:objectiu(x, municipis, estimacioHabitants, estimacioDistancies),
				  reverse=True)    

    # Alguns valors �tils
    N           = len(poblacio)
    taxaMutacio = 0.01
    
    # Genera una llista del tipus [0,1,1,2,2,2,3,3,3,3,...] per 
    # representar les probabilitats de reproduir-se de cada
    # individu (el primer 1 possibilitat, el segon 2, etc.)
    reproduccio = [x for x in range(N) for y in range(x+1)]

    for i in range(generacions):
		# Es generen N-1 nous individus creuant els existents (sense
		# que es repeteixin els pares)
        pares = sample(reproduccio,2)
        while pares[0]==pares[1]:
            pares = sample(reproduccio,2)
        fills = [creua(poblacio,pares) for x in range(N-1)]

        # S'apliquen mutacions amb una certa probabilitat
        fills = [muta(x, taxaMutacio) for x in fills]

		# S'afegeix el millor individu de la poblaci� anterior
		# (elitisme)
        fills.append(poblacio[-1])
        poblacio = fills

        # S'ordenen els individus per funci� objectiu (descendentment)
        poblacio.sort(key=lambda 
                      x:objectiu(x, municipis, estimacioHabitants, estimacioDistancies), 
                      reverse=True)
            

    # Torna el millor individu trobat
    return poblacio[-1]


########################################################################
#
# Apartat 2
# 

from apartat1 import llegeixMunicipis, objectiu, inventaSolucio


# Alguns par�metres del problema
NOMBRE_GRUPS  = 10
POBLACIO      = 100
ESTIMACIO_HABITANTS = 4891.17
ESTIMACIO_DISTANCIA = 87.77

from random import seed
#seed(0)

# Llegeix el fitxer de municipis
municipis = llegeixMunicipis("municipis.data")

# Genera la poblaci� inicial de solucions
solucions = [inventaSolucio(NOMBRE_GRUPS, len(municipis)) 
					for x in range(POBLACIO)]

# Crida l'algorisme gen�tic per diferent nombre d'iteracions
for iters in [50, 100, 200, 300, 500]:
	
	millor = evoluciona(solucions, iters, municipis, ESTIMACIO_HABITANTS, ESTIMACIO_DISTANCIA)
	print "Pobl=", POBLACIO, " iters=", iters, " objectiu = ", objectiu(millor, municipis, ESTIMACIO_HABITANTS, ESTIMACIO_DISTANCIA)
