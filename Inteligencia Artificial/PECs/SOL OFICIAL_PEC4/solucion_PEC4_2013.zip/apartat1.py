#! /usr/bin/env python
# -*- coding: utf-8 -*-

from random import choice
from math   import sqrt

# Llegeix el fitxer de municipis i torna un diccionari
# {municipi : (habitants, latitud, longitud)}
def llegeixMunicipis(nomFitxer):
    fitxer = file(nomFitxer)
    
    linies = [(l.strip()).split("\t") for l in fitxer.readlines()]
    diccio = {int(l[0]) : (int(l[1]), float(l[2]), float(l[3]))  for l in linies}
    return diccio

# Genera una solució aleatòria donat un nombre de grups i d'elements
def inventaSolucio(nombreGrups, nombreElements):
	return [choice(range(nombreGrups)) for x in range(nombreElements)]

# Donat un vector amb un agrupament de municipis, calcula la desviació
# típica del nombre d'habitants per grup
def diferenciaHabitants(agrupament, municipis):
	habGrup = {x : 0 for x in agrupament}
	
	# El primer element de municipis és el nombre d'habitants
	for m in municipis:
		habGrup[agrupament[m]] += municipis[m][0]
	
	# Calculem la desviació entre grups
	mitjana = sum(habGrup.values()) / float(len(habGrup))
	valors  = [(hg - mitjana)**2 for hg in habGrup.values()]
	sd      = sqrt(sum(valors) / float(len(habGrup) - 1))
	return sd
		
# Donat un vector amb un agrupament de municipis, calcula la distància
# màxima entre dos municipis d'una mateixa zona i torna la mitjana
# de tots els grups
def distanciaMaxima(agrupament, municipis):
	maxDistGrup = {x : 0 for x in agrupament}
	
	# Trobar les distàncies entre cada dos municipis de cada zona
	for grup in maxDistGrup:
		municipisGrup = [x for x in range(len(agrupament)) if agrupament[x] == grup]
		
		# Les entrades 1 i 2 són la latitud i longitud
		# Es podria optimitzar evitant calcular cada distància dos cops
		distancies = [sqrt((municipis[m1][1] - municipis[m2][1])**2 + 
							(municipis[m1][2] - municipis[m2][2])**2)
							for m1 in municipisGrup
							for m2 in municipisGrup]

		maxDistGrup[grup] = max(distancies)
		
	# Calcula la mitjana i la torna
	return(sum(maxDistGrup.values())/len(maxDistGrup))


# La funció objectiu, que donat un agrupament, el diccionari de municipis
# i les estimacions mitjanes pels criteris de qualitat, torna el valor
# associat a aquesta solució
def objectiu(agrupament, municipis, estimacioHabitants, estimacioDistancies):
	
	hab = diferenciaHabitants(agrupament, municipis) / estimacioHabitants
	dis = distanciaMaxima    (agrupament, municipis) / estimacioDistancies
	
	return (hab+dis)

########################################################################
#
# Apartat 1
# 

# Evita que s'executi aquest codi quan cridem les funcions des d'altres
# fitxers
if __name__ == "__main__":

	# Alguns paràmetres del problema
	NOMBRE_GRUPS  = 10
	NOMBRE_PROVES = 1000

	# Llegir el fitxer de municipis
	municipis = llegeixMunicipis("municipis.data")

	# Genera unes quantes solucions inventades per veure els valors típics
	# de cada criteri de qualitat i poder fer-los servir per ponderar-les
	solucionsProva = [inventaSolucio(NOMBRE_GRUPS, len(municipis)) 
						for x in range(NOMBRE_PROVES)]

	estimacioHabitants = sum([diferenciaHabitants(x,municipis) 
								for x in solucionsProva]) / NOMBRE_PROVES
	estimacioDistancies = sum([distanciaMaxima(x,municipis)
								for x in solucionsProva]) / NOMBRE_PROVES

	print "Estimació de diferenciaHabitants()=", estimacioHabitants
	print "Estimació de distanciaMaxima()="    , estimacioDistancies							

					
