# -*- coding: utf-8 -*-
import random, sys, math


# Genera un ve� de l'estat actual: simplement mou un municipi a un
# altre grup a l'atzar
def generaVei(estat):
    nou = estat[:]
    nou[random.randint(0,len(estat)-1)] = random.randint(0,NOMBRE_GRUPS-1)
    return nou

# Tenint en compte l'energia de cada estat, la iteraci� actual
# i el factor de toler�ncia, decideix si un nou estat s'accepta 
# o no
def accepta(energia, novaEnergia, iteracions, factor):
    if novaEnergia < energia:
        return True
    else:
        valor = math.exp((energia-novaEnergia)/
                         (iteracions*factor))
        return random.random() < valor

# Aplica l'algorisme de recocci� simulada a un conjunt de servidors
# i una distribuci� de clients. La toler�ncia indica l'empitjorament
# acceptable a l'iniciar l'algorisme (aproximat).
def recoccioSimulada(agrupament, municipis, tolerancia, iteracions, estimacioHabitants, estimacioDistancies):

	# La toler�ncia permet ajustar la temperatura per controlar si
	# s'accepta o no un nou estat "pitjor" (amb temps de resposta m�s
	# gran)
    factor = tolerancia / float(iteracions)

    # Es calcula el temps mitj� d'espera de l'estat inicial
    estat    = agrupament[:]
    qualitat = objectiu(estat, municipis, estimacioHabitants, estimacioDistancies)

	# S'emmagatzema el millor estat obtingut; ser� aquell que es tornar�
    millor         = estat[:]
    millorQualitat = qualitat
    for i in range(iteracions):
        nou          = generaVei(estat)
        novaQualitat = objectiu(estat, municipis, estimacioHabitants, estimacioDistancies)

        if accepta(qualitat, novaQualitat, i+1, factor):
            estat = nou
            qualitat = novaQualitat

            if novaQualitat < millorQualitat:
                millor         = estat[:]
                millorQualitat = qualitat

    return millor



########################################################################
#
# Apartat 3
# 

from apartat1 import llegeixMunicipis, objectiu, inventaSolucio


# Alguns par�metres del problema
NOMBRE_GRUPS        = 10
ESTIMACIO_HABITANTS = 4891.17
ESTIMACIO_DISTANCIA = 87.77
tolerancia          = 0.5
from random import seed
#seed(0)

# Llegeix el fitxer de municipis
municipis = llegeixMunicipis("municipis.data")

# Genera la soluci� inicial
solucio = inventaSolucio(NOMBRE_GRUPS, len(municipis)) 

for iters in [100, 200, 500, 1000, 1500, 2000, 2500, 3000, 3500, 4000, 4500, 5000]:
	seed(0)
	
	# Es crida a recocci� simulada per que obtingui un bon agrupament
	agrupament = recoccioSimulada(solucio, municipis, tolerancia, iters, ESTIMACIO_HABITANTS, ESTIMACIO_DISTANCIA)

	print("Iteracions=", iters, " objectiu=", objectiu(agrupament, municipis, ESTIMACIO_HABITANTS, ESTIMACIO_DISTANCIA))
