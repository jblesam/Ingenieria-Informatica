<?php
header("Content-Type: text/html;charset=utf-8");

if (isset($_POST["opcion"]))
{
	$opcio = $_POST["opcion"];
	switch ($opcio)
	{
		case "nuevapeli":
			include_once("nuevapeli.html");
			break;
		
		case "proyectar":
		
			include_once("proyectar.html");
			break;
			
		case "cartelera":
			include_once("cartelera.html");
			break;
	
		default:
			echo "<br>ERROR: Opción no disponible<br>";
	}
}
?>