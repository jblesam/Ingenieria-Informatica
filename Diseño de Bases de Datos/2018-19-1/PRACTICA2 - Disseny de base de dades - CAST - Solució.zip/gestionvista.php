<?php

header("Content-Type: text/html;charset=utf-8");
include_once("tcontrol.php");

function mostrarError ($missatge)
{
	echo "<table bgcolor=grey align=center border = 1 cellpadding = 10>";
	echo "<tr><td><br><h2> $missatge </h2><br><br></td></tr>";
	echo "</table>";		
};

function mostrarMissatge ($missatge)
{
	echo "<table bgcolor=#ffffb7 align=center border = 1 cellpadding = 10>";
	echo "<tr><td><br><h2> $missatge </h2><br><br></td></tr>";
	echo "</table>";		
};

if (isset($_POST["opcion"]))
{
	$opcio = $_POST["opcion"];
	switch ($opcio)
	{
		case "Nueva película":
		{
			if (isset($_POST["nombre"]) && isset($_POST["duracion"]))
			{
				$nom = $_POST["nombre"];
				$durada = $_POST["duracion"];
				$c = new TControl();
				if ($c->novapeli($nom, $durada))
				{
					mostrarMissatge("Película dada de alta con éxito");
					echo ("<a href='index.html'> Volver </a>");
				}
				else
				{
					mostrarError("Error al dar de alta la película");
					echo ("<a href='index.html'> Volver </a>");
				}
			}
			else{
				mostrarError("Faltan datos");
			}
			break;
		}

		case "Proyectar":
		{	
			if (isset($_POST["peli"]) && isset($_POST["cine"]) && isset($_POST["recaudacion"]))
			{
				$peli = $_POST["peli"];
				$cinema = $_POST["cine"];
				$recaptacio = $_POST["recaudacion"];
				$c = new TControl();
				if ($c->projectar($peli, $cinema, $recaptacio))
				{
					mostrarMissatge("Projección realitzada con éxito");
					echo ("<a href='index.html'> Volver </a>");
				}
				else
				{
					mostrarError("Error al realizar la proyección");
					echo ("<a href='index.html'> Volver </a>");
				}
			}
			else{
				mostrarError("Faltan datos");
			}
			break;
		}

		case "Cartelera":
		{
			if (isset($_POST["ciudad"]))
			{
				$ciutat = $_POST["ciudad"];
				$c = new TControl();
				$res = $c->cartelleraciutat($ciutat);
				if ($res)
				{
					echo ('<html>

					<head>
						<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
						<title> PRA2 Cartellera </title>
					</head>
					
					<body>
						<center>
							<h1>CARTELERA DE LA CIUDAD DE <br>'.$ciutat.' <br></h1>
							<br> <br>');
					echo ($res);
					echo ('<br><a href="index.html"> Volver </a></center></body></html>');
				}
				else
				{
					mostrarError("Error al generar la cartelera de la ciudad");
					echo ("<a href='index.html'> Volver </a>");
				}
			}
			else{
				mostrarError("no ciudad");
			}
			break;	
		}
		default:
		{
			mostrarError("Error: opción incorrecta");
			echo ("<a href='index.html'> Volver </a>");
		}
	}
}
else
{
	mostrarError("ERROR: Es necesario indicar todos los datos");
	echo ("<a href='index.html'> Vover </a>");
}


?>





