<?php
//Classe de MODEL encarregada de la gestió de la taula CINEMA de la base de dades
include_once ("TAccesbd.php");
class Tcinema
{
    private $nom;
    private $ciutat;
    private $abd;
    function __construct($v_nom, $v_ciutat, $servidor, $usuari, $paraula_pas, $nom_bd)
    {
        $this->nom = $v_nom;
        $this->ciutat = $v_ciutat;
        $var_abd = new TAccesbd($servidor,$usuari,$paraula_pas,$nom_bd);
        $this->abd = $var_abd;
        $this->abd->connectar_BD();
    }

    function __destruct()
    {
        if (isset($this->abd))
        {
        unset($this->abd);
        }
    }

    public function llistatcinemes()
    {
        $res = false;
        if ($this->abd->consulta_SQL("select * from CINE"))
        {   
            $fila = $this->abd->consulta_fila();
            $res = "<select  name='cine'> ";
            while ($fila != null)
            {
                $nom = $this->abd->consulta_dada('nombre');
                $ciutat = $this->abd->consulta_dada('ciudad');
                $res = $res . "<option value='" . $nom . "'>";
                $res = $res . $nom . " - " . $ciutat;
                $fila = $this->abd->consulta_fila();
            }
            $res = $res . "</select>";
            $this->abd->tancar_consulta();
        }
        return $res;
    }

    public function llistatciutats()
    {
        $res = false;
        if ($this->abd->consulta_SQL("select distinct ciudad from CINE"))
        {   
            $fila = $this->abd->consulta_fila();
            $res = "<select  name='ciudad'> ";
            while ($fila != null)
            {
                $ciutat = $this->abd->consulta_dada('ciudad');
                $res = $res . "<option value='" . $ciutat . "'>";
                $res = $res . $ciutat;
                $fila = $this->abd->consulta_fila();
            }
            $res = $res . "</select>";
            $this->abd->tancar_consulta();
        }
        return $res;
    }

    public function cartellera()
    {
        $res = false;
        $SQL = "select pr.nombrePeli, pr.nombreCine, p.duracion, p.recaudacionTotal, pr.recaudacion
        from (PROYECCION pr inner join PELICULA p on pr.nombrePeli = p.nombre)inner join CINE c on pr.nombreCine = c.nombre
        where c.ciudad = '" . $this->ciutat ."' order by pr.nombrePeli";
        if ($this->abd->consulta_SQL($SQL))
        {   
            $fila = $this->abd->consulta_fila();
            $res = "<table border=1><tr bgcolor='lightblue'><th>Película</th><th>Cine</th><th>Duración</th><th>Recaudación</th><th>Rec.Total</th></tr> ";
            while ($fila != null)
            {
                $peli = $this->abd->consulta_dada('nombrePeli');
                $cine = $this->abd->consulta_dada('nombreCine');
                $durada = $this->abd->consulta_dada('duracion');
                $rectotal = $this->abd->consulta_dada('recaudacion');
                $rec = $this->abd->consulta_dada('recaudacionTotal');

                $res = $res . "<tr>";
                $res = $res . "<td>$peli</td>";
                $res = $res . "<td>$cine</td>";
                $res = $res . "<td align='right'>$durada</td>";
                $res = $res . "<td align='right'>$rectotal</td>";
                $res = $res . "<td align='right'>$rec</td></tr>";
                $fila = $this->abd->consulta_fila();
            }
            $res = $res . "</table>";
            $this->abd->tancar_consulta();
        }
        return $res;
    }
 


}