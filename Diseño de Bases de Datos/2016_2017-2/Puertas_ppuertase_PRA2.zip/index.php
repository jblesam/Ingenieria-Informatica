<!DOCTYPE html>
<html>
<head>
<title>Login</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="robots" content="noindex">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Expires" content="0" />
<link rel="stylesheet" href="http://fontawesome.io/assets/font-awesome/css/font-awesome.css" type="text/css" />
<link rel="stylesheet" href="css/index.css" type="text/css" />
<script language="JavaScript" type="text/javascript" src="js/jquery-1.12.4.js"></script>
<script src="js/md5.js"></script>
<script src="js/control.js"></script>
<script>
  function valida() {
    document.forms[0].long_pass_a.value = document.forms[0].pass_a.value.length;
	var hash = CryptoJS.MD5(document.forms[0].pass.value);
	document.forms[0].pass.value = hash;
	if (document.forms[0].pass_a.value != "") {
	 hash = CryptoJS.MD5(document.forms[0].pass_a.value);
	 document.forms[0].pass_a.value = hash;
	}
    if (document.forms[0].pass_b.value != "") {
	 hash = CryptoJS.MD5(document.forms[0].pass_b.value);
	 document.forms[0].pass_b.value = hash;
    }
    document.forms[0].submit();
  }

  function canvia_password() {
    $(".change").toggle();
    if ($(".change").css('display') == 'none') $("#boto").val("Accedir"); else $("#boto").val("Canviar");
     posiciona();
  }  
</script>
</head>
<body>
  <?php
  //print_r($_SERVER);
  // Generem el header de la pàgina
  header ( 'Content-Type: text/html; charset="UTF-8"' );
  
  if (! session_id ())
   @ session_start ();
  if (isset($_GET['close'])) {
   session_unset(); // Netegem la sessió
   header ( 'Location: '. $_SERVER['CONTEXT_PREFIX'].'/index.php' );
  }
  if (isset ( $_SESSION ['error'] )) {
   echo "<center class='warning'>";
   echo $_SESSION ['error'];
   echo "</center>";
   unset ( $_SESSION ['error'] );
  }
  if (isset ( $_SESSION ['ok'] )) {
   echo "<center class='ok'>";
   echo $_SESSION ['ok'];
   echo "</center>";
   unset ( $_SESSION ['ok'] );
  }
  ?> 
  <img class="fons" src="img/fons.jpg" />
  <img class="logo" src="img/uoc_masterbrand_3linies_blanc.png" />
  <div class="credits">
    <h3>Disseny de Bases de dades</h3>
    Pedro Puertas<br> 2016-2017/2
  </div>
  <form method="post" action="control/loginAction.php" onsubmit="javascript:valida();">
    <input type="hidden" name="long_pass_a" value="" />
    <div id="tabla_password">
      <a id="icono" href="info.html"><i class="icono fa fa-info-circle fa-2x"></i></a>
      <a id="canvi_password" href="javascript:canvia_password();"><i class="fa fa-address-card-o fa-2x"></i></a>
      <table style="width: 80%">
        <thead>
          <tr>
            <th colspan="2"><h1>Benvingut</h1></th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td align="center">
            <span class="fa fa-user input_icon"></span>
            <input type="text"  placeholder="Usuari" name="userid" value="" style="width: 250px" autofocus="autofocus" />
            </td>
          </tr>
          <tr>
            <td align="center">
            <span class="fa fa-key input_icon"></span>
            <input type="password" autocomplete="off" placeholder="Paraula de pas" name="pass" id="pass" value="" style="width: 250px" />
            </td>
          </tr>
          <tr class="change">
            <td align="center">
            <span class="fa fa-key input_icon"></span>
            <input type="password" autocomplete="off" placeholder="Nova paraula de pass" name="pass_a" id="pass_a" value="" style="width: 250px" />
            </td>
          </tr>
          <tr class="change">
            <td align="center">
            <span class="fa fa-key input_icon"></span>
            <input type="password" autocomplete="off" placeholder="Repeteix la paraula de pas" name="pass_b" id="pass_b" value="" style="width: 250px" />
            </td>
          </tr>
          <tr>
            <td colspan="2" align="right"><input class="gobutton" id="boto" type="submit" onsubmit="javascript:valida();" value="Accedir" /></td>
          </tr>
        </tbody>
      </table>
    </div>
  </form>
</body>
</html>