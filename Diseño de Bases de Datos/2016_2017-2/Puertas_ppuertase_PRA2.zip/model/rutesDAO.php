<?php
/**
 * Clase DAO que permet l'acces a les taules de RUTES
 *
 * @author Pedro Puertas
 *
 */
class rutesDAO {
 /**
  * Funció que permet conectar a la base de dades MySQL
  *
  * @return conexió
  */
 function connect() {
  // Variables de conexió
  $mysql_server = "localhost";
  $mysql_user = "root";
  $mysql_pass = "";
  $mysql_db = "rutes";

  // Si estem al servidor de la UOC canviem les credencials
  if ($_SERVER ['HTTP_HOST'] == 'eimtdbd.uoc.edu') {
   $mysql_server = "localhost";
   $mysql_user = "ppuertase";
   $mysql_pass = "K0dLrh5W";
   $mysql_db = "ppuertase";
  }
  // Se conecta al SGBD
  if (! ($con = mysqli_connect ( $mysql_server, $mysql_user, $mysql_pass )))
   die ( "Error: No se pudo conectar" );
   
  // Selecciona la base de datos
  if (! mysqli_select_db ( $con, $mysql_db ))
   die ( "Error: No existe la base de datos" );
   
  // Important indicar que les dades estan en UTF-8
  mysqli_set_charset ( $con, "utf8" );

  return $con;
 }

 /**
  * Funció generica per fer consultes
  *
  * @param String $sql
  * @param String $tipus
  * @param Array $params
  * @return multitype:
  */
 function select($sql, $tipus, $params) {
  $result = null;
  $stmt = null;
  $con = self::connect (); // Connectem a la base de dades
  if (strlen($tipus) > 0) {
   $stmt = $con->prepare ( $sql ); // preparem la consulta amb variables bind
   if ($stmt) {
    $bind = [ ]; // Array per les variables
    $bind [] = $tipus; // Afegim els tipus
    foreach ( $params as $clau => $valor ) {
     $bind [] = & $params [$clau]; // Afegim la referencia dels valors dels paràmetres (& per referencia)
    }
    call_user_func_array ( array ($stmt,'bind_param'), $bind ); // Associem al statement les variables bind
    $stmt->execute (); // Executem la consulta
    $resultSet = $stmt->get_result (); // Obtenim els resultat
    
   }
  } else {
   $resultSet = $con->query($sql);
  }
  $numRows = $resultSet->num_rows; // Nombre de files
  if ($numRows > 0) { // Si tenim files
   $result = [ ];
   while ( $row = $resultSet->fetch_assoc () ) {
    $data = [ ]; // Recorre cada fila i associem els valors, fem una conversió desde UTF-8
    foreach ( $row as $key => $value ) {
     // $data[utf8_decode($key)] = $value;
     $data [$key] = $value;
    }
    // Afegim el registre al array del resultat
    array_push ( $result, $data );
   }
  } else
   $result = null;
 
 // Tanquem la conneció
  // Tanquem el statement
  if ($stmt) $stmt->close ();
  if ($con) $con->close ();
 return $result;
}

/**
 * Funció que comprova si l'usuari existeix i emmagatzema un registre de la data del accés
 *
 * @param
 *         array
 */
function login($user, $pass) {
 $result = self::select ( "select checkUser(?,?) as res from dual", "ss", [$user,  $pass] );
 return $result [0] ['res'];
}

/**
 * Funció que comprova si l'usuari existeix i emmagatzema un registre de la data del accés
 *
 * @param
 *         array
 */
function canvi_password($user, $pass, $new_pass) {
 $result = self::select ( "select canvi_password(?,?,?) as res from dual", "sss", [$user, $pass, $new_pass ] );
 return $result [0] ['res'];
}


/**
 * Funció que retorna l'usuari a partir de l'email
 * @param unknown_type $email
 */
function getUsuari($email) {
 $fila = self::select ( 
   "select c.*, ".
   "(select max(DATE_FORMAT(data_accés,'%d/%m/%Y %H:%i:%S')) from accessos a where a.conductor_dni = c.dni and data_accés < now()-10) as data_accés ".
   "from conductor c where c.email = ? ".
   "order by data_accés desc limit 1", 
   "s", [$email] );
    
   return $fila [0];
}

/**
 * Funció que retorna les rutes no acabades d'un conductor
 *
 * @param unknown_type $email
 * @return unknown
 */
function getRutesNoAcabades($dni) {
 $sql = "select t.id, t.camió_matrícula as matrícula, DATE_FORMAT(t.data_inici,'%d/%m/%Y') as data_inici, r.nom  from " . 
        "conductor c, transport t, ruta r where dni = ? " . 
        "and t.camió_matrícula = c.camió_matrícula " . 
        "and t.data_finalització is null " . 
        "and r.id = t.ruta_id ";
 $result = self::select ( $sql, "s", [$dni] );
 // print_r($result);
 return $result;
}

/**
 * Funció que retorna la ruta per el seu id
 *
 * @param unknown_type $ruta
 * @return unknown
 */
function getRuta($ruta) {
 $sql = "select t.id, t.camió_matrícula as matrícula, DATE_FORMAT(t.data_inici,'%d/%m/%Y') as data_inici, DATE_FORMAT(t.data_finalització,'%d/%m/%Y') as data_finalització, t.ruta_id, r.nom as desc_ruta, t.incidències, t.pes, t.volum " . 
        "from transport t, ruta r where t.id = ?  and r.id = t.ruta_id";
 $fila = self::select ( $sql, "d", [ $ruta ] );
 return $fila [0];
}


function arrayToSelect($array, $id, $class) {
 echo "<select class=".addslashes($class)." id=".addslashes($id)." name=".addslashes($id).">";
 foreach ($array as $row) {
    $keys = array_keys($row);
    echo "<option value=";
    echo addslashes($row[$keys[0]]);
    echo ">";
    echo $row[$keys[1]];
    echo "</option>";
 }
 echo "</select>";
}

function getRutes() {
 $files = self::select ("select id, nom from ruta", "", []);
 return $files;
}

/**
 * Funció que permet donar d'alta un nou contacte
 */
function alta_transport($data) {
 $con = self::connect ();

 $sql = "INSERT INTO transport(camió_matrícula,data_inici,data_finalització,ruta_id,incidències,pes,volum) VALUES (?,str_to_date(?,'%d/%m/%Y'),str_to_date(?,'%d/%m/%Y'),?,?,?,?)";
 $stmt = $con->prepare ( $sql );
 if ($stmt) {
  // Pasem a la consulta insert els paràmetres. Dades del transport
  if ($data['data_inici'] == '') $data['data_inici'] = null;
  if ($data['data_finalització'] == '') $data['data_finalització'] = null;

  $stmt->bind_param ( "sssssss", $data ['matrícula'], $data ['data_inici'], $data ['data_finalització'], $data ['ruta_id'], $data ['incidències'], $data ['pes'], $data ['volum'] );
  $result = $stmt->execute ();
  // Tanquem els recursos util·litzats
  $stmt->close ();
  $con->close ();
  return $result;
 } else {
  if ($con)
   $con->close ();
  return false;
 }
}

/**
 * Funció que permet modificar un contacte
 */
function modifica_transport($data) {
  $con = self::connect ();
 
  $sql = "UPDATE transport SET data_inici = str_to_date(?,'%d/%m/%Y'), data_finalització = str_to_date(?,'%d/%m/%Y') , incidències = ?, pes = ? , volum = ? WHERE id = ?";

 $stmt = $con->prepare ( $sql );
 if ($stmt) {
  if ($data['data_inici'] == '') $data['data_inici'] = null;
  if ($data['data_finalització'] == '') $data['data_finalització'] = null;
  $stmt->bind_param ( "ssssss",  $data ['data_inici'], $data ['data_finalització'], $data ['incidències'], $data ['pes'], $data ['volum'], $data['id'] );
  $result = $stmt->execute ();
  //print_r ( $result );
  $stmt->close ();
  $con->close ();
  return $result;
 } else {
  if ($con)
   $con->close ();
  return false;
 }
}

function validaData($date, $format = 'd/m/Y') {
 if (empty($date)) return true;
 $d = DateTime::createFromFormat($format, $date);
 return $d && $d->format($format) == $date;
}

function comparaDates($date_a, $date_b, $format = 'd/m/Y') {
 if (empty($date_a)) return 0;
 if (empty($date_b)) return 0;
 $da = DateTime::createFromFormat($format, $date_a);
 $db = DateTime::createFromFormat($format, $date_b);
 if (!$da || !$db) return 0;
 if ($da < $db) $result = -1;
 if ($da > $db) $result = 1;
 if ($da == $db) $result = 0;
 return $result;
}

}

?>
