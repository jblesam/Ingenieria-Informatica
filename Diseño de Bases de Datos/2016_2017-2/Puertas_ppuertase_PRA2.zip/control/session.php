<?php

if (! session_id ()) @ session_start ();
function check_session() {
 if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 600)) {
  session_unset();     // unset del la variable $_SESSION 
  session_destroy();   // destruim la sessió
  @ session_start ();  // Crearem una nova sessió i indiquem l'error
  $_SESSION ['error'] = "La seva sessió ha expirat";
  header ( 'Location: '. $_SERVER['CONTEXT_PREFIX'].'/index.php' );
  exit ();
 }
 
 $_SESSION['LAST_ACTIVITY'] = time(); // update last activity time stamp
 
 if (! isset ( $_SESSION ['usuari'] )) {
  // Si no és 1 indiquem l'error i retornem a la p�gina
  $_SESSION ['error'] = "No te privilegis d'access a aquesta pàgina";
  header ( 'Location: '.$_SERVER['CONTEXT_PREFIX']. '/index.php' );
  exit ();
 }
}

?>