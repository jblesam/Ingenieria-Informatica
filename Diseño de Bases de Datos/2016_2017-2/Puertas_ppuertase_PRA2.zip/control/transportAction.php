<?php
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);


// Carreguem el controlador de sessi� (session_start, etc)
include_once ( '../control/session.php');
// Classe d'accés a la base de dades
include_once ('../model/rutesDAO.php');
// Iniciem l'objecte DAO
$rutesDAO = new rutesDAO ();

$error = "";
if (empty($_POST['volum'])) $error .= "El camp VOLUM és obligatori </br>";
if (empty($_POST['pes'])) $error .= "El camp PES és obligatori </br>";
if (empty($_POST['data_inici'])) $error .= "El camp DATA INICI és obligatori </br>";
if ($rutesDAO->comparaDates($_POST['data_inici'], $_POST['data_finalització']) > 0) $error .= "La DATA FINALITZACIÓ no por ser menor que la DATA INICI </br>";
if (!$rutesDAO->validaData($_POST['data_inici'])) $error .= "El format de DATA INICI és erroni </br>";
if (!$rutesDAO->validaData($_POST['data_finalització'])) $error .= "El format de DATA FINALITZACIÓ és erroni </br>";

if ($error == "" && isset($_POST['id']) && !empty($_POST['id'])) {
 if ($rutesDAO->modifica_transport($_POST)) {
  $_SESSION ['POST'] = $_POST;
  $_SESSION ['ok'] = "Dades actualitzades correctament";
 } else {
  $_SESSION ['error'] = ($error == "") ? "No s'han pogut emmagatzemar els canvis" : $error;
  $_SESSION ['POST'] = $_POST;
 }
} else {
 if ($error == "" && $rutesDAO->alta_transport($_POST)) {
  $_SESSION ['POST'] = $_POST;
  $_SESSION ['ok'] = "Transport donat d'alta correctament";
 } else {
  $_SESSION ['error'] = ($error == "") ? "No s'han pogut donar d'ALTA" : $error;
  $_SESSION ['POST'] = $_POST;
 }
}
header ( 'Location: '. $_SERVER['CONTEXT_PREFIX'].'/transport.php' );
exit ();
?>