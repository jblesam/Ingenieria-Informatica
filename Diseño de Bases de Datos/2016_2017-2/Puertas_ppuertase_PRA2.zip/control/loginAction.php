<?php
// Carreguem el controlador de sessi� (session_start, etc)
include_once ('../control/session.php');
// Classe d'accés a la base de dades
include_once ('../model/rutesDAO.php');
// Iniciem l'objecte DAO
$rutesDAO = new rutesDAO ();
$error = false;

if (isset($_POST['pass_a']) && isset($_POST['pass_b']) && (!empty($_POST['pass_a']) || !empty($_POST['pass_b']))) {
 if ($_POST['pass_a'] != $_POST['pass_b']) {
  $error = true;
  $_SESSION ['error'] = 'Les paraules de pas no coincideixen';
 } else {
  if (empty($_POST['pass_a']) || empty($_POST['pass_b']) ) {
   $error = true;
   $_SESSION ['error'] = 'Les paraules de pas no coincideixen';
  } else {
    if ($_POST['long_pass_a'] < 5) {
     $error = true;
     $_SESSION ['error'] = 'Paraula de pas de mínim de 5 dígits';
    }
  }
 }

 if (!$error && $rutesDAO->canvi_password ( $_POST ['userid'], $_POST ['pass'], $_POST['pass_a'] ) == 1) {
  $_SESSION ['ok'] = 'Paraula de pas canviada correctament';
 } else {
  if (!$error) $_SESSION ['error'] = 'Error canviant la paraula de pas';
 }
 header ( 'Location: ' . $_SERVER['CONTEXT_PREFIX'].'/index.php' );
 exit();
}

// Fem la crida del login
if ($rutesDAO->login ( $_POST ['userid'], $_POST ['pass'] ) == 1) {
 // Lliberem variables de la sessió
 // Si torna 1 indica que el login es correcte i el redirigim a la pàgina de rutes
 $_SESSION ['usuari'] = $rutesDAO->getUsuari ( $_POST ['userid'] );
 
 // print_r($_SESSION['usuari']);
 unset($_SESSION['error']);
 // Redirigim a la pantalla de rutes, el login és correcte
 header ( 'Location: ' . $_SERVER['CONTEXT_PREFIX'].'/rutes.php' );
} else {
 // Si no és 1 indiquem l'error i retornem a la pàgina
 // print_r($_SESSION['usuari']);
 unset ( $_SESSION ['usuari'] );
 $_SESSION ['error'] = 'Paraula de pas o usuari incorrectes';
 // Redirigim a la pantalla de inici, el login és incorrecte
 header ( 'Location: ' . $_SERVER['CONTEXT_PREFIX'].'/index.php' );
}
?>