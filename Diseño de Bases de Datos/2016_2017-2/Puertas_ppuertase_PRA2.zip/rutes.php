<!DOCTYPE html>
<?php
 ini_set('display_errors', 1);
 ini_set('display_startup_errors', 1);
 error_reporting(E_ALL);


include_once ('./control/session.php');
check_session ();
include_once ('./model/rutesDAO.php');

// Iniciem l'objecte DAO
$rutesDAO = new rutesDAO ();
?>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Expires" content="0" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="robots" content="noindex">
<link rel="stylesheet" href="http://fontawesome.io/assets/font-awesome/css/font-awesome.css" type="text/css" />
<link rel="stylesheet" href="css/index.css" type="text/css" />
<script language="JavaScript" type="text/javascript" src="js/jquery-1.12.4.js"></script>
<script src="js/control.js"></script>

<title>Gestió de rutes</title>
<script type="text/javascript">
 function valida(id) {
	if (id != null) document.forms[0].id.value = id;
	document.forms[0].desc_ruta.value = $('#ruta_id > option').get($('#ruta_id').val()-1).innerText;
	document.forms[0].submit();
 }

</script>


</head>
<body>
 <img class="fons" src="img/fons.jpg" />
 <img class="logo" src="img/uoc_masterbrand_3linies_blanc.png" />
 <div class="credits">
  <h3>Disseny de Bases de dades</h3>
  Pedro Puertas<br> 2016-2017/2
 </div>
 <div class="container">
 <div class="conductor">Conductor : 
  <?php 
  echo $_SESSION ['usuari'] ['nom'] . " " . $_SESSION ['usuari'] ['cognoms'];
  if (!empty($_SESSION ['usuari']['data_accés']))  echo  "<span class='mini'>(últim accés  " . $_SESSION ['usuari'] ['data_accés']. ")</span>"; 
  ?>
  <a class="icon" href="javascript:tancar();"><i class="fa fa-sign-out" aria-hidden="true"></i></a>
 </div>
  <?php
  $no_acabades = $rutesDAO->getRutesNoAcabades ( $_SESSION ['usuari'] ['dni'] );
  if (isset ( $no_acabades )) {
   echo "Tens " . sizeof ( $no_acabades );
   echo (sizeof ( $no_acabades ) > 1) ? " rutes no acabades " : " ruta no acabada";
   echo "<br /><br />";
   echo "<table>" . PHP_EOL;
   foreach ( $no_acabades as $fila ) {
    echo "<tr>" . PHP_EOL;
    echo "<td>Transport del " . $fila ['data_inici'];
    echo " en el vehicle " . $fila ['matrícula'] . " de la ruta ";
    echo $fila['nom']."</td>".PHP_EOL;
    echo "<td><a href='javascript:valida(" . $fila ['id'] . ");'>Completar les dades</a></td>" . PHP_EOL;
    echo "</tr>" . PHP_EOL;
   }
   echo "</table>" . PHP_EOL;
   echo "<br></p>" . PHP_EOL;
   echo "<hr><br>";
  }
  ?>
 <form method="post" name="ruta_conductor" action="transport.php" onsubmit="javascript:valida();">
  <p>
   <input type="hidden" name="id" />
   <input type="hidden" name="desc_ruta" />
   Escull una ruta per informar de les dades de transport:&nbsp;&nbsp;
   
   <?php 
   $rutes = $rutesDAO->getRutes();
   $rutesDAO->arrayToSelect($rutes, "ruta_id", "select-style");
   ?>
  </p>
  <br> <input class="gobutton" type="submit" value="Enviar" />
  </form>
 </div>
</body>
</html>
