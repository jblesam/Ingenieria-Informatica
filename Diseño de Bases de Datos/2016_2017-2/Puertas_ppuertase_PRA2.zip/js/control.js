$(function() {

  $('input,textarea').each(function() {
    var $el = $(this);
    var name = $(this).attr('name');
    var id = $(this).attr('id');
    var type = $(this).attr('type');

    if (name == null) {
      name = $el.attr('id');
    } else {
      if (id == null) $(this).attr('id', name);
    }

    var placeholder = null;

    if (type != 'radio' && type != 'checkbox') {
      if (this.localName == 'input') placeholder = $(this).attr('placeholder');
      if (this.localName == 'textarea') placeholder = $(this).attr('placeholder');
      if (this.localName == 'select') placeholder = this[0].text;
      if (placeholder) {
        var label = $("<label for='" + name + "'>" + placeholder + "</label>");
        label.insertAfter(this);
      }

      if ($el.val()) {
        $el.addClass('filled');
      }

      $(this).on('focus', function() {
        var $el = $(this);
        var label = $("label[for='" + $el.attr('id') + "']");
        label.css('left', $el.position().left + 12);
        label.css('top', $el.position().top + 6);
      });

      $(this).on('blur', function() {
        if ($(this).val()) {
          $(this).addClass('filled');
        } else
          $(this).removeClass('filled');
      });

    }

  });

  posiciona();

  window.addEventListener("resize", posiciona);

});

function posiciona() {
  $("input, textarea").each(function() {
    var $el = $(this);
    var label = $("label[for='" + $el.attr('id') + "']");
    label.css('left', $el.position().left + 12);
    label.css('top', $el.position().top + 6);
  });
}

function tancar() {
  document.location = "index.php?close=1";
}