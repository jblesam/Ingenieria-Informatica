﻿--
-- Base de dades: `Rutes`
--

USE `rutes`;

-- --------------------------------------------------------------
-- A - Sentències SQL de la pàgina index.php | loginAction.php
-- --------------------------------------------------------------

-- Comprovació de l'usuari
-- Se li pasa per bind variables email i paraula de pas encriptada en MD5
select checkUser('jmuntada@transport.es','827ccb0eea8a706c4c34a16891f84e7b') as res from dual;  

-- Canvi de paraula de pas
-- Se li pasa per bind variables email, paraula de pas actual i paraula de pas nova (123456)
select canvi_password('jmuntada@transport.es','827ccb0eea8a706c4c34a16891f84e7b','e10adc3949ba59abbe56e057f20f883e') as res from dual;

-- Lectura de les dades del conductor per emmagatzemar-les a la sessió
select c.*,
(select max(DATE_FORMAT(data_accés,'%d/%m/%Y %H:%i:%S')) from accessos a where a.conductor_dni = c.dni and data_accés < now()-10) as data_accés 
from conductor c where c.email = 'jmuntada@transport.es'
order by data_accés desc limit 1;


-- --------------------------------------------------------
-- C - Sentències SQL de la pàgina rutes.php
-- --------------------------------------------------------

-- Consulta que recupera la llista de transports pendents de finalitzar per conductor
select t.id, t.camió_matrícula as matrícula, DATE_FORMAT(t.data_inici,'%d/%m/%Y') as data_inici, r.nom  
  from conductor c, transport t, ruta r where dni = '52111111A' 
   and t.camió_matrícula = c.camió_matrícula and t.data_finalització is null  
   and r.id = t.ruta_id;

-- Consulta que recupera la llista de rutes per mostrar al selector de rutes
select id, nom from ruta;
-- ---------------------------------------------------------------------
-- D - Sentències SQL de la pàgina transport.php | transportAction.php
-- ---------------------------------------------------------------------

-- Consulta les dades d'un transport per el seu id per modificar-lo
select t.id, t.camió_matrícula as matrícula, 
       DATE_FORMAT(t.data_inici,'%d/%m/%Y') as data_inici, 
	   DATE_FORMAT(t.data_finalització,'%d/%m/%Y') as data_finalització, 
	   t.ruta_id, r.nom as desc_ruta,
       t.incidències, t.pes, t.volum 
from transport t, ruta r where t.id = 1 and r.id = t.ruta_id;
       
-- Inserir les dades d'un nou transport, es fan servir bind variables i es formatejen les dates adequadament       
INSERT INTO transport(camió_matrícula,data_inici,data_finalització,ruta_id,incidències,pes,volum) 
VALUES ('1111-BBB',str_to_date('01/09/2017','%d/%m/%Y'),str_to_date(null,'%d/%m/%Y'),1,null,1,2);

-- Modificació d'un transport, s'utilitza el id per identificar el registre a modificar
UPDATE transport SET 
data_inici = str_to_date('01/09/2017','%d/%m/%Y'), 
data_finalització = str_to_date(null,'%d/%m/%Y') , 
incidències = null, 
pes = 1 , 
volum = 2 
WHERE id = 11;
