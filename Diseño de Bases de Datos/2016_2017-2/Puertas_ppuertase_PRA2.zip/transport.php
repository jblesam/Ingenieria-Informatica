<!DOCTYPE html>
<?php
include_once ('./control/session.php');
check_session ();
include_once ('./model/rutesDAO.php');
// Iniciem l'objecte DAO
$rutesDAO = new rutesDAO ();

if (isset($_SESSION['POST'])) {
 $_POST = $_SESSION['POST'];
 unset($_SESSION['POST']);
}
if (!isset($_POST['desc_ruta']) && !isset($_SESSION ['ok']) && !isset($_SESSION ['error'])) {
 header ( 'Location: ' . $_SERVER['CONTEXT_PREFIX']. '/rutes.php' );
 exit ();
}

if (isset($_POST['id']) && !empty($_POST['id'])) {
 //print_r ( $_POST );
 $ruta = $rutesDAO->getRuta ( $_POST ['id'] );
  $ruta['ruta_id'] = $_POST['ruta_id'];
} else {
 $ruta = [];
 $ruta['id'] = null;
 $ruta['desc_ruta'] = $_POST['desc_ruta'];
 $ruta['ruta_id'] = $_POST['ruta_id'];
 $ruta['matrícula'] = $_SESSION ['usuari'] ['camió_matrícula'];
 $ruta['data_inici'] = isset($_POST['data_inici']) ? $_POST['data_inici'] : '';
 $ruta['data_finalització'] = isset($_POST['data_finalització']) ? $_POST['data_finalització'] : '';
 $ruta['incidències'] = isset($_POST['incidències']) ? $_POST['incidències'] : '';
 $ruta['volum'] = isset($_POST['volum']) ? $_POST['volum'] : '';
 $ruta['pes'] = isset($_POST['pes']) ? $_POST['pes'] : '';
}

?>
<html lang="es">
<head>
<title>Gestió de rutes</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Expires" content="0" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="robots" content="noindex">
<link rel="stylesheet" href="http://fontawesome.io/assets/font-awesome/css/font-awesome.css" type="text/css" />
<link rel="stylesheet" href="css/index.css" type="text/css" />
<link rel="stylesheet" href="css/jquery-ui.css" type="text/css" />
<script language="JavaScript" type="text/javascript" src="js/jquery-1.12.4.js"></script>
<script language="JavaScript" type="text/javascript" src="js/jquery-ui.js"></script>
<script src="js/control.js"></script>

<script>
  function emmagatzemar() {
    document.forms[0].submit();
  }

  function tornar() {
    window.location = 'rutes.php';
  }

  $( function() {

    $.datepicker.regional['es'] = {
        closeText: 'Cerrar',
        prevText: '< Ant',
        nextText: 'Seg >',
        currentText: 'Avui',
        monthNames: ['Gener', 'Febrer', 'Març', 'Abril', 'Maig', 'Juny', 'Juliol', 'Agost', 'Setembre', 'Octubre', 'Novembre', 'Decembre'],
        monthNamesShort: ['Gen','Feb','Mar','Abr', 'Mai','Jun','Jul','Ago','Set', 'Oct','Nov','Dec'],
        dayNames: ['Diumenge', 'Dilluns', 'Dimarts', 'Dimecres', 'Dijous', 'Divendres', 'Dissabte'],
        dayNamesShort: ['Dom','Lun','Mar','Mié','Juv','Vie','Sáb'],
        dayNamesMin: ['Dg','Dl','Dm','Dc','Dj','Dv','Ds'],
        weekHeader: 'Sm',
        dateFormat: 'dd/mm/yy',
        firstDay: 1,
        isRTL: false,
        showMonthAfterYear: false,
        yearSuffix: ''
        };
        $.datepicker.setDefaults($.datepicker.regional['es']);

    
    $( "input[name^='data']" ).datepicker();
  } );

</script>

</head>
<body>
  <img class="fons" src="img/fons.jpg" />
  <img class="logo" src="img/uoc_masterbrand_3linies_blanc.png" />
  <div class="credits">
    <h3>Disseny de Bases de dades</h3>
    Pedro Puertas<br> 2016-2017/2
  </div>
  <div class="container">
  <div class="conductor">Conductor : 
    <?php 
    echo $_SESSION ['usuari'] ['nom'] . " " . $_SESSION ['usuari'] ['cognoms'];
    if (!empty($_SESSION ['usuari']['data_accés']))  echo  "<span class='mini'>(últim accés  " . $_SESSION ['usuari'] ['data_accés']. ")</span>"; 
    ?>
    <a class="icon" href="javascript:tancar();"><i class="fa fa-sign-out" aria-hidden="true"></i></a>
  </div>
    <?php 
     if (isset ( $_SESSION ['ok'] )) {
      echo "Ruta <h4>".$ruta['desc_ruta']."</h4> amb el vehicle <h4>".$ruta['matrícula']."</h4>";
     } else {
       if (isset($_POST['id']) && !empty($_POST['id'])) {
         echo "Actualitza les dades de la ruta <h4>".$ruta['desc_ruta']."</h4> amb el vehicle <h4>".$ruta['matrícula']."</h4>";
       } else {
         echo "Informa les dades de la ruta <h4>".$ruta['desc_ruta']."</h4> amb el vehicle <h4>".$ruta['matrícula']."</h4>";
       }
     }  
    ?>
    <form method="post" name="transport" action="<?php echo  $_SERVER['CONTEXT_PREFIX']?>/control/transportAction.php">
      <input type="hidden" name="id" value="<?php echo $ruta['id'];?>" />
      <input type="hidden" name="ruta_id" value="<?php echo $ruta['ruta_id']; ?>" />
      <input type="hidden" name="desc_ruta" value="<?php echo $ruta['desc_ruta']; ?>" />
      <input type="hidden" name="matrícula" placeholder="Matrícula" readonly="readonly" value="<?php echo $ruta['matrícula'];?>" />
      <div class="half">
        <input type="number" name="volum" placeholder="Volum" value="<?php echo isset($ruta['volum']) ? $ruta['volum'] : '';?>" />
        <input type="number" name="pes" placeholder="Pes" value="<?php echo isset($ruta['pes']) ? $ruta['pes'] : '';?>" />
        <input type="text" name="data_inici" placeholder="Data inici" value="<?php echo isset($ruta['data_inici']) ? $ruta['data_inici'] : '';?>" />
        <input type="text" name="data_finalització" placeholder="Data finalització" value="<?php echo isset($ruta['data_finalització']) ? $ruta['data_finalització'] : '';?>" />
        <br /><br /><br /><br /><br /><br /><br />
        <?php if (!isset ( $_SESSION ['ok'] )) echo '<button type="button" tabindex="-1"   onclick="javascript:emmagatzemar();">Emmagatzemar</button>';?>
        <button type="button" tabindex="-1" onclick="javascript:tornar();">Tornar</button>
      </div>
 
      <div class="half">
      <textarea type="text" name="incidències" placeholder="Incidències" size="200" style="width:90%; height: 200px"><?php echo $ruta['incidències'];?></textarea>
      </div>
    </form>
  </div>
 <?php 
  if (isset ( $_SESSION ['error'] )) {
   echo "<center class='warning'>";
   echo $_SESSION ['error'];
   echo "</center>";
   unset ( $_SESSION ['error'] );
  }
  if (isset ( $_SESSION ['ok'] )) {
   echo "<center class='ok'>";
   echo $_SESSION ['ok'];
   echo "</center>";
   unset ( $_SESSION ['ok'] );
  }
  ?>  
</body>

</html>
