﻿--
-- Base de dades: `Rutes`
--
USE `rutes`;

-- ------------------------------------------------------------------
-- Sentències LDD per ampliar l'estructura de taules
-- ------------------------------------------------------------------

-- S'afegeixen comentaris a les columnes
ALTER TABLE camió COMMENT = 'Taula que emmagatzema les dades de cada vehicle',
 CHANGE matrícula matrícula VARCHAR(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'Matrícula del vehicle',
 CHANGE tonatge tonatge INT(11) COMMENT 'Pes màxim que pot transportar',
 CHANGE volum volum INT(11) COMMENT 'Volum màxim que pot transportar',
 CHANGE consum consum INT(11) COMMENT 'Consum del vehicle';

ALTER TABLE ciutat COMMENT = 'Taula que emmagatzema les dades de les ciutats de pas',
 CHANGE id id INT(11) AUTO_INCREMENT NOT NULL COMMENT 'Identificador únic de ciutat',
 CHANGE nom nom VARCHAR(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci COMMENT 'Nom de la ciutat',
 CHANGE acrònim acrònim VARCHAR(3) CHARACTER SET utf8 COLLATE utf8_unicode_ci COMMENT 'Nom abreujat del la ciutat';

 DROP TABLE IF EXISTS accessos;

-- Crear la taula ACCESSOS que permet emmagatzemar les dades dels accessos dels conductors
CREATE TABLE `accessos` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Identificador únic del registre',
  `data_accés` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Emmagatzema l\'hora d\'accés',
  `conductor_dni` varchar(20) NOT NULL COMMENT 'Emmagatzema el ID del conductor',
  PRIMARY KEY (`id`),
  KEY `FK_ACCESOS_CONDUCTOR` (`conductor_dni`),
  CONSTRAINT `FK_ACCESOS_CONDUCTOR` FOREIGN KEY (`conductor_dni`) REFERENCES `conductor` (`dni`)
) ENGINE=InnoDB COMMENT='Taula que emmagatzema els accessos dels conductors' DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Normalització dels identificadors a minúscules i afegir els camps d'email i la paraula de pas. S'afegeixen comentaris a totes les columnes i s'amplia
-- la mida del camp cognoms que era massa petit
ALTER TABLE conductor COMMENT = 'Taula que emmagatzema les dades dels conductors',
CHANGE DNI dni VARCHAR(9) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'DNI del conductor',
CHANGE nom nom VARCHAR(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci COMMENT 'Nom del conductor',
CHANGE cognoms cognoms VARCHAR(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci COMMENT 'Cognoms del conductor',
CHANGE telefon telefon VARCHAR(15) CHARACTER SET utf8 COLLATE utf8_unicode_ci COMMENT 'Telefon del conductor',
CHANGE camió_matrícula camió_matrícula VARCHAR(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'Indica el vehicle que condueix',
ADD COLUMN email VARCHAR(50) NOT NULL COMMENT 'Correu electrònic del conductor',
ADD COLUMN contrasenya VARCHAR(40)  NOT NULL COMMENT 'Paraula de pas del conductor encriptada en MD5';

-- Normalització, els identificador numérics els anomemen 'id'
ALTER TABLE ruta COMMENT = 'Taula que emmagatzema les diferents rutes de transport';

ALTER TABLE ruta   
 CHANGE codi_ruta id INT(11) AUTO_INCREMENT NOT NULL COMMENT 'Identificador únic de ruta',
 CHANGE nom nom VARCHAR(25) CHARACTER SET utf8 COLLATE utf8_unicode_ci COMMENT 'Nom de la ruta',
 CHANGE cost_peatge cost_peatge INT(11) COMMENT 'Cos del peatge';


-- Normalització les claus foranas s'identifiquen per <taula>_<identificador>, per tant codi_ruta pasa a ser ruta_id
ALTER TABLE itinerari COMMENT = 'Taula que emmagatzema les ciutes per les que passa la ruta',
 DROP FOREIGN KEY itinerari_ibfk_1,
 DROP FOREIGN KEY itinerari_ibfk_2,
 CHANGE codi_ruta ruta_id INT(11) NOT NULL COMMENT 'Identificador de ruta',
 CHANGE ciutat_partida ciutat_id_partida INT(11) NOT NULL COMMENT 'Identificador de la ciutat de partida',
 CHANGE ciutat_destí ciutat_id_destí INT(11) NOT NULL COMMENT 'Identificador de la ciutat de destí',
 CHANGE distància distància INT(11) COMMENT 'Distància entre les ciutats';

 -- Afegim el conjunt de restriccions sobre la taula que controlen les relacions amb la taula de rutes i ciutat
 ALTER TABLE itinerari
 ADD PRIMARY KEY (ruta_id, ciutat_id_partida, ciutat_id_destí),
 ADD CONSTRAINT itinerari_ibfk_1 FOREIGN KEY (ruta_id) REFERENCES ruta (id) ON UPDATE RESTRICT ON DELETE RESTRICT,
 ADD CONSTRAINT itinerari_ibfk_2 FOREIGN KEY (ciutat_id_partida) REFERENCES ciutat (id) ON UPDATE RESTRICT ON DELETE RESTRICT,
 ADD CONSTRAINT itinerari_ibfk_3 FOREIGN KEY (ciutat_id_destí) REFERENCES ciutat (id) ON UPDATE RESTRICT ON DELETE RESTRICT;

-- Adequar la taula TRANSPORT per poder emmagatzemar la relació M:N:O, s'afegeix un identificador 'id' i es normalitzen
-- les claus foranas en el format adequat
ALTER TABLE transport
 DROP FOREIGN KEY transport_ibfk_1,
 DROP FOREIGN KEY transport_ibfk_2;

ALTER TABLE transport DROP INDEX matrícula;
ALTER TABLE transport DROP INDEX codi_ruta;

ALTER TABLE transport COMMENT = 'Taula que emmagatzema els diferents transports que han fet els conductors',
 ADD id INT KEY AUTO_INCREMENT COMMENT 'Identificador únic del transport' FIRST ,
 CHANGE matrícula camió_matrícula VARCHAR(10) NOT NULL COMMENT  'Taula que emmagatzema les diferents rutes de transport',
 CHANGE data_inici data_inici DATE COMMENT 'Data inici del transport',
 CHANGE data_finalització data_finalització DATE COMMENT 'Data finalització del transport, si null indica que el transport no ha finalitzat',
 CHANGE incidències incidències VARCHAR(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci COMMENT 'Incidències en el transport',
 CHANGE pes pes INT(11) COMMENT 'Pes transportat',
 CHANGE volum volum INT(11) COMMENT 'Volum transportat',
 CHANGE codi_ruta ruta_id INT(11) NOT NULL COMMENT 'Identificador de la ruta per la qual pasa el vehicle';
 
ALTER TABLE transport
 ADD CONSTRAINT transport_ibfk_1 FOREIGN KEY (camió_matrícula) REFERENCES camió (matrícula) ON UPDATE RESTRICT ON DELETE RESTRICT,
 ADD CONSTRAINT transport_ibfk_2 FOREIGN KEY (ruta_ID) REFERENCES ruta (id) ON UPDATE RESTRICT ON DELETE RESTRICT;


-- ------------------------------------------------------------------
-- Sentències LMD per inserir dades sobre les noves taules / columnes
-- ------------------------------------------------------------------

update conductor set email = replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(
lower(concat(substr(nom,1,1),cognoms,'@transport.es'))
,'á','a'),'é','e'),'í','i'),'ó','o'),'ú','u'),'à','a'),'è','e'),'ì','i'),'ò','o'),'ù','u'),contrasenya = MD5('12345'); 

ALTER TABLE conductor ADD UNIQUE INDEX IX_CONDUCTOR_EMAIL (email);

-- ------------------------------------------------------------------
-- Declaració de la funció checkUser
-- ------------------------------------------------------------------
DROP FUNCTION IF EXISTS checkUser;
DROP FUNCTION IF EXISTS canvi_password;

DELIMITER $$
CREATE FUNCTION checkUser (email CHAR(50), contrasenya CHAR(40)) 
 RETURNS INT 
BEGIN
  insert into accessos(conductor_dni)
   select c.DNI FROM conductor c where c.email = email and c.contrasenya = contrasenya;
  RETURN ROW_COUNT();
END;

CREATE FUNCTION canvi_password (email CHAR(50), contrasenya CHAR(40), nova_contrasenya CHAR(40)) 
 RETURNS INT 
BEGIN
  update conductor c set c.contrasenya = nova_contrasenya
  where c.email = email and c.contrasenya = contrasenya;
  RETURN ROW_COUNT();
END;

$$
DELIMITER ;

