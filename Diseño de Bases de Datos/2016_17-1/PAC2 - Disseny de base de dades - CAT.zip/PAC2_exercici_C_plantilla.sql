--
-- Base de dades: `Assignatures`
--
DROP DATABASE IF EXISTS `Assignatures`;
CREATE DATABASE IF NOT EXISTS `Assignatures` DEFAULT CHARACTER SET UTF8 COLLATE utf8_unicode_ci;
USE `Assignatures`;

-- --------------------------------------------------------
-- C1 - Definició de l'estructura 1FN
-- --------------------------------------------------------

--
-- Estructura de la taula `...`
--

...

-- --------------------------------------------------------
-- C2 - Modificació de l'estructura a 3FN
-- --------------------------------------------------------

--
-- Modificacions a la taula `...`
--

...

-- --------------------------------------------------------
-- C3 - Inserció de dades
-- --------------------------------------------------------

--
-- Bolcant dades de la taula `...`
--

...