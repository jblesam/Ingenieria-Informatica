--
-- Base de dades: `Discogràfica`
--

USE `Discogràfica`;

-- --------------------------------------------------------
-- Sentències LDD per ampliar l'estructura de taules
-- --------------------------------------------------------

--
-- Estructura de la taula `...`
--

...

-- --------------------------------------------------------
-- Sentències LMD per inserir dades a les noves taules
-- --------------------------------------------------------

--
-- Bolcant dades de la taula `...`
--

...