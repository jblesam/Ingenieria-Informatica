<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<?
// Importamos el paquete de idms
require_once('texts.html');

//presentamos el título en el idm seleccionado
?>
<title><?=$site_title[$idm];?></title>

<style type="text/css">

body{
margin:0;
padding:0;
line-height: 1.5em;
}

b{font-size: 110%;}
em{color: red;}

#maincontainer{
width: 840px; /*Width of main container*/
margin: 0 auto; /*Center container on page*/
}

#topsection{
background: #EAEAEA;
height: 90px; /*Height of top section*/
}

#topsection h1{
margin: 0;
padding-top: 15px;
}

#contentwrapper{
float: left;
width: 100%;
}

#contentcolumn{
margin-left: 200px; /*Set left margin to LeftColumnWidth*/
}

#leftcolumn{
float: left;
width: 200px; /*Width of left column*/
margin-left: -840px; /*Set left margin to -(MainContainerWidth)*/
background: #C8FC98;
}

#footer{
clear: left;
width: 100%;
background: black;
color: #FFF;
text-align: center;
padding: 4px 0;
}

#footer a{
color: #FFFF80;
}

.innertube{
margin: 10px; /*Margins for inner DIV inside each column (to provide padding)*/
margin-top: 0;
}

</style>

</head>
<body>
<div id="maincontainer">

<div id="topsection">
<div class="innertube"><h1><?=$header_text[$idm];?></h1>
<p>
<a href="index.php?pag=0&idm=<?=$idm;?>&temp=<?=$temp;?>"><?=$main_text[$idm];?></a>&nbsp;&nbsp;&nbsp;
<a href="index.php?pag=<?=$pag;?>&idm=0&temp=<?=$temp;?>"><?=$language_spanish[$idm];?></a> |
<a href="index.php?pag=<?=$pag;?>&idm=1&temp=<?=$temp;?>"><?=$language_english[$idm];?></a> |
<a href="index.php?pag=<?=$pag;?>&idm=2&temp=<?=$temp;?>"><?=$language_catalan[$idm];?></a>&nbsp;&nbsp;&nbsp;
<a href="index.php?pag=<?=$pag;?>&idm=<?=$idm;?>&temp=2"><i><?=$template[$idm];?> 2</i></a>
</p>
</div>
</div>

<div id="contentwrapper">
<div id="contentcolumn">
<div class="innertube">
<p><b>CONTENIDO</b></p>
<?php
//phpinfo();
# Ruta absoluta al directorio del sitio en el sistema de ficheros
$path = "";
# Nombre del fichero de contenido
$pagina = $pag."_$idm.html";

# TEST: ¿existe fichero de contenido?
$file = $path.$pagina; 
if(file_exists($file))
     include_once($pagina);
    else 
     echo $content_error[$idm]." ".$pagina;
?>
</div> 

</div>
</div>

<div id="leftcolumn">
<div class="innertube">
<p><b><?=$main_menu[$idm];?></b></p>
<?php
  for ($i=0; $i< sizeof($menu_text[$idm]); $i++){
		echo "<h3>".$menu_text[$idm][$i][0]."</h3>";
		echo "<ul>";
		for ($j=1; $j < sizeof($menu_text[$idm][$i]); $j++){
			echo "<li><a href=\"index.php?pag=".$menu__uri[$i][$j]."&idm=".$idm."&temp=".$temp."\">".$menu_text[$idm][$i][$j]."</a></li>";							
		}
		echo "</ul>";
  }
    
?>

</div>
</div>

<div id="footer">
<?=$footer_text[$idm];?>

</div>

</div>
</body>
</html>

