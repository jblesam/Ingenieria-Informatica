<?php
# --------------------------------------------------------------------------------
# Programa: index.php
# uso: index.php?pag=01&idm=es
#
# Carga los parámetros ‘pag’ y ‘idm’ pasados por el URL.
# Si no se han pasado parámetros, carga la página inicial del idioma por defecto
#
# Idiomas de la aplicación: es (español), en (inglés), cat (catalán)
# --------------------------------------------------------------------------------

// RESUELVO PARÁMETRO DE LA PÁGINA
$default_pag = 0;

/* Si se ha pasado el parámetro ‘pag’ por el URL y no está vacío, cargo su valor en la variable $pag, de lo contrario cargo la página por defecto. */ 

$pag = isset($_GET['pag']) && !empty($_GET['pag']) ? $_GET['pag'] : $default_pag;


// RESUELVO PARÁMETRO DEL IDIOMA
$default_idm = "0";

/* Si se ha pasado el parámetro ‘idm’ por el URL y no está vacío, cargo su valor en la variable $idm, de lo contrario le asigno un valor vacío. */
$idm = isset($_GET['idm']) && !empty($_GET['idm']) ? $_GET['idm'] : "";

/* Si el idioma seleccionado está en la lista de idiomas válidos (‘es-0’,’en-1’,’cat-2’), lo asigno a la variable $idm, de lo contrario cargo el idioma per defecto. */ 
$idm = ($idm == "0" || $idm == "1" || $idm == "2") ? $idm : $default_idm; 

//RESUELVO PARÁMETRO DE PLANTILLA
$default_template="1";
/* Si se ha pasado el parámetro ‘temp’ por el URL y no está vacío, cargo su valor en la variable $temp, de lo contrario le asigno un valor vacío. */
$temp = isset($_GET['temp']) && !empty($_GET['temp']) ? $_GET['temp'] : "";

/* Si la plantilla seleccionada está en la lista de plantillas válidos, lo asigno a la variable $temp, de lo contrario cargo la plantilla por defecto. */ 
$temp = ($temp == "1" || $temp == "2") ? $temp : $default_template; 
# Abro la plantilla HTML para el idioma seleccionado
include_once("layer_${temp}.php");

?>
